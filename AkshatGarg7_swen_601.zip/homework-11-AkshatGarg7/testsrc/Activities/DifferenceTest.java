package Activities;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DifferenceTest {

    @Test
    public void executeSingle(){
        //setup
        Operation diff = new Difference();
        double[] input = { -2.5d};
        double expected = -2.5d;

        //invoke
        double actual = diff.execute(input);

        //assert
        assertEquals(expected, actual);

    }

    @Test
    public void executeMultiple(){
        //setup
        Operation diff = new Difference();
        double[] input = { 10.0d, 3.0d, 4.0d};
        double expected = 3.0d;

        //invoke
        double actual = diff.execute(input);

        //assert
        assertEquals(expected, actual);

    }

    @Test
    public void executeZero(){
        //setup
        Operation diff = new Difference();
        double[] input = {};
        double expected = 0.0d;

        //invoke
        double actual = diff.execute(input);

        //assert
        assertEquals(expected, actual);

    }

    @Test
    public void matchesTure(){
        //setup
        Operation diff = new Difference();
        String operator = "-";
        boolean expected = true;

        //invoke
        boolean actual = diff.matches(operator);

        //assert
        assertEquals(expected,actual);
    }

    @Test
    public void matchesFalse(){
        //setup
        Operation diff = new Difference();
        String operator = "+";
        boolean expected = false;

        //invoke
        boolean actual = diff.matches(operator);

        //assert
        assertEquals(expected,actual);
    }

}