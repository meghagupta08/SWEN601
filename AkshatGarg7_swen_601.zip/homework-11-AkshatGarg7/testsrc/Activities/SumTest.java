package Activities;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SumTest {
    @Test
    public void executeSingle(){
        //setup
        Operation sum = new Sum();
        double[] input = {1.0d};
        double expected = 1.0d;

        //invoke
        double actual = sum.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    @Test
    public void executeMultiple(){
        //setup
        Operation sum = new Sum();
        double[] input = {1.0d , 3.0d , 2.5d};
        double expected = 6.5d;

        //invoke
        double actual = sum.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    @Test
    public void matchesFalse(){
        //setup
        Operation sum = new Sum();
        String operator = "-";
        boolean expected = false;

        //invoke
        boolean actual = sum.matches(operator);

        //assert
        assertEquals(expected,actual);
    }

    @Test
    public void matchesTrue(){
        //setup
        Operation sum = new Sum();
        String operator = "+";
        boolean expected = true;

        //invoke
        boolean actual = sum.matches(operator);

        //assert
        assertEquals(expected,actual);
    }
}