package homework;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Test for testing IntegerDivision
 *
 * @author Akshat Garg ag2193@rit.edu
 */

class IntegerDivisionTest {

    /**
     * Checking for single operand pass
     */

    @Test
    public void executeSingle(){
        //setup
        Operation intdiv = new IntegerDivision();
        double[] input = {3.0d};
        double expected = 3;

        //invoke
        double actual = intdiv.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for multiple operand pass
     */

    @Test
    public void executeMultiple(){
        //setup
        Operation intdiv = new IntegerDivision();
        double[] input = {15.0d, 2.5d, 7.0d, 0.3d};
        double expected = 0;

        //invoke
        double actual = intdiv.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for zero operand pass
     */

    @Test
    public void executeZero(){
        //setup
        Operation intdiv = new IntegerDivision();
        double[] input = {};
        double expected = 0;

        //invoke
        double actual = intdiv.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for division by zero and if previous result is positive operand pass
     */

    @Test
    public void executeDivPosZero(){
        //setup
        Operation intdiv = new IntegerDivision();
        double[] input = {15.0d, 2.5d, 0.0d, 0.3d};
        double expected = Double.POSITIVE_INFINITY;

        //invoke
        double actual = intdiv.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for division by zero and if previous result is negative operand pass
     */

    @Test
    public void executeDivNegZero(){
        //setup
        Operation intdiv = new IntegerDivision();
        double[] input = {15.0d, -2.5d, 0.0d, 0.3d};
        double expected = Double.NEGATIVE_INFINITY;

        //invoke
        double actual = intdiv.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for division by zero and if previous result is 0 too
     */

    @Test
    public void executeDivZeroZero(){
        //setup
        Operation intdiv = new IntegerDivision();
        double[] input = {0.0d, 10.0d, 0.0d, 0.3d};
        double expected = Double.NaN;

        //invoke
        double actual = intdiv.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for wrong operator input
     */

    @Test
    public void matchesFalse(){
        //setup
        Operation intdiv = new IntegerDivision();
        String operator = "/";
        boolean expected = false;

        //invoke
        boolean actual = intdiv.matches(operator);

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking for correct operator input
     */

    @Test
    public void matchesTrue(){
        //setup
        Operation intdiv = new IntegerDivision();
        String operator = "//";
        boolean expected = true;

        //invoke
        boolean actual = intdiv.matches(operator);

        //assert
        assertEquals(expected,actual);
    }
}