package homework;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Test for testing Exponent
 *
 * @author Akshat Garg ag2193@rit.edu
 */

class ExponentTest {

    /**
     * Checking for single operand pass
     */

    @Test
    public void executeSingle(){
        //setup
        Operation expo = new Exponent();
        double[] input = {3.0d};
        double expected = 3.0d;

        //invoke
        double actual = expo.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for multiple operand pass
     */

    @Test
    public void executeMultiple(){
        //setup
        Operation expo = new Exponent();
        double[] input = {3.0d,2.5d,3.5d};
        double expected = 14955.845800680298;

        //invoke
        double actual = expo.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for zero operand pass
     */

    @Test
    public void executeZero(){
        //setup
        Operation expo = new Exponent();
        double[] input = {};
        double expected = 0d;

        //invoke
        double actual = expo.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for wrong operator input
     */

    @Test
    public void matchesFalse(){
        //setup
        Operation expo = new Exponent();
        String[] operator = {"+"};
        boolean expected = false;

        //invoke
        boolean actual = expo.matches(operator);

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking for correct operator input if input is "**"
     */

    @Test
    public void matchesTrue1(){
        //setup
        Operation expo = new Exponent();
        String[] operator = {"**"};
        boolean expected = true;

        //invoke
        boolean actual = expo.matches(operator);

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking for correct operator input if input is "^"
     */

    @Test
    public void matchesTrue2(){
        //setup
        Operation expo = new Exponent();
        String[] operator = {"^"};
        boolean expected = true;

        //invoke
        boolean actual = expo.matches(operator);

        //assert
        assertEquals(expected,actual);
    }


}