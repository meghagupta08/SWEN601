package homework;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Test for testing sum
 *
 * @author Akshat Garg ag2193@rit.edu
 */

class SumTest {

    /**
     * Checking for single operand pass
     */
    @Test
    public void executeSingle(){
        //setup
        Operation sum = new Sum();
        double[] input = {1.0d};
        double expected = 1.0d;

        //invoke
        double actual = sum.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for multiple operand pass
     */

    @Test
    public void executeMultiple(){
        //setup
        Operation sum = new Sum();
        double[] input = {1.0d , 3.0d , 2.5d};
        double expected = 6.5d;

        //invoke
        double actual = sum.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for zero operand pass
     */

    @Test
    public void executeZero(){
        //setup
        Operation sum = new Sum();
        double[] input = {};
        double expected = 0.0d;

        //invoke
        double actual = sum.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for wrong operator input
     */

    @Test
    public void matchesFalse(){
        //setup
        Operation sum = new Sum();
        String operator = "-";
        boolean expected = false;

        //invoke
        boolean actual = sum.matches(operator);

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking for correct operator input
     */

    @Test
    public void matchesTrue(){
        //setup
        Operation sum = new Sum();
        String operator = "+";
        boolean expected = true;

        //invoke
        boolean actual = sum.matches(operator);

        //assert
        assertEquals(expected,actual);
    }
}