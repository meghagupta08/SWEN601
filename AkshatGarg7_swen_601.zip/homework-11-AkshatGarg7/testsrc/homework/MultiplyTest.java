package homework;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Test for testing multiply
 *
 * @author Akshat Garg ag2193@rit.edu
 */

class MultiplyTest {

    /**
     * Checking for single operand pass
     */

    @Test
    public void executeSingle(){
        //setup
        Operation multi = new Multiply();
        double[] input = {3.0d};
        double expected = 3.0d;

        //invoke
        double actual = multi.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for multiple operand pass
     */

    @Test
    public void executeMultiple(){
        //setup
        Operation multi = new Multiply();
        double[] input = {3.0d, 5.0d, 4.5d, 2.0d};
        double expected = 135.0d;

        //invoke
        double actual = multi.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for zero operand pass
     */

    @Test
    public void executeZero() {
        //setup
        Operation multi = new Multiply();
        double[] input = {};
        double expected = 0.0d;

        //invoke
        double actual = multi.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for wrong operator input
     */

    @Test
    public void matchesFalse(){
        //setup
        Operation multi = new Multiply();
        String operator = "/";
        boolean expected = false;

        //invoke
        boolean actual = multi.matches(operator);

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking for correct operator input
     */

    @Test
    public void matchesTrue(){
        //setup
        Operation multi = new Multiply();
        String operator = "*";
        boolean expected = true;

        //invoke
        boolean actual = multi.matches(operator);

        //assert
        assertEquals(expected,actual);
    }
}