package homework;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Test for testing difference
 *
 * @author Akshat Garg ag2193@rit.edu
 */

class DifferenceTest {

    /**
     * Checking for single operand pass
     */

    @Test
    public void executeSingle(){
        //setup
        Operation diff = new Difference();
        double[] input = {-1.0d};
        double expected = -1.0d;

        //invoke
        double actual = diff.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for multiple operand pass
     */

    @Test
    public void executeMultiple(){
        //setup
        Operation diff = new Difference();
        double[] input = {10.0d, 3.0d, 4.0d};
        double expected = 3.0d;

        //invoke
        double actual = diff.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for zero operand pass
     */

    @Test
    public void executeZero(){
        //setup
        Operation diff = new Difference();
        double[] input = {};
        double expected = 0.0d;

        //invoke
        double actual = diff.execute(input);

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking for correct operator input
     */

    @Test
    public void matchesTrue(){
        //setup
        Operation diff = new Difference();
        String operator = "-";
        boolean expected = true;

        //invoke
        boolean actual = diff.matches(operator);

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking for wrong operator input
     */

    @Test
    public void matchesFalse(){
        //setup
        Operation diff = new Difference();
        String operator = "+";
        boolean expected = false;

        //invoke
        boolean actual = diff.matches(operator);

        //assert
        assertEquals(expected,actual);
    }
}