package homework;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {
    @Test
    public void executeSum(){
        //setup
        String[] arrayOperation = new String[]{"+","-","*","/","//","%","^","**"};
        Calculator c = new Calculator(arrayOperation);
        String operator = "+";
        double[] input = {3.0d, 4.0d};
        double expected = 7.0d;

        //invoke
        double actual = c.resultOperation(operator,input);

        //assert
        assertEquals(expected, actual);
    }

    @Test
    public void executeDifference(){
        //setup
        String[] arrayOperation = new String[]{"+","-","*","/","//","%","^","**"};
        Calculator c = new Calculator(arrayOperation);
        String operator = "-";
        double[] input = {3.0d, 4.0d};
        double expected = -1.0d;

        //invoke
        double actual = c.resultOperation(operator,input);

        //assert
        assertEquals(expected, actual);
    }

    @Test
    public void executeMultiply(){
        //setup
        String[] arrayOperation = new String[]{"+","-","*","/","//","%","^","**"};
        Calculator c = new Calculator(arrayOperation);
        String operator = "*";
        double[] input = {3.0d, 4.0d};
        double expected = 12.0d;

        //invoke
        double actual = c.resultOperation(operator,input);

        //assert
        assertEquals(expected, actual);
    }

    @Test
    public void executeDivision(){
        //setup
        String[] arrayOperation = new String[]{"+","-","*","/","//","%","^","**"};
        Calculator c = new Calculator(arrayOperation);
        String operator = "/";
        double[] input = {3.0d, 4.0d};
        double expected = 0.75d;

        //invoke
        double actual = c.resultOperation(operator,input);

        //assert
        assertEquals(expected, actual);
    }

    @Test
    public void executeIntegerDivision(){
        //setup
        String[] arrayOperation = new String[]{"+","-","*","/","//","%","^","**"};
        Calculator c = new Calculator(arrayOperation);
        String operator = "//";
        double[] input = {4.0d, 3.0d};
        double expected = 1.0d;

        //invoke
        double actual = c.resultOperation(operator,input);

        //assert
        assertEquals(expected, actual);
    }

    @Test
    public void executeModulo(){
        //setup
        String[] arrayOperation = new String[]{"+","-","*","/","//","%","^","**"};
        Calculator c = new Calculator(arrayOperation);
        String operator = "%";
        double[] input = {11.0d,4.0d};
        double expected = 3.0d;

        //invoke
        double actual = c.resultOperation(operator,input);

        //assert
        assertEquals(expected, actual);
    }

    @Test
    public void executeExponent(){
        //setup
        String[] arrayOperation = new String[]{"+","-","*","/","//","%","^","**"};
        Calculator c = new Calculator(arrayOperation);
        String operator = "^";
        double[] input = {3.0d, 4.0d};
        double expected = 81.0d;

        //invoke
        double actual = c.resultOperation(operator,input);

        //assert
        assertEquals(expected, actual);
    }

    @Test
    public void executeFailing(){
        //setup
        String[] arrayOperation = new String[]{"+","-","*","/","//","%","^","**"};
        Calculator c = new Calculator(arrayOperation);
        String operator = "&";
        double[] input = {3.0d, 4.0d};
        double expected = 0;

        //invoke
        double actual = c.resultOperation(operator,input);

        //assert
        assertEquals(expected, actual);
    }


}