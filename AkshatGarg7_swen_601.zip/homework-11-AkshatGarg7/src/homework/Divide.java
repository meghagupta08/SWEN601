package homework;

/**
 * Divide is child class of AbstractOperation and divides all the operands and returns it.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class Divide extends AbstractOperation {

    public static final String OPERATOR = "/";//final symbol of divide

    /**
     * Constructor for Divide
     */

    protected Divide() {
        super(OPERATOR);
    }

    /**
     * returns 0 if no operands are passed else divides all the operands and returns result.
     * It also checks for positive infinity, negative infinity and not a number cases.
     *
     * @param operands values to be divided
     * @return result of division
     */

    @Override
    public double execute(double... operands) {
        if(operands.length < 1){// 0 operands passed
            return 0.0d;
        }
        double result = operands[0]; // default starting value
        for(int i = 1; i < operands.length; i++) {
            if(result > 0 && operands[i] == 0.0d){ // checks if it's a positive infinity if previous result is positive and next number is 0
                return Double.POSITIVE_INFINITY;
            }else if(result < 0 && operands[i] == 0.0d){// checks if it's a negative infinity if previous result is negative and next number is 0
                return Double.NEGATIVE_INFINITY;
            }else if(result == 0 && operands[i] == 0.0d){// checks if it's a NaN if previous number is 0 and next number is 0
                return Double.NaN;
            }else{
                result /= operands[i];
            }
        }
        return result;
    }
}
