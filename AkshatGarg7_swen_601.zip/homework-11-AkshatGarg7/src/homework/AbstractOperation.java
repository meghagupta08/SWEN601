package homework;

/**
 * AbstractOperation implements Operation interface and is an abstract parent class
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public abstract class AbstractOperation implements Operation{

    /**
     * OPERATOR is a string type operator constant
     */
    private final String[] OPERATOR;

    /**
     * Declaration of constructor for AbstractOperation
     *
     * @param operator array of string operator
     */

    protected AbstractOperation(String... operator) {
        OPERATOR = operator;
    }

    /**
     * Returns boolean based on match of string.
     *
     * @param operator string array input to compare with OPERATOR
     * @return boolean based on match of string
     */

    @Override
    public boolean matches(String[] operator) {
        for(int i = 0; i < OPERATOR.length; i++){
            for(int j = 0; j < operator.length; j++){
                if(OPERATOR[i].equals(operator[j])){
                    return true;
                }
            }
        }
        return false;
    }
}
