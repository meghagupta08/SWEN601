package homework;

/**
 * Multiply is child class of AbstractOperation and multiplies all the operands and returns it.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class Multiply extends AbstractOperation {

    public static final String OPERATOR = "*";//final symbol of multiply

    /**
     * Constructor for Multiply
     */

    protected Multiply() {
        super(OPERATOR);
    }

    /**
     * returns 0 if no operands are passed else multiplies all the operands and returns the result
     *
     * @param operands values to be multiplied
     * @return result of operands
     */

    @Override
    public double execute(double... operands) {
        if(operands.length < 1){// 0 operands passed
            return 0.0d;
        }
        double result = 1.0d; // default starting value
        for(int i = 0; i < operands.length; i++){
            result *= operands[i];
        }
        return result;
    }
}
