package homework;

/**
 * Difference is child class of AbstractOperation and differences all the operands and returns it.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class Difference extends AbstractOperation {

    public static final String OPERATOR = "-"; //final symbol of difference

    /**
     * Constructor for Difference
     */

    protected Difference() {
        super(OPERATOR);
    }

    /**
     * Returns 0 if we have no operands else will return difference of all operands
     *
     * @param operands values of operands for which difference to be found
     * @return difference of all operands
     */

    @Override
    public double execute(double... operands) {
        if(operands.length < 1){ //if no operands are passed
            return 0.0d;
        }
        double result = operands[0]; // more than 0 operands passed
        for(int i = 1; i < operands.length; i++){
            result -= operands[i]; // subtracts new operands from difference of previous operands
        }
        return result;
    }
}
