package homework;

/**
 * Modulo is child class of AbstractOperation and modules of all the operands and returns it.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class Modulo extends AbstractOperation{

    public static final String OPERATOR = "%";//final symbol of modulo

    /**
     * Constructor for Modulo
     */

    protected Modulo() {
        super(OPERATOR);
    }

    /**
     * returns 0 if no operands are passed else takes modulos of all the operands and returns result.
     * It also checks for positive infinity, negative infinity and not a number cases.
     *
     * @param operands values whose modules to be found
     * @return result of modulos
     */

    @Override
    public double execute(double... operands) {
        if(operands.length < 1){// 0 operands passed
            return 0;
        }
        double result = operands[0];// default starting value
        for(int i = 1; i < operands.length; i++) {
            if (result > 0 && operands[i] == 0) {// checks if it's a positive infinity if previous result is positive and next number is 0
                return Double.POSITIVE_INFINITY;
            } else if (result < 0 && operands[i] == 0) {// checks if it's a negative infinity if previous result is negative and next number is 0
                return Double.NEGATIVE_INFINITY;
            } else if (result == 0 && operands[i] == 0) {// checks if it's a NaN if previous number is 0 and next number is 0
                return Double.NaN;
            } else {
                result = result % operands[i];
            }
        }
        return result;
    }
}
