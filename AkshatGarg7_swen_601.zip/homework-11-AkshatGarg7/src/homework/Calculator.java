package homework;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Returns the value of operands entered by the user using appropriate operator.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class Calculator {
    private String[] operations;

    public Calculator(String[] operations) {
        this.operations = operations;
    }

    /**
     * We first check what operator we are gonna use from array of operation. then we execute the respective case.
     *
     * @param operator defines what operation to be performed
     * @param operands values to operated with
     * @return String with result
     */
    public double resultOperation(String operator, double[] operands) {
        int count = 0;
        String i = "";
        while (count < operations.length) { // checking for operator is in the list or not
            if (operations[count].equals(operator)) {
                i = operator;
                break;
            } else {
                count++;
            }
        }
        double a = 0;
        switch (i) { // based on previous value of operator we apply cases
            case "+":
                Sum s = new Sum();
                a = s.execute(operands);
                System.out.print("Sum of all operands is: " + a);
                return a;
            case "-":
                Difference diff = new Difference();
                a = diff.execute(operands);
                System.out.print("Difference of all operands is: " + a);
                return a;
            case "*":
                Multiply mul = new Multiply();
                a = mul.execute(operands);
                System.out.print("Multiplication of all operands is: " + a);
                return a;
            case "/":
                Divide div = new Divide();
                a = div.execute(operands);
                System.out.print("Division of all operands is: " + a);
                return a;
            case "//":
                IntegerDivision id = new IntegerDivision();
                a = id.execute(operands);
                System.out.print("IntegerDivision of all operands is: " + a);
                return a;
            case "%":
                Modulo mod = new Modulo();
                a = mod.execute(operands);
                System.out.print("Modulo of all operands is: " + a);
                return a;
            case "^":
            case "**":
                Exponent exp = new Exponent();
                a = exp.execute(operands);
                System.out.print("Exponent of all operands is: " + a);
                return a;
            default:
                System.out.println("Error: Unknown Operator: " + operator);
                return a;
        }
    }

    public static void main(String[] args) {
        String[] arrayOperation = new String[]{"+","-","*","/","//","%","^","**"};
        Calculator c = new Calculator(arrayOperation);
        ArrayList<Double> operands = new ArrayList<>();
        String q = "";
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the Operator and Operands below. And to stop entering operands type \"quit\"-> ");
        System.out.print("Operator: ");
        String operator = s.next();
        System.out.print("Enter operands: ");
        while(true) {
            q = s.next();
            if (q.equals("quit")) {
                break;
            } else{
                double o = Double.parseDouble(q);
                operands.add(o);
            }
        }
        double[] operandsArray = new double[operands.size()];
        for(int i = 0; i < operands.size(); i++){
            operandsArray[i] = operands.get(i);
        }
        c.resultOperation(operator, operandsArray);
    }
}
