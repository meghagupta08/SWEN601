package homework;

/**
 * Operation is an interface declaring operator and operands method.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public interface Operation {
    boolean matches(String... operator);
    double execute(double... operands);
}
