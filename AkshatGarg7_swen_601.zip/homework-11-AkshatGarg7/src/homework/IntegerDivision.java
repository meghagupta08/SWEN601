package homework;

/**
 * IntegerDivision is child class of AbstractOperation and integerdivsion of all the operands and returns it.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class IntegerDivision extends AbstractOperation{
    public static final String OPERATOR = "//"; //final symbol of integerdivision

    /**
     * Constructor for IntegerDivision
     */

    protected IntegerDivision() {
        super(OPERATOR);
    }

    /**
     * returns 0 if no operands are passed else divides the operands and rounds down to nearest integer and loops for all
     * operands and returns result.
     * It also checks for positive infinity, negative infinity and not a number cases.
     *
     * @param operands values to be divided
     * @return result of IntegerDivision
     */

    @Override
    public double execute(double... operands) {
        if(operands.length < 1){// 0 operands passed
            return 0;
        }
        double result = operands[0];// default starting value
        for(int i = 1; i < operands.length; i++) {
            if (result > 0 && operands[i] == 0) {// checks if it's a positive infinity if previous result is positive and next number is 0
                return Double.POSITIVE_INFINITY;
            } else if (result < 0 && operands[i] == 0) {// checks if it's a negative infinity if previous result is negative and next number is 0
                return Double.NEGATIVE_INFINITY;
            } else if (result == 0 && operands[i] == 0) {// checks if it's a NaN if previous number is 0 and next number is 0
                return Double.NaN;
            } else {
                result /= operands[i];
                result = Math.floor(result); // rounding down to integer value after each division
            }
        }
        return result;
    }
}
