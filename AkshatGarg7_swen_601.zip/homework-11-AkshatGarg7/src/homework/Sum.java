package homework;

/**
 * Sum is child class of AbstractOperation and sums all the operands and returns it.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class Sum extends AbstractOperation {

    public static final String OPERATOR = "+"; //final symbol of sum

    /**
     * Constructor for Sum
     */
    protected Sum() {
        super(OPERATOR);
    }

    /**
     * We are summing all the operands and returning the resulted sum.
     *
     * @param operands values to be added
     * @return resulted sum
     */
    @Override
    public double execute(double... operands) {
        double sum = 0.0d;
        for(double value: operands){
            sum += value;
        }
        return sum;
    }
}
