package homework;

/**
 * Exponent is child class of AbstractOperation and finds exponent based on the operands and returns it.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class Exponent extends AbstractOperation{

    public static final String[] OPERATOR = {"^","**"};//final symbols of exponent

    /**
     * Constructor for Exponent
     */

    protected Exponent() {
        super(OPERATOR);
    }

    /**
     * returns 0 if 0 operands passed else will return exponent of value of first operands raised to other operands.
     *
     * @param operands values whose exponent value to be found out
     * @return result of exponent
     */

    @Override
    public double execute(double... operands) {
        if(operands.length < 1){// 0 operands passed
            return 0;
        }
        double result = operands[0];// default starting value
        for(int i = 1; i < operands.length; i++){
            result = Math.pow(result,operands[i]); // finding the power of operands
        }
        return result;
    }
}
