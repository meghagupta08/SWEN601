package Activities;

public interface Operation {
    boolean matches(String operator);
    double execute(double ... operands);
}
