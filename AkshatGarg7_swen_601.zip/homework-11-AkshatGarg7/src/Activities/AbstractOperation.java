package Activities;

public abstract class AbstractOperation implements Operation{
    private final String OPERATOR;

    protected AbstractOperation(String operator) {
        OPERATOR = operator;
    }

    @Override
    public boolean matches(String operator) {
        return OPERATOR.equals(operator);
    }
}
