package Activities;

public class Difference extends AbstractOperation {

    public static final String OPERATOR = "-";

    protected Difference() {
        super(OPERATOR);
    }

    @Override
    public double execute(double... operands) {
        if (operands.length < 1){
            return 0.0d;
        }
        double diff = operands[0];
        for(int i = 1; i < operands.length; i++){
            diff = diff - operands[i];
        }
        return diff;
    }
}
