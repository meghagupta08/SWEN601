package Activities;

public class Sum extends AbstractOperation{

    public static final String OPERATOR = "+";

    protected Sum() {
        super(OPERATOR);
    }

    @Override
    public double execute(double... operands) {
        double sum = 0.0d;
        for(double value: operands){
            sum += value;
        }
        return sum;
    }
}
