package homework;

/**
 * Represents a node implementation of a stack
 *
 * @param <T> This describes my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */


public class NodeStack<T> implements Stack<T> {

    private Node<T> top;
    private int size; // indicates the next open slot

    /**
     * Creates an empty stack
     */
    public NodeStack(){
        this.top = null;
        this.size = 0;
    }

    /**
     * Adds the specified element to the top of the stack
     *
     * @param value my type parameter value
     */
    @Override
    public void push(T value) {
        Node<T> node = new Node<>(value);
        node.setNext(this.top); //set next element in stack linked list
        this.top = node;
        this.size++;
    }

    /**
     * Returns a reference to the element at the top of the stack.
     * The element is not removed from the stack.
     *
     * @return a reference to the element at the top of the stack
     */
    @Override
    public T peek() {
        return top.getValue();
    }

    /**
     * Removes the element at the top of the stack and returns a
     * reference to it.
     *
     * @return the element at the top of the stack and returns a reference to it.
     */
    @Override
    public T pop() {
        T value = this.top.getValue();
        Node<T> next = this.top.getNext();//get next element in stack linked list
        this.top = next;//set next element in linked list as top
        this.size --;
        return value;
    }

    /**
     * Returns the number of elements in the stack.
     *
     * @return the number of elements in the stack
     */
    @Override
    public int size() {
        return this.size;
    }
}

