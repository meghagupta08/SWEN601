package homework;

/**
 * Represents a node in linked list
 *
 * @param <T> This describes my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */

public class Node<T> {
    private T value;
    private Node<T> next;

    /**
     * Node Constructor
     *
     * @param value my type parameter value
     * @param next my type parameter next node reference
     */

    public Node(T value, Node<T> next){
        this.value = value;
        this.next = next;
    }

    /**
     * Node Constructor. creates a node storing the specified element
     *
     * @param value my type parameter value
     */
    public Node(T value){
        this(value,null); //setting next node as null
    }

    /**
     * Get the value of current node
     *
     * @return the value of current node
     */
    public T getValue() {
        return value;
    }

    /**
     * Set the value of node
     *
     * @param value of current node
     */
    public void setValue(T value) {
        this.value = value;
    }

    /**
     * Get the value of next node
     *
     * @return the value of next node
     */
    public Node<T> getNext() {
        return next;
    }

    /**
     * Set the value for next node
     *
     * @param next the value for the next node
     */
    public void setNext(Node<T> next) {
        this.next = next;
    }
}

