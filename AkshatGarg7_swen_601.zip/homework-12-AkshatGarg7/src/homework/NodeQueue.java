package homework;

/**
 * Represents a node implementation of a queue
 *
 * @param <T> This describes my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */

public class NodeQueue<T> implements Queue<T> {

    private Node<T> front, back;
    private int size;

    /**
     * Creates an empty queue.
     */
    public NodeQueue(){
        this.front = null;
        this.back = null;
        this.size = 0;
    }

    /**
     * Adds the specified element to the rear of the queue.
     *
     * @param value my type parameter value
     */
    @Override
    public void enqueue(T value) {
        Node<T> node = new Node<>(value);
        if(this.front == null || this.size == 0){//if value is the first element of the queue
            // both front and back pointer points to same node when first node is created
            this.front = node;
            this.back = node;
        }else{
            back.setNext(node);//set next element in queue linked list
            back = node;
        }
        this.size ++;
    }

    /**
     * Returns a reference to the element at the front of the queue.
     * The element is not removed from the queue.
     *
     * @return a reference to the element at the front of the queue
     */
    @Override
    public T peek() {
        return front.getValue();
    }

    /**
     * Removes the element at the front of the queue and returns a
     * reference to it.
     *
     * @return Removes the element at the front of the queue and returns a reference to it
     */
    @Override
    public T dequeue() {
        T value = this.front.getValue();
        this.front = this.front.getNext();
        if(this.front == null){//if there are no elements in queue, we set both back and front as null
            this.back = null;
        }
        size --;
        return value;
    }

    /**
     * Returns the number of elements currently in this queue.
     *
     * @return the number of elements currently in this queue
     */
    @Override
    public int size() {
        return size;
    }
}

