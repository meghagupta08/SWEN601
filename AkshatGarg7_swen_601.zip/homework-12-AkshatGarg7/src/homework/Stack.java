package homework;

/**
 * Implementation of a stack
 *
 * @param <T> This describes my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */


public interface Stack<T> {
    /**
     * Adds the specified element to the top of the stack
     *
     * @param value my type parameter value
     */
    void push(T value);
    /**
     * Returns a reference to the element at the top of the stack.
     * The element is not removed from the stack
     *
     * @return a reference to the element at the top of the stack
     */
    T peek();
    /**
     * Removes the element at the top of the stack
     * and returns a reference to it.
     *
     * @return remove the element at the top of stack and return it
     */
    T pop();
    /**
     * Returns the number of elements in the stack
     *
     * @return the number of elements in the stack
     */
    int size();
}

