package homework;

/**
 * Implementation of a queue
 *
 * @param <T> This describes my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */

public interface Queue<T> {
    /**
     * Adds the specified element to the rear of the queue
     *
     * @param value my type parameter value
     */
    void enqueue(T value);
    /**
     * Returns a reference to the element at the front of the queue.
     * The element is not removed from the queue.
     *
     * @return a reference to the element at the front of the queue
     */
    T peek();
    /**
     * Removes the element at the front of the queue and returns a
     * reference to it.
     *
     * @return removes the element at the front of the queue and returns a reference to it
     */
    T dequeue();
    /**
     * Returns the number of elements currently in this queue.
     *
     * @return the number of elements currently in this queue
     */
    int size();
}
