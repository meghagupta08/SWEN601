package homework;

public class Main {
    public static void main(String[] args) {
        System.out.println("Test for NodeStack");
        Stack<String> stack = new NodeStack<>();
        stack.push("abc");
        stack.push("def");
        stack.push("dog1");
        System.out.println("Top element: " + stack.peek());
        System.out.println("All the element of stack-> ");
        while(stack.size() > 0){
            String next = stack.pop();
            System.out.println(next);
        }

        System.out.println("\n\nTest for NodeQueue");
        Queue<String> queue = new NodeQueue<>();
        queue.enqueue("abc");
        queue.enqueue("def");
        queue.enqueue("thunder");

        System.out.println("Front element: " + queue.peek());
        System.out.println("All the element of queue-> ");
        while(queue.size() > 0){
            String next = queue.dequeue();
            System.out.println(next);
        }

        System.out.println("\n\nTest for ArrayStack");
        Stack<Integer> arrayStack = new ArrayStack<>();
        for(int i = 0; i < 5; i++){
            arrayStack.push(i);
        }
        System.out.println("Top element: " + arrayStack.peek());
        System.out.println("All the element of stack-> ");
        System.out.print("[");
        while(arrayStack.size() > 1){
            int next = arrayStack.pop();
            System.out.print(next + ",");
        }
        System.out.print(arrayStack.pop() + "]");

        System.out.println("\n\nTest for ArrayQueue");
        Queue<Integer> arrayQueue = new ArrayQueue<>();
        for(int i = 0; i < 5; i++){
            arrayQueue.enqueue(i);
        }
        System.out.println("Front element: " + arrayQueue.peek());
        System.out.println("All the element of queue-> ");
        System.out.print("[");
        while(arrayQueue.size() > 1){
            int next = arrayQueue.dequeue();
            System.out.print(next + ",");
        }
        System.out.print(arrayQueue.dequeue() + "]");

        System.out.println("\n\nTest for Cyclic ArrayQueue");
        Queue<Integer> cyclicQueue = new ArrayQueue<>();
        for(int i = 0; i < 5; i++){
            cyclicQueue.enqueue(i);
        }
        System.out.println("Front element: " + cyclicQueue.peek());
        cyclicQueue.dequeue();
        cyclicQueue.dequeue();
        cyclicQueue.enqueue(6);
        cyclicQueue.enqueue(7);
        System.out.println("All the element of queue-> ");
        System.out.print("[");
        while(cyclicQueue.size() > 1){
            int next = cyclicQueue.dequeue();
            System.out.print(next + ",");
        }
        System.out.print(cyclicQueue.dequeue() + "]");
    }
}
