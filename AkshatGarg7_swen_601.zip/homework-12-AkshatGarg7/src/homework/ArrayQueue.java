package homework;
import java.util.Arrays;

/**
 * Represents an array implementation of a queue in which the
 * indexes for the front and rear of the queue circle back to 0
 * when they reach the end of the array.
 *
 * @param <T> This describes my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */

public class ArrayQueue<T> implements Queue<T> {

    private Object[] array;
    private int size,front,back;

    /**
     * Creates an empty queue using the default capacity.
     */
    public ArrayQueue() {
        this.array = new Object[2];
        this.size = 0;
        this.front = -1;
        this.back = -1;
    }

    /**
     * Creates a new array to store the contents of the queue with
     * twice the capacity of the old one.
     */
    private void increaseLength(){
        Object[] larger = Arrays.copyOf(this.array,(this.size*2));
        this.front = 0;
        this.back = this.size - 1;
        this.array = larger;

    }

    /**
     * Adds the specified element to the rear of the queue, expanding
     * the capacity of the queue array if necessary.
     *
     * @param value my type parameter value
     */
    @Override
    public void enqueue(T value) {
        if(this.front == -1) {//if first element in queue
            this.front = 0;
        }
        else if(this.size == this.array.length){// expanding array because array was full
            increaseLength();
        }
        //if we dequeue and have null at start we will traverse back to starting of array to insert element
        this.back = (this.back + 1) % this.array.length;
        this.array[this.back] = value;
        this.size++;
    }

    /**
     * Returns a reference to the element at the front of the queue.
     * The element is not removed from the queue.
     *
     * @return a reference to the element at the front of the queue
     */
    @Override
    public T peek() {
        return (T) (this.array[this.front]);
    }

    /**
     * Removes the element at the front of the queue and returns a
     * reference to it.
     *
     * @return removes the element at the front of the queue and returns a reference to it
     */
    @Override
    public T dequeue() {
        T value = (T) (this.array[this.front]);
        this.array[this.front] = null;
        if(this.front == this.back){//empty array condition
            this.front = -1;
            this.back = -1;
        }else {//if we dequeue and front reached end of array and have some elements at start we will traverse back to starting of array
            this.front = (this.front + 1)% this.array.length;
        }
        this.size --;
        return value;
    }

    /**
     * Returns the number of elements currently in this queue.
     *
     * @return the number of elements currently in this queue
     */
    @Override
    public int size() {
        return size;
    }
}
