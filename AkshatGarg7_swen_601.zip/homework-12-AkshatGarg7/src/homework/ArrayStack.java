package homework;
import java.util.Arrays;

/**
 * Represents an array implementation of a stack
 *
 * @param <T> This describes my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */

public class ArrayStack<T> implements Stack<T>{

    private Object[] array;
    private int size; // indicates the next open slot

    /**
     * Creates an empty stack using the default capacity.
     */
    public ArrayStack() {
        this.array = new Object[2]; // initial array size is 2
        this.size = 0;
    }

    /**
     * Creates a new array to store the contents of the stack with
     * twice the capacity of the old one.
     */
    private void increaseLength(){
        this.array = Arrays.copyOf(this.array,(this.size*2));
    }

    /**
     * Adds the specified element to the top of the stack, expanding
     * the capacity of the stack array if necessary.
     *
     * @param value my type parameter value
     */
    @Override
    public void push(T value) {
        if(this.size == this.array.length){ // expanding array because array was full
            increaseLength();
        }
        this.array[this.size] = value;
        this.size++;
    }

    /**
     * Returns a reference to the element at the top of the stack.
     * The element is not removed from the stack.
     *
     * @return a reference to the element at the top of the stack
     */
    @Override
    public T peek() {
        return (T) (this.array[(this.size - 1)]);
    }

    /**
     * Removes the element at the top of the stack and returns a
     * reference to it.
     *
     * @return Removes the element at the top of the stack and returns a reference to it
     */
    @Override
    public T pop() {
        T value = (T) (this.array[this.size - 1]);
        this.array[this.size - 1] = null; // after popping
        size --;
        return value;
    }

    /**
     * Returns the number of elements in the stack
     *
     * @return the number of elements in the stack
     */
    @Override
    public int size() {
        return size;
    }
}
