package activities;

public class Main {
    public static void main(String[] args) {
        Node<Integer> intNode = new Node<>(1);
        Node<String> strNode = new Node<>("abc");
        //strNode.setNext(intNode); //cant connect str to int
        Node<Integer> third = new Node<>(23);
        intNode.setNext(third); //can connect only same type


        Stack<String> stack = new NodeStack<>();
        stack.push("abc");
        stack.push("def");
        stack.push("dog1");

        System.out.println(stack.peek());

        while(stack.size() > 0){
            String next = stack.pop();
            System.out.println(next);
        }

        Queue<String> queue = new NodeQueue<>();
        queue.enqueue("abc");
        queue.enqueue("def");
        queue.enqueue("thunder");

        System.out.println(queue.peek());
        while(queue.size() > 0){
            String next = queue.dequeue();
            System.out.println(next);
        }
    }
}
