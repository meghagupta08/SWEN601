package activities;

public class NodeStack<T> implements Stack<T> {

    private Node<T> top;
    private int size;

    public NodeStack(){
        this.top = null;
        this.size = 0;
    }

    @Override
    public void push(T value) {
        Node<T> node = new Node<>(value);
        node.setNext(this.top);
        this.top = node;
        this.size++;
    }

    @Override
    public T peek() {
        return top.getValue();
    }

    @Override
    public T pop() {
        T value = this.top.getValue();
        Node<T> next = this.top.getNext();
        this.top = next;
        this.size --;
        return value;
    }

    @Override
    public int size() {
        return this.size;
    }
}
