package activities;

public class NodeQueue<T> implements Queue<T> {

    private Node<T> front, back;
    private int size;

    public NodeQueue(){
        this.front = null;
        this.back = null;
        this.size = 0;
    }

    @Override
    public void enqueue(T value) {
        Node<T> node = new Node<>(value);
        if(this.front == null || this.size == 0){
            this.front = node;
            this.back = node;
        }else{
            back.setNext(node);
            back = node;
        }
        this.size ++;
    }

    @Override
    public T peek() {
        return front.getValue();
    }

    @Override
    public T dequeue() {
        T value = this.front.getValue();
        this.front = this.front.getNext();
        if(this.front == null){
            this.back = null;
        }
        size --;
        return value;
    }

    @Override
    public int size() {
        return size;
    }
}
