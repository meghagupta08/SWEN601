package homework;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Creating a unit test for Node implementation of Stack
 *
 * @author Akshat Garg ag2193@rit.edu
 */
class NodeStackTest {

    /**
     * Checking stack push for single push
     */
    @Test
    public void stackPushSingle() {
        //setup
        Stack<String> stack = new NodeStack<>();
        String input = "abc";
        int expected = 1;

        //invoke
        stack.push(input);
        int actual = stack.size();

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking stack push for Multiple push
     */
    @Test
    public void stackPushMultiple() {
        //setup
        Stack<String> stack = new NodeStack<>();
        int expected = 3;

        //invoke
        stack.push("abc");
        stack.push("def");
        stack.push("ghi");
        int actual = stack.size();

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking stack peek for single element in stack
     */
    @Test
    public void stackPeekSingle(){
        //setup
        Stack<String> stack = new NodeStack<>();
        stack.push("abc");
        String expected = "abc";

        //invoke
        String actual = stack.peek();

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking stack peek for multiple element in stack
     */
    @Test
    public void stackPeekMultiple(){
        //setup
        Stack<String> stack = new NodeStack<>();
        stack.push("abc");
        stack.push("def");
        stack.push("ghi");
        String expected = "ghi";

        //invoke
        String actual = stack.peek();

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking stack peek for zero element in stack
     */
    @Test
    public void stackPeekZero(){
        // Code is expected to throw a null point exception
        // because there is no element to peek in stack
        // Hence this assertion will pass
        Stack<String> stack = new NodeStack<>();
        assertThrows(NullPointerException.class, stack::peek);
    }

    /**
     * Checking stack pop for single element in stack
     */
    @Test
    public void stackPopSingle(){
        //setup
        Stack<String> stack = new NodeStack<>();
        stack.push("abc");
        String expected = "abc";

        //invoke
        String actual = stack.pop();

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking stack pop for multiple element in stack
     */
    @Test
    public void stackPopMultiple(){
        //setup
        Stack<String> stack = new NodeStack<>();
        stack.push("abc");
        stack.push("def");
        stack.push("ghi");
        String expected = "ghi\ndef\nabc";

        //invoke
        StringBuilder actual = new StringBuilder();
        while(stack.size() > 1) {
            String a = stack.pop();
            actual.append(a).append("\n");
        }
        actual.append(stack.pop());
        //assert
        assertEquals(expected, actual.toString());
    }

    /**
     * Checking stack pop for zero element in stack
     */
    @Test
    public void stackPopZero(){
        // Code is expected to throw a null point exception
        // because there is no element to pop in stack.
        // Hence, this assertion will pass
        Stack<String> stack = new NodeStack<>();
        assertThrows(NullPointerException.class, stack::pop);
    }

}