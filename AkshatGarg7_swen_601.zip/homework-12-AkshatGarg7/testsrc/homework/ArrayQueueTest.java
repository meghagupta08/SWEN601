package homework;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Creating a unit test for Array implementation of Stack
 *
 * @author Akshat Garg ag2193@rit.edu
 */
class ArrayQueueTest {

    /**
     * Checking queue enqueue for single enqueue
     */
    @Test
    public void queueEnqueueSingle() {
        //setup
        Queue<String> queue = new ArrayQueue<>();
        String input = "abc";
        int expected = 1;

        //invoke
        queue.enqueue(input);
        int actual = queue.size();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking queue enqueue for single enqueue
     */
    @Test
    public void queueEnqueueMultiple() {
        //setup
        Queue<String> queue = new ArrayQueue<>();
        int expected = 2;

        //invoke
        queue.enqueue("abc");
        queue.enqueue("def");
        int actual = queue.size();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking queue enqueue to see if array doubles when reached at its capacity
     */
    @Test
    public void queueEnqueueMoreThanCapacity() {
        //setup
        Queue<String> queue = new ArrayQueue<>();
        int expected = 5;

        //invoke
        queue.enqueue("abc");
        queue.enqueue("def");
        queue.enqueue("ghi");
        queue.enqueue("jkl");
        queue.enqueue("mno");
        int actual = queue.size();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking queue peek for single element in queue
     */
    @Test
    public void queuePeekSingle() {
        //setup
        Queue<String> queue = new ArrayQueue<>();
        queue.enqueue("abc");
        String expected = "abc";

        //invoke
        String actual = queue.peek();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking queue peek for multiple element in queue
     */
    @Test
    public void queuePeekMultiple() {
        //setup
        Queue<String> queue = new ArrayQueue<>();
        queue.enqueue("abc");
        queue.enqueue("def");
        queue.enqueue("ghi");
        String expected = "abc";

        //invoke
        String actual = queue.peek();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking queue peek for zero element in queue
     */
    @Test
    public void queuePeekZero() {
        // Code is expected to throw an Array out of bound exception
        // because there is no element to peek in array queue
        // Hence this assertion will pass
        Queue<String> queue = new ArrayQueue<>();
        assertThrows(ArrayIndexOutOfBoundsException.class, queue::peek);
    }

    /**
     * Checking queue dequeue for single element in queue
     */
    @Test
    public void queueDequeueSingle() {
        //setup
        Queue<String> queue = new ArrayQueue<>();
        queue.enqueue("abc");
        String expected = "abc";

        //invoke
        String actual = queue.dequeue();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking queue dequeue for multiple element in queue
     */
    @Test
    public void queueDequeueMultiple() {
        //setup
        Queue<String> queue = new ArrayQueue<>();
        queue.enqueue("abc");
        queue.enqueue("def");
        queue.enqueue("ghi");
        String expected = "abc\ndef\nghi";

        //invoke
        StringBuilder actual = new StringBuilder();
        while (queue.size() > 1) {
            String a = queue.dequeue();
            actual.append(a).append("\n");
        }
        actual.append(queue.dequeue());

        //assert
        assertEquals(expected, actual.toString());
    }

    /**
     * Checking queue dequeue for zero element in queue
     */
    @Test
    public void queueDequeueZero() {
        // Code is expected to throw an Array out of bound exception
        // because there is no element to dequeue in array queue
        // Hence this assertion will pass
        Queue<String> queue = new ArrayQueue<>();
        assertThrows(ArrayIndexOutOfBoundsException.class, queue::dequeue);
    }

    /**
     * Checking if circular queue implementation is working or not
     */
    @Test
    public void circularQueueTest(){
        //setup
        Queue<Integer> queue = new ArrayQueue<>();
        for(int i = 1; i < 6; i++){
            queue.enqueue(i);
        }
        String expected = "{3,4,5,6,7}";

        //invoke
        queue.dequeue();
        queue.dequeue();
        queue.enqueue(6);
        queue.enqueue(7);
        StringBuilder actual = new StringBuilder();
        actual.append("{");
        while(queue.size() > 1){
            int a = queue.dequeue();
            actual.append(a).append(",");
        }
        actual.append(queue.dequeue()).append("}");

        //assert
        assertEquals(expected, actual.toString());
    }
}