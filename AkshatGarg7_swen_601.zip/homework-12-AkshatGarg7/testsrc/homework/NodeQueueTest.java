package homework;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Creating a unit test for Node implementation of Queue
 *
 * @author Akshat Garg ag2193@rit.edu
 */
class NodeQueueTest {

    /**
     * Checking queue enqueue for single enqueue
     */
    @Test
    public void queueEnqueueSingle() {
        //setup
        Queue<String> queue = new NodeQueue<>();
        String input = "abc";
        int expected = 1;

        //invoke
        queue.enqueue(input);
        int actual = queue.size();

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking queue enqueue for single enqueue
     */
    @Test
    public void queueEnqueueMultiple() {
        //setup
        Queue<String> queue = new NodeQueue<>();
        int expected = 3;

        //invoke
        queue.enqueue("abc");
        queue.enqueue("def");
        queue.enqueue("ghi");
        int actual = queue.size();

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking queue peek for single element in queue
     */
    @Test
    public void queuePeekSingle() {
        //setup
        Queue<String> queue = new NodeQueue<>();
        queue.enqueue("abc");
        String expected = "abc";

        //invoke
        String actual = queue.peek();

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking queue peek for multiple element in queue
     */
    @Test
    public void queuePeekMultiple() {
        //setup
        Queue<String> queue = new NodeQueue<>();
        queue.enqueue("abc");
        queue.enqueue("def");
        queue.enqueue("ghi");
        String expected = "abc";

        //invoke
        String actual = queue.peek();

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking queue peek for zero element in queue
     */
    @Test
    public void queuePeekZero(){
        // Code is expected to throw a null point exception
        // because there is no element to peek in queue
        // Hence this assertion will pass
        Queue<String> queue = new NodeQueue<>();
        assertThrows(NullPointerException.class, queue::peek);
    }

    /**
     * Checking queue dequeue for single element in queue
     */
    @Test
    public void queueDequeueSingle() {
        //setup
        Queue<String> queue = new NodeQueue<>();
        queue.enqueue("abc");
        String expected = "abc";

        //invoke
        String actual = queue.dequeue();

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Checking queue dequeue for multiple element in queue
     */
    @Test
    public void queueDequeueMultiple() {
        //setup
        Queue<String> queue = new NodeQueue<>();
        queue.enqueue("abc");
        queue.enqueue("def");
        queue.enqueue("ghi");
        String expected = "abc\ndef\nghi";

        //invoke
        StringBuilder actual = new StringBuilder();
        while(queue.size() > 1) {
            String a = queue.dequeue();
            actual.append(a).append("\n");
        }
        actual.append(queue.dequeue());

        //assert
        assertEquals(expected, actual.toString());
    }

    /**
     * Checking queue dequeue for zero element in queue
     */
    @Test
    public void queueDequeueZero(){
        // Code is expected to throw a null point exception
        // because there is no element to dequeue in queue
        // Hence this assertion will pass
        Queue<String> queue = new NodeQueue<>();
        assertThrows(NullPointerException.class, queue::dequeue);
    }
}