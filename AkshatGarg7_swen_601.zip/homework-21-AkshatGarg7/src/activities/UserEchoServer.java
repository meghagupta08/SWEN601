package activities;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class UserEchoServer {
    public static void main(String[] args) throws IOException {
        ServerSocket server = new ServerSocket(33075);
        while (true) {
            System.out.println("Waiting for next client...");
            Socket client = server.accept();
            System.out.println("Connected!");
            InputStream in = client.getInputStream();
            InputStreamReader ir = new InputStreamReader(in);
            BufferedReader reader = new BufferedReader(ir);

            OutputStream out = client.getOutputStream();
            PrintWriter writer = new PrintWriter(out);
            while (true) {
                String line = reader.readLine();
                writer.println("server>> " + line);
                writer.flush();

                if (line.equalsIgnoreCase("quit")) {
                    System.out.println("Client quit!");
                    break;
                }
            }
        }
    }
}
