package activities;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

public class GooglePrinter {
    public static void main(String[] args) throws IOException {
        URL url = new URL(" http://www.google.com");
        url.openConnection();
        InputStream isr = url.openConnection().getInputStream();
        InputStreamReader ir = new InputStreamReader(isr);
        BufferedReader br = new BufferedReader(ir);
        while(br.readLine() != null){
            System.out.println(br.readLine());
        }
    }
}
