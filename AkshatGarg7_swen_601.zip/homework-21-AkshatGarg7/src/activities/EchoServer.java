package activities;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class EchoServer {
    public static void main(String[] args) throws IOException {
        System.out.println("Creating Server....");
        ServerSocket server = new ServerSocket(33075);
        while(true) {
            System.out.println("Waiting for connection....");
            Socket client = server.accept();
            System.out.println("Connection established!");

            InputStream in = client.getInputStream();
            InputStreamReader ir = new InputStreamReader(in);
            BufferedReader reader = new BufferedReader(ir);
            System.out.println("Reading a line of text....");
            String line = reader.readLine();
            System.out.println(line);

            OutputStream out = client.getOutputStream();
            PrintWriter writer = new PrintWriter(out);
            writer.println("server>> " + line);
            writer.flush();
        }
    }
}
