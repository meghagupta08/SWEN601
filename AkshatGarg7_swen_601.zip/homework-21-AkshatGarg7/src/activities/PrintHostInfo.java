package activities;

import java.io.IOException;
import java.net.InetAddress;

public class PrintHostInfo {
    public static void main(String[] args) throws IOException {
        InetAddress local = InetAddress.getLocalHost();
        System.out.println(local.getHostAddress());
        System.out.println(local.getHostName());

        InetAddress localhost = InetAddress.getByName("localhost");
        System.out.println(localhost.getHostAddress());
        System.out.println(localhost.getHostName());
    }
}
