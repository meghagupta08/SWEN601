package activities;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class UserEchoClient {
    public static void main(String[] args) throws IOException {
        Socket sock = new Socket(args[0],33075);

        OutputStream out = sock.getOutputStream();
        PrintWriter writer = new PrintWriter(out);
//        writer.println("Hello, World!");
//        writer.flush();

        InputStream in = sock.getInputStream();
        InputStreamReader ir = new InputStreamReader(in);
        BufferedReader reader = new BufferedReader(ir);

        Scanner scanner = new Scanner(System.in);
        while(true){
            System.out.print(">> ");
            String line = scanner.nextLine();
            writer.println(line);
            writer.flush();

            String response = reader.readLine();
            System.out.println(response);

            if(line.equalsIgnoreCase("quit")){
                break;
            }
        }
//        System.out.println("Reading a line of text....");
//        String line = reader.readLine();
//        System.out.println(line);

    }
}
