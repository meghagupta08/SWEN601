package activities;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

public class EchoClient {
    public static void main(String[] args) throws IOException {
        InetAddress local = InetAddress.getLocalHost();
        String hostname = local.getHostName();

        System.out.println("Opening a connection....");
        Socket sock = new Socket(hostname,33075);
        System.out.println("Connection established!");

        OutputStream out = sock.getOutputStream();
        PrintWriter writer = new PrintWriter(out);
        writer.println("Hello, World!");
        writer.flush();

        System.out.println("Waiting for response....");

        InputStream in = sock.getInputStream();
        InputStreamReader ir = new InputStreamReader(in);
        BufferedReader reader = new BufferedReader(ir);
//        System.out.println("Reading a line of text....");
        String line = reader.readLine();
        System.out.println(line);
    }
}
