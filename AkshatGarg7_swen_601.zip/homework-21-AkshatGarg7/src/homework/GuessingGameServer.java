package homework;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;

/**
 * Server Side to use guess gaming
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class GuessingGameServer {
    /**
     * creating a variable random variable to be used to create random number
     */
    private final static Random RNG = new Random(); //seed not defined as it will generate same random number

    /**
     * Main function to run server
     *
     * @param args None
     * @throws IOException if any exception occurs throw IOException
     */
    public static void main(String[] args) throws IOException {
        /*
         * Creating a server socket for the game at port 6355
         */
        ServerSocket server = new ServerSocket(6355);

        while(true){
            Socket client = server.accept(); //waiting until a client joins

            /*
             * Taking input from client
             */
            InputStream in = client.getInputStream();
            InputStreamReader ir = new InputStreamReader(in);
            BufferedReader reader = new BufferedReader(ir);

            /*
             * Sending output to client side
             */
            OutputStream out = client.getOutputStream();
            PrintWriter writer = new PrintWriter(out);

            int count = 0;
            int random = RNG.nextInt(99) + 1; //generating a random new number
            while(true){
                String line = reader.readLine();
                /*
                 * based on input from client side, response generated and send to client
                 */
                if(line.equals("restart")){
                    writer.print("restarted\n");
                    writer.flush();
                    count = 0;
                    random = RNG.nextInt(99) + 1; //generating a random new number
                }else if(line.equals("quit")){
                    writer.print("game_over\n");
                    writer.flush();
                    break;
                }else if(line.toLowerCase().contains("guess") && line.toLowerCase().substring(0, 5).equals("guess")){
                    String[] string = line.split("\\s+"); //splitting by spaces to take 2nd element as int input for guess
                    if(string.length != 2){
                        writer.print("error\n");
                    }
                    if(count >= 6){ //more than 6 tries
                        writer.print("out_of_guesses\n");
                    }else if(Integer.parseInt(string[1]) < random){
                        writer.print("toolow\n");
                    }else if(Integer.parseInt(string[1]) > random){
                        writer.print("toohigh\n");
                    }else if(Integer.parseInt(string[1]) == random){
                        writer.print("correct\n");
                    }
                    writer.flush();
                    count++;
                }else{
                    writer.print("error\n");
                }
                writer.flush(); //sending the output to client side
            }
        }
    }
}//End of class
