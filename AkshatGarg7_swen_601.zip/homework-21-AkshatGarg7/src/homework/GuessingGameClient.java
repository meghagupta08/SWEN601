package homework;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

/**
 * Client Side to use guess gaming
 *
 * @author Akshat Garg ag2193@rit.edu
 */
public class GuessingGameClient {

    /**
     * Main function which throws IOException
     *
     * @param args take 1 argument for finding server
     * @throws IOException if any exception occurs throw IOException
     */

    public static void main(String[] args) throws IOException {
        /*
          Connect to socket
         */
        Socket sock = new Socket(args[0],6355);

        /*
          Send data
         */
        OutputStream out = sock.getOutputStream();
        PrintWriter writer = new PrintWriter(out);

        /*
          Take input from server
         */
        InputStream in = sock.getInputStream();
        InputStreamReader ir = new InputStreamReader(in);
        BufferedReader reader = new BufferedReader(ir);

        Scanner scanner = new Scanner(System.in);
        while(true){
            String line = scanner.nextLine();
            writer.println(line);
            writer.flush();

            String response = reader.readLine();
            /*
             * giving output according to response from server
             */
            if(response.equalsIgnoreCase("toolow")){
                System.out.println("Too low!");
            }else if(response.equalsIgnoreCase("toohigh")){
                System.out.println("Too high!");
            }else if(response.equalsIgnoreCase("out_of_guesses")){
                System.out.println("Out of guesses!");
            }else if(response.equalsIgnoreCase("correct")){
                System.out.println("Correct!");
            }else if(response.equalsIgnoreCase("game_over")){
                System.out.println(response);
                sock.close(); //quit case, we close the socket
                break;
            }else{
                System.out.println(response);
            }
        }
    }
}
