package activities;

public class Main {
    public static void main(String[] args) {
        Graph<String> graph = new AdjacencyGraph<>();
        graph.addValue("A");
        graph.addValue("B");
        graph.addValue("C");
        graph.addValue("D");
        graph.addValue("E");
        graph.addValue("F");
        graph.addValue("G");

        graph.connectUndirected("A","B");
        graph.connectUndirected("C","D");
        graph.connectUndirected("E","F");
        graph.connectUndirected("E","G");

        graph.connectDirected("D","A");
        graph.connectDirected("B","C");
        graph.connectDirected("G","F");

        System.out.println(graph.breadthFirstSearch("A","C"));
        System.out.println(graph.breadthFirstSearch("A","G"));

        System.out.println(graph.breadthFirstPath("A","C"));
    }
}
