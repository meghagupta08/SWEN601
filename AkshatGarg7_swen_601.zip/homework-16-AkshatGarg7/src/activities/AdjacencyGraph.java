package activities;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

public class AdjacencyGraph<T> implements Graph<T>{

    private final HashMap<T, Vertex<T>> vertices;

    public AdjacencyGraph() {
        this.vertices = new HashMap<>();
    }

    @Override
    public void addValue(T value) {
        Vertex<T> vertex = new Vertex<>(value);
        vertices.put(value,vertex);
    }

    @Override
    public boolean contains(T value) {
        return vertices.containsKey(value);
    }

    @Override
    public void connectDirected(T value, T... neighbors) {
        Vertex<T> vertex = vertices.get(value);
        for(T neighbourValue : neighbors){
            Vertex<T> neighbour = vertices.get(neighbourValue);
            vertex.addNeighbor(neighbour);
        }
    }

    @Override
    public void connectUndirected(T value, T... neighbors) {
        Vertex<T> vertex = vertices.get(value);
        for(T neighbourValue : neighbors){
            Vertex<T> neighbour = vertices.get(neighbourValue);
            vertex.addNeighbor(neighbour);
            neighbour.addNeighbor(vertex);
        }
    }

    @Override
    public int size() {
        return vertices.size();
    }

    @Override
    public boolean breadthFirstSearch(T s,T e){
        Vertex<T> start = vertices.get(s);
        Vertex<T> end = vertices.get(e);

        HashSet<Vertex<T>> visited = new HashSet<>();
        LinkedList<Vertex<T>> queue = new LinkedList<>();

        visited.add(start);
        queue.add(start);
        while(queue.size() > 0){
            Vertex<T> v = queue.remove(0); //constant time
            if(v == end){
                return true;
            }else{
                for(Vertex<T> neighbour : v.getNeighbors()){
                    if(!visited.contains(neighbour)){
                        visited.add(neighbour);
                        queue.add(neighbour);
                    }
                }
            }
        }
        return false;
    }

    @Override
    public List<T> breadthFirstPath(T s, T e){
        Vertex<T> start = vertices.get(s);
        Vertex<T> end = vertices.get(e);

        HashMap<Vertex<T>, Vertex<T>> visited = new HashMap<>();
        LinkedList<Vertex<T>> queue = new LinkedList<>();

        visited.put(start,null);
        queue.add(start);

        LinkedList<T> path = new LinkedList<>();

        while(queue.size() > 0){
            Vertex<T> v = queue.remove(0); //constant time
            if(v == end){
                Vertex<T> c = end;
                while(c != null){
                    path.add(0,c.getValue());
                    c = visited.get(c);
                }
                return path;
            }else{
                for(Vertex<T> neighbour : v.getNeighbors()){
                    if(!visited.containsKey(neighbour)){
                        visited.put(neighbour,v);
                        queue.add(neighbour);
                    }
                }
            }
        }


        return path;
    }
//    @Override
//    public String toString() {
//        return "AdjacencyGraph{" +
//                "vertices=" + vertices +
//                '}';
//    }
}
