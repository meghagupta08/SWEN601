package activities;

import java.util.HashSet;

public class Vertex<T> {
    private T value;
    private HashSet<Vertex<T>> neighbors;

    public Vertex(T value) {
        this.value = value;
        this.neighbors = new HashSet<>();
    }

    public void addNeighbor(Vertex<T> neighbor){
        this.neighbors.add(neighbor);
    }

    public HashSet<Vertex<T>> getNeighbors(){
        return this.neighbors;
    }

    public T getValue() {
        return value;
    }
//    @Override
//    public String toString() {
//        return "Vertex{" +
//                "value=" + value +
//                ", neighbors=" + getNeighbors() +
//                '}';
//    }
}
