package activities;

import java.util.LinkedList;
import java.util.List;

public interface Graph<T> {
    void addValue(T value);
    boolean contains(T value);
    void connectDirected(T value, T... neighbors);
    void connectUndirected(T value,T... neighbors);
    int size();
    default boolean breadthFirstSearch(T start,T end){ //we can implement in interface but cant do anything
        return false;
    }
    default List<T> breadthFirstPath(T start,T end){
        return new LinkedList<>();
    }
}
