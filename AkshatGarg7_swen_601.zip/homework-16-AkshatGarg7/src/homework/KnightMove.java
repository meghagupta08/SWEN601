package homework;
import java.util.*;

/**
 * KnightMove is an implementation of AdjacencyGraph and Graph
 *
 * @author Akshat Garg ag2193@rit.edu
 */
public class KnightMove {

    /**
     * Possible move for knight in for any given coordinates
     */
    private final int[][] DIRECTIONS = new int[][]{{2, 1}, {1, 2}, {-1, 2}, {-2, 1}, {-2, -1}, {-1, -2}, {1, -2}, {2, -1}};
    /**
     * fields
     */
    public AdjacencyGraph<String> grid;
    private int[] gridSize;
    private String start, destination;

    /**
     * Constructor
     *
     * @param gridSize size of chessboard
     * @param start starting coordinate of knight
     * @param destination coordinates of target
     */
    public KnightMove(int[] gridSize, String start, String destination) {
        this.grid = new AdjacencyGraph<>();
        this.gridSize = gridSize;
        this.start = start;
        this.destination = destination;
    }

    /**
     * Creates neighbours of knight for given position
     *
     * @param cell current coordinate of knight
     * @return Set of all possible neighbours of knight
     */
    public Set<Vertex<String>> createNeighbor(Vertex<String> cell) {
        int[] row = { -2, -1, 1, 2, -2, -1, 1, 2 };
        int[] column = { -1, -2, -2, -1, 1, 2, 2, 1 };
        String[] cellCoordinate = cell.getValue().split(","); //splits the string and adds ",: in between
        int x = Integer.parseInt(cellCoordinate[0]);
        int y = Integer.parseInt(cellCoordinate[1]);

        Set<Vertex<String>> neighbors = new HashSet<>();
        if (x < 0 || y < 0 || x >= gridSize[0] || y >= gridSize[1]) { // checking for out of bound neighbours
            return null;
        } else {
            for(int i = 0; i < 8 ; i++){
            //for (int[] d : DIRECTIONS) {
                int newX = x + row[i];
                int newY = y + column[i];
                if (!(newX < 0 || newY < 0 || newX >= gridSize[0] || newY >= gridSize[1])) { //after adding checking for out of bounds neighbours
                    String next = newX + "," + newY;
                    this.grid.addValue(next);
                    this.grid.connectUndirected((x + "," + y), next);
                    neighbors.add(new Vertex<>(next));
                }
            }
        }
        return neighbors;
    }

    /**
     * Shortest path to target from start
     */
    public void shortestPath(){
        Vertex<String> s = new Vertex<>(start);
        Vertex<String> e = new Vertex<>(destination);
        String[] eString = e.getValue().split(",");
        int eX = Integer.parseInt(eString[0]);
        int eY = Integer.parseInt(eString[1]);

        LinkedList<Vertex<String>> queue = new LinkedList<>();
        Set<Vertex<String>> visited = new HashSet<>();
        Set<Vertex<String>> vertices = new HashSet<>();

        queue.add(s);
        visited.add(s);

        boolean flag = false;

        while(queue.size() > 0){
            Vertex<String> cur = queue.remove(0);
            vertices = createNeighbor(cur);
            String[] curString = cur.getValue().split(",");
            int curX = Integer.parseInt(curString[0]);
            int curY = Integer.parseInt(curString[1]);
            if(eX == curX && eY == curY){
                flag = false;
            }
            for(Vertex<String> vertex : vertices){
                for(Vertex<String> v : visited){
                    if(v.getValue().equals(vertex.getValue())){
                        flag = true;
                        break;
                    }
                }
                if(!flag){
                    visited.add(vertex);
                    queue.add(vertex);
                }
                flag = false;
            }
        }
    }
}
