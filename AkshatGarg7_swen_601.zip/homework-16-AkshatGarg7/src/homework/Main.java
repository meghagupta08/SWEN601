package homework;

import java.util.List;
import java.util.Scanner;

/**
 * Implementing KnightMove in main
 *
 * @author Akshat Garg ag2193@rit.com
 */
public class Main {
    /**
     * Main function
     *
     * @param args 2 , grid size
     */
    public static void main(String[] args) {
        int startX = 0;
        int startY = 0;
        int endX = 0;
        int endY = 0;

        int gridX = Integer.parseInt(args[0]);
        int gridY = Integer.parseInt(args[1]);

        Scanner s = new Scanner(System.in);
        String q;
        while (true) {
            System.out.print("Enter <row1> <col1> <row2> <col2> or quit: ");
            q = s.next();
            if (q.equals("quit")) {
                break;
            }
            startX = Integer.parseInt(q);
            startY = s.nextInt();
            endX = s.nextInt();
            endY = s.nextInt();


            String start = startX + "," + startY;
            String end = endX + "," + endY;
            String[][] output = new String[gridX][gridY]; //output matrix
            for (int i = 0; i < gridX; i++) {
                for (int j = 0; j < gridY; j++) {
                    output[i][j] = " ";
                }
            }

            //calling the function
            KnightMove knightMoves = new KnightMove(new int[]{gridX, gridY}, start, end);
            knightMoves.grid.addValue(start);
            knightMoves.grid.addValue(end);
            knightMoves.shortestPath();

            // getting the path in list output
            List<String> path = knightMoves.grid.breadthFirstPath(start, end);
            int index = 0;
            while (index < path.size()) {
                String[] stringArray = (path.get(index)).split(",");
                int x = Integer.parseInt(stringArray[0]);
                int y = Integer.parseInt(stringArray[1]);
                output[x][y] = String.valueOf(index); //setting step number in output matrix
                index++;
            }
            //start "s" and end "e" setup
            output[startX][startY] = "S";
            output[endX][endY] = "E";

            //output
            for (int i = 0; i < gridX; i++) {
                System.out.print("|");
                for (int j = 0; j < gridY; j++) {
                    System.out.print(output[i][j] + "|");
                }
                System.out.print("\n");
            }
        }
    }
}
