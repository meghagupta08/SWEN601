package homework;

import java.util.LinkedList;
import java.util.List;

/**
 * Implemantation of Graph
 *
 * @param <T> my Type parameter
 */

public interface Graph<T> {
    /**
     * Add value to graph
     * @param value to be added
     */
    void addValue(T value);

    /**
     * @param value to be searched
     * @return boolean based on test
     */
    boolean contains(T value);

    /**
     * Connects two neighbour in one direction
     *
     * @param value current value
     * @param neighbors neighour of value
     */
    void connectDirected(T value, T... neighbors);

    /**
     * Connects two neighbour in uni direction
     *
     * @param value current value
     * @param neighbors neighour of value
     */
    void connectUndirected(T value,T... neighbors);

    /**
     * @return size of graph
     */
    int size();

    /**
     * Finds the shortest path
     *
     * @param start start value
     * @param end target value
     * @return boolean if found
     */
    default boolean breadthFirstSearch(T start,T end){ //we can implement in interface but cant do anything
        return false;
    }

    /**
     * Finds the shortest path and returns same
     * @param start start value
     * @param end target value
     * @return path
     */
    default List<T> breadthFirstPath(T start,T end){
        return new LinkedList<>();
    }
}
