package activities;

import homework.CopierThread;

import java.util.ArrayList;

public class MyClass implements Runnable{
    private static long sum;
    private static double mainSum;
    private double id;

    public MyClass(double id){
        this.id = id;
        sum = 0;
        mainSum = 0;
    }

    @Override
    public void run() {
        sum += 1000;
        mainSum += id;
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("Start");
        ArrayList<Thread> threads = new ArrayList<>();
        for(int i = 0; i < 100; i++){
            MyClass myClass = new MyClass(i);
            Thread thread = new Thread(myClass);
            thread.start();
            threads.add(thread);
        }

        for(Thread thread : threads){
            thread.join();
        }

        System.out.println("MainSum: " + mainSum);
        System.out.println("Sum: " + sum);
    }
}
