package activities;

public class RunnableCounter implements Runnable{

    private int number;

    public RunnableCounter(int number) {
        this.number = number;
    }

    @Override
    public void run() {
        for(int i = 1; i < 101; i++){
            System.out.println("runnable " + this.number + ": " + i);
        }
    }

    public static void main(String[] args) {
        RunnableCounter runnableCounter = new RunnableCounter(1);
        Thread thread = new Thread(runnableCounter);
        System.out.println("MAIN START");
        thread.start();
        System.out.println("MAIN RUN");
    }
}
