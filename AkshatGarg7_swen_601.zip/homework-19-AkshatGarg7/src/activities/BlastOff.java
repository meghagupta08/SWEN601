package activities;

public class BlastOff implements Runnable{
    @Override
    public void run() {
        int i = -10;
        while(true) {
            if(i < 0) {
                System.out.println("T" + i);
            }else{
                System.out.println("T+" + i);
            }
            i++;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {}
        }
    }

    public static void main(String[] args) {
        BlastOff bo = new BlastOff();
        Thread thread = new Thread(bo);
        thread.start();
    }
}
