package activities;

public class CounterThread extends Thread{
    private int number;

    public CounterThread(int number) {
        this.number = number;
    }

    @Override
    public void run(){
        for(int i = 1; i < 101; i++){
            System.out.println("thread " + this.number + ": " + i);
        }
    }

    public static void main(String[] args) {
        CounterThread thread = new CounterThread(1);
        //thread.start();
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("MAIN START");
        System.out.println("Thread is alive: " + thread.isAlive());
        thread.start();
        System.out.println("Thread is alive: " + thread.isAlive());
        //thread.run();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
        }
        System.out.println("MAIN END");
        System.out.println("Thread is alive: " + thread.isAlive());
        //thread.start(); Exception because it is dead
    }
}
