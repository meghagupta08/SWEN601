package activities;

import java.util.ArrayList;

public class ManyCounters {
    public static void main(String[] args) {
        ArrayList<Thread> threads = new ArrayList<>();
        for(int i = 1; i < 11; i++){
            RunnableCounter runnableCounter = new RunnableCounter(i);
            Thread thread = new Thread(runnableCounter);
            thread.start();
            threads.add(thread);
            /**
             * Concurrency is dead
             */
//            try {
//                thread.join();
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
        }
        for(Thread thread : threads){
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
//        try {
//            Thread.sleep(1000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
        System.out.println("All done!");
//        for(int i = 1; i < 101; i++){
//            System.out.println("main: " + i);
//        }
    }
}
