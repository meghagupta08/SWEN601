package homework;

/**
 * Counter runs the myRunnable counter to count up to given user input number and up to given number
 * times in different threads one after another.
 *
 * @author Akshat Garg ag2193@rit.edu
 */
public class Counter {
    /**
     * Main method
     *
     * @param args number till we have to print
     */
    public static void main(String[] args) {
        /**
         * checking if 1 argument are passed or not
         */
        if(args.length != 1){
            System.out.println("Usage: java homework.Counter <number>");
            System.exit(1);
        }
        int number = Integer.parseInt(args[0]);//10;
        /**
         * Running myRunnable counters to count the number from 1 to number
         */
        for(int i = 1; i < number + 1; i ++){
            MyRunnable myRunnable = new MyRunnable(i,number);
            Thread thread = new Thread(myRunnable);
            thread.start();
            //waiting for previous thread to finish the task
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
