package homework;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * CopierThread creates thread for each file in source directory and implements the concept of
 * multi thread.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class CopierThread implements Runnable {
    /**
     * Required Fields
     */
    private String source, destination;
    private Exception exception;
    private static long bytes;

    /**
     * Constructor
     *
     * @param source from where the files to copied
     * @param destination to where the files be pasted
     */
    public CopierThread(String source, String destination) {
        this.source = source;
        this.destination = destination;
        bytes = 0;
        exception = null;
    }

    /**
     * @return the exception
     */
    public Exception getException() {
        return exception;
    }

    /**
     * @return the total bytes copied
     */
    public static long getBytes() {
        return bytes;
    }

    /**
     * run the thread with following steps
     */
    @Override
    public void run() {
        try {
            File f = new File(source);
            bytes += f.length();
            System.out.println("    Copying file '" + f.getName() + "'...");
            FileUtils.copyFile(source,destination + "\\" + f.getName());
        } catch (IOException ex) {
            this.exception = ex;
            System.exit(1);
        }
    }

    /**
     * Main method
     *
     * @param args source and destination directory
     */
    public static void main(String[] args) {
        /**
         * checking if 2 arguments are passed or not
         */
        if(args.length != 2) {
            System.out.println("Usage: java homework.FileCopier <input dir> <output dir>");
            System.exit(1);
        }
        String source = args[0];
        String destination = args[1];

        //start of program
        long startTime = System.currentTimeMillis();

        /**
         * Clearing the output directory
         */
        try {
            System.out.println("Clearing directory '" + destination + "'.");
            FileUtils.clearDirectory(destination);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        /**
         * Copying file from source to destination by creating
         */
        File searchPath = new File(source);
        int count = 0;
        long countBytes = 0;
        File[] files = searchPath.listFiles();
        ArrayList<Thread> threads = new ArrayList<>();

        if (files != null) { //directory is not empty check
            for (File file : files) {
                //If a directory is found inside the source directory we will skip it
                if (file.isDirectory()) {
                    System.out.println("    Skipping directory '" + file.getName() + "'...");
                    continue;
                }
                //copying each file from source to destination
                count++;
                countBytes += file.length();
                CopierThread copierThread = new CopierThread(file.getAbsolutePath(),destination);
                Thread thread = new Thread(copierThread);
                thread.start();
                threads.add(thread);
            }
        }else{ //if source directory is empty!
            throw new NullPointerException("Source Directory is empty!");
        }
        //end of program
        long endTime = System.currentTimeMillis();
        //waiting for the previous thread to finish.
        try{
            for(Thread thread : threads){
                thread.join();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //output
        System.out.println("Copied " + count + " files (" + countBytes + " bytes) in " + (endTime - startTime) + " milliseconds.");
    }
}
