package homework;

/**
 * MyRunnable implements Runnable to implement the count up
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class MyRunnable implements Runnable{

    /**
     * Required fields
     */
    private int number,count;

    /**
     * Constructor
     *
     * @param count thread number
     * @param number number till we have to print
     */
    public MyRunnable(int count,int number) {
        this.number = number;
        this.count = count;
    }

    /**
     * Runs the count from 1 to n and prints it.
     */
    @Override
    public void run() {
        for(int i = 1; i < number + 1; i++){
            System.out.println(i);
            //System.out.println("Thread " + count + ": " + i);
        }
    }
}
