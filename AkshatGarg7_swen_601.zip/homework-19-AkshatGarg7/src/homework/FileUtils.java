package homework;
import java.io.*;

/**
 * FileUtils is a utility file for FileCopier.
 *
 * @author Akshat Garg ag2193@rit.edu
 */
public class FileUtils{
    private static int sum;

    /**
     * Copies file from source path to given destination path
     *
     * @param source from where file to copied
     * @param destination to where file has to be copied
     * @throws IOException throws IOException according to case
     */
    public static void copyFile(String source, String destination) throws IOException {
        FileInputStream fin = new FileInputStream(source);
        FileOutputStream fout = new FileOutputStream(destination);
        byte[] buffer = new byte[10240]; //creating a custom buffer

        int n = 1;
        //Reading and copying the file until it ends.
        while(n > 0){
            n = fin.read(buffer);
//            sum += n;
            if(n > 0) {
                fout.write(buffer, 0, n);
            }
        }
        //closing the files
        fin.close();
        fout.close();
    }

    /**
     * Clears the given directory by recursively
     *
     * @param name Directory to be emptied
     * @throws IOException throws IOException according to case
     */
    public static void clearDirectory(String name) throws IOException {
        //if input directory file is empty
        if(name.equals("") || name.equals(" ")){
            throw new FileNotFoundException("Directory name cannot be empty!");
        }
        File file = new File(name);
        //finding file path of each file or directory in given directory
        for(File subfile : file.listFiles()){
            //if directory is found we recursively delete files inside it.
            if(subfile.isDirectory()){
                clearDirectory(subfile.getAbsolutePath());
            }
            if(!subfile.delete()){ //if it fails to delete file in directory it throws and error
                throw new IOException("Failed to delete " + subfile.getAbsolutePath());
            }
        }
    }

    /**
     * Main method to test copyFile and clearDirectory
     * @param args none
     * @throws IOException throws IOException according to case
     */
    public static void main(String[] args) throws IOException{
        copyFile("input/words.txt","output/foo.txt");
        clearDirectory("output");
    }
}
