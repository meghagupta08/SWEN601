package homework;
import java.io.File;
import java.io.IOException;

/**
 * FileCopier clears the destination
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class FileCopier {
    /**
     * Main method
     *
     * @param args source and destination directory
     */
    public static void main(String[] args) {
        /**
         * checking if 2 arguments are passed or not
         */
        if(args.length != 2){
            System.out.println("Usage: java homework.FileCopier <input dir> <output dir>");
            System.exit(1);
        }
        String source = args[0];
        String destination = args[1];

        //start of program
        long startTime = System.currentTimeMillis();

        /**
         * Clearing the output directory
         */
        try {
            System.out.println("Clearing directory '" + destination + "'.");
            FileUtils.clearDirectory(destination);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        /**
         * Copying file from source to destination
         */
        File searchPath = new File(source);
        int count = 0;
        long countBytes = 0;
        File[] files = searchPath.listFiles();
        if(files != null){ //directory is not empty check
            for (File file : files) {
                //If a directory is found inside the source directory we will skip it
                if (file.isDirectory()) {
                    System.out.println("    Skipping directory '" + file.getName() + "'...");
                    continue;
                }
                try { //copying each file from source to destination
                    System.out.println("    Copying file '" + file.getName() + "'...");
                    FileUtils.copyFile(file.getAbsolutePath(), destination + "\\" + file.getName());
                    count++;
                    countBytes += file.length();
                } catch (IOException e) {
                    e.printStackTrace();
                    System.exit(1);
                }
            }
        }else{ //if source directory is empty!
            throw new NullPointerException("Source Directory is empty!");
        }
        //end of program
        long endTime = System.currentTimeMillis();
        //output
        System.out.println("Copied " + count + " files (" + countBytes + " bytes) in " + (endTime - startTime) + " milliseconds.");
    }
}
