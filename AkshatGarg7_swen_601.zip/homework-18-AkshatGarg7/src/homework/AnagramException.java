package homework;
/**
 * Custom checked Exception for the class Anagram
 *
 * @author Akshat Garg ag2193@rit.edu
 */
public class AnagramException extends Exception{
    /**
     * Constructor that returns AnagramException with a message and cause because it caused by another exception.
     *
     * @param message error message
     * @param cause cause of message
     */
    public AnagramException(String message,Throwable cause){
        super(message,cause);
    }

    /**
     * Constructor that returns AnagramException with a message.
     *
     * @param message error message
     */
    public AnagramException(String message){
        super(message);
    }
}
