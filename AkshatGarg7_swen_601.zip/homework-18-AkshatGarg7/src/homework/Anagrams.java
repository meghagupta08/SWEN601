package homework;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Anagrams finds all the word which has same characters as given word.
 *
 * @author Akshat Garg ag2193@rit.edu
 */
public class Anagrams {
    /**
     * readWords returns a set of unique words in the given files.
     * All the words are converted to lowercase so that no two words with different case repeats.
     *
     * @param filename source filepath
     * @return collection of unique set of words in source file
     * @throws AnagramException throws exception based on case
     */
    public static Collection<String> readWords(String filename) throws AnagramException {
        HashSet<String> unique = new HashSet<>(); //collections of unique words
        //if no filepath is given
        if(filename.equals("") || filename.equals(" ")){
            throw new AnagramException("Source path cannot be empty!");
        }
        //if the file doesn't end ".txt" it is not possible to process
        if(!filename.contains(".txt")){
            throw new AnagramException(".txt file supported only!");
        }
        //try-with-resource
        try(FileReader fileReader = new FileReader(filename)){
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            List<String> lists= bufferedReader.lines().collect(Collectors.toList());//reading all the lines and converting to a list
            for(String list : lists){
                // converting each word in list to lowercase and splitting at " " so that
                // if line contains more than 1 word it is considered as 2+ words
                String[] split = list.toLowerCase().split("\\s+");
                //adding to the collection
                unique.addAll(Arrays.asList(split));
            }
        } catch (FileNotFoundException e) { //file not found error
            throw new AnagramException("File Not Found!",e);
        } catch (IOException e) { // file was never opened error
            throw new AnagramException("File was never opened!",e);
        }
        return unique;
    }

    /**
     * sortWords returns a string of the word given in sorted order
     *
     * @param string to be sorted
     * @return a string of the word given in sorted order
     */
    public static String sortWord(String string){
        ArrayList<Integer> wordToNumber = new ArrayList<>();
        byte[] bytes = string.getBytes(StandardCharsets.US_ASCII); // converting to bytes
        Arrays.sort(bytes); //sorting it
        return new String(bytes);
    }

    /**
     * makeAnagrams returns a map of strings with key as sorted order of word in set
     * and value as all the possible anagrams of the word
     *
     * @param unique collection of all the words in the source file
     * @return map of unique with key as sorted word in unique set and value as all the possible anagrams of the word
     */
    public static Map<String,List<String>> makeAnagrams(Collection<String> unique){
        Map<String,List<String>> map = new HashMap<>();
        for(String word: unique){
            String sorted = sortWord(word);
            if(!map.containsKey(sorted)){//if the sortWord(word) doesn't exist in map we create new key and initialize the list of value
                map.put(sorted,new ArrayList<>());
            }
            map.get(sorted).add(word);//anagrams of word are to key of word
        }
        return map;
    }

    /**
     * writeAnagrams writes the map to given destination filepath
     *
     * @param map map returned from makeAnagrams
     * @param destination filepath where we have to write
     * @throws AnagramException throws exception based on case
     */
    public static void writeAnagrams(Map<String,List<String>> map, String destination) throws AnagramException{
        //if no filepath is given
        if(destination.equals("") || destination.equals(" ")){
            throw new AnagramException("Destination path cannot be empty!");
        }
        //if the file doesn't end ".txt" it is not possible to process
        if(!destination.contains(".txt")){
            throw new AnagramException(".txt file supported only!");
        }
        try(FileWriter fileWriter = new FileWriter(destination)){
            PrintWriter pw = new PrintWriter(fileWriter);
            for(Map.Entry<String,List<String>> entry: map.entrySet()){
                Collections.sort(entry.getValue()); //sorting the values for given key
                List<String> list = entry.getValue();
                int i = 0;
                StringBuilder sb = new StringBuilder();
                while(i < list.size() - 1){
                    sb.append(list.get(i)).append(" ");
                    i++;
                }
                sb.append(list.get(list.size() - 1));
                pw.println(entry.getKey() + " " + sb);
            }
            pw.flush();//flushing all the things in memory to file
        } catch (IOException e) { //Filepath not found
            throw new AnagramException("File Not Found! Empty destination file path!",e);
        }
    }

    public static void main(String[] args){
        try {
            String input = args[0];
            String output = args[1];
            Collection<String> set = readWords(input);
            Map<String,List<String>> map = makeAnagrams(set);
            writeAnagrams(map,output);
            Scanner s = new Scanner(System.in);
            while(true) {
                System.out.print("Enter the word for which Anagrams should be printed: ");
                String line = s.nextLine();
                String temp = sortWord(line);
                if (line.equals(" ")) { //condition to quit
                    break;
                }
                if (!map.containsKey(temp)) { //if the word Key doesn't exist in the map
                    System.out.println("Word doesn't exist! Enter new word.");
                } else {
                    Collections.sort(map.get(temp));
                    List<String> list = map.get(temp);
                    StringBuilder sb = new StringBuilder();
                    int i = 0;
                    while(i < list.size() - 1){
                        sb.append(list.get(i)).append(" ");
                        i++;
                    }
                    sb.append(list.get(list.size() - 1));
                    System.out.println(sb);
                    //System.out.println("Anagrams for word \"" + line + "\": " + sb);
                }
            }
        } catch (AnagramException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}