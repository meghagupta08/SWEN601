package activities;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReaderExample {
    public static void main(String[] args) throws IOException {
        FileReader reader = new FileReader("out.txt");
        BufferedReader br = new BufferedReader(reader);

//        char[] buffer = new char[25];
//        int number = reader.read(buffer);
//        System.out.println("number: " + number);
//        String string = new String(buffer);
//        System.out.println(string);
        String line =br.readLine();
        while(line!=null){
            System.out.println(line);
            line = br.readLine();
        }
    }
}
