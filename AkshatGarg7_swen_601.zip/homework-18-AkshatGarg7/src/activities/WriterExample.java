package activities;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class WriterExample {
    public static void main(String[] args) throws IOException {
        FileWriter writer = new FileWriter("out.txt");
        PrintWriter pw = new PrintWriter(writer);

//        writer.write("Hello, World!");
//        writer.write("\nHow are you today?");
//        writer.write("\nGoodBye!");
//
//        writer.flush();

        pw.println("Hello, World!");
        pw.println("\nHow are you today?");
        pw.println("\nGoodBye!");
        pw.flush();
    }
}
