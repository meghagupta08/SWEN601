package activities;

public class BadMoveException extends Exception {
    public BadMoveException(String message){
        super(message);
    }
    public BadMoveException(Throwable cause){
        super(cause);
    }
    public BadMoveException(String message,Throwable cause){
        super(message,cause);
    }
}
