package activities;

public enum Piece {
    BLACK("B"),
    WHITE("W");

    private final String symbol;

    Piece(String symbol) {
        this.symbol = symbol;
    }

    public String getSymbol() {
        return symbol;
    }

    public Piece flip(){
        if(this==WHITE){
            return BLACK;
        }else{
            return WHITE;
        }
    }
}
