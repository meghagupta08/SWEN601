package activities;

public class Square {
    private Piece piece;

    public Square(){
        this.piece = null;
    }

    public void occupy(Piece piece) throws BadMoveException{
        if(isOccupied()){
            throw new BadMoveException("Square already Occupied.");
        }
        this.piece = piece;
    }

    public boolean isOccupied(){
        return piece != null;
    }

    public void flip() throws BadMoveException{
        if(piece == null){
            throw new BadMoveException("You can't flip an empty Square!");
        }
        piece.flip();
    }

    @Override
    public String toString(){
        return isOccupied()? piece.getSymbol() : " ";
    }
}
