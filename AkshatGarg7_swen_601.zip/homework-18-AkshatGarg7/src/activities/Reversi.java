package activities;

public class Reversi {
    public static void main(String[] args){
        Square square = new Square();

        try {
            square.occupy(Piece.BLACK);
            square.flip();
            square.occupy(Piece.BLACK);
        } catch (BadMoveException e) {
            System.out.println("You made a bad move! Try again.");
            e.printStackTrace();
        } finally{
            System.out.println("Finally!");
        }
    }
}
