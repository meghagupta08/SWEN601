package homework;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import static homework.Anagrams.*;

/**
 * Unit Test for Anagram Class
 *
 * @author Akshat Garg ag2193@rit.edu
 */
class AnagramsTest {
    /**
     * Check if everything works in readWords
     *
     * @throws AnagramException no exception in this part
     */
    @Test
    public void fileInputTrue() throws AnagramException {
        //setup
        String filename = "singleWordPerLine.txt";
        String expected = "[how, tea, world, ate, eta, are, goodbye, eat, tae, hello, you]";

        //invoke
        Collection<String> set = readWords(filename);
        String actual = set.toString();

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Test for readWords if ".txt" file not supplied
     */
    @Test
    public void fileInputNotTxt() {
        //setup
        String filename = "in";
        //assert
        try {
            readWords(filename);
        } catch (AnagramException e) {
            assertEquals(e.getMessage(),".txt file supported only!");
        }
    }

    /**
     * Test for readWords if blank file supplied
     */
    @Test
    public void fileInputBlank() {
        //setup
        String filename = "";
        //assert
        try {
            readWords(filename);
        } catch (AnagramException e) {
            assertEquals(e.getMessage(),"Source path cannot be empty!");
        }
    }

    /**
     * Test for readWords if file supplied does not exist
     */
    @Test
    public void fileInputFalse() {
        //setup
        String filename = "input.txt";
        //assert
        try {
            readWords(filename);
        } catch (AnagramException e) {
            assertEquals(e.getMessage(),"File Not Found!");
        }
    }


    /**
     * Test for readWords if file supplied does contain multiple words and random caps words
     */
    @Test
    public void fileInputMultipleWordPerLine() throws AnagramException {
        //setup
        String filename = "in.txt";
        String expected = "[goodbye, good, how, tea, world, ate, eta, are, today, eat, tae, hello, you]";

        //invoke
        Collection<String> set = readWords(filename);
        String actual = set.toString();

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Test for sortWord
     */
    @Test
    public void sortedWord(){
        //setup
        String input = "tea";
        String expected = "aet";

        //invoke
        String actual = sortWord(input);

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Test for makeAnagrams
     */
    @Test
    public void makeAnagram() throws AnagramException {
        //setup
        String filename = "singleWordPerLine.txt";
        String expected = "{how=[how], aet=[tea, ate, eta, eat, tae], bdegooy=[goodbye], ouy=[you], ehllo=[hello], dlorw=[world], aer=[are]}";
        //invoke
        Collection<String> set = readWords(filename);
        Map<String,List<String>> map = makeAnagrams(set);
        String actual = map.toString();

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Test for writeAnagram if everything works or not
     */
    @Test
    public void writeAnagramTrue() throws AnagramException {
        //setup
        String filename = "foo.txt";
        String expected = "how how\n" +
                "aet ate eat eta tae tea\n" +
                "bdegooy goodbye\n" +
                "ouy you\n" +
                "adoty today\n" +
                "dgoo good\n" +
                "ehllo hello\n" +
                "dlorw world\n" +
                "aer are\n";

        //invoke
        Collection<String> set = readWords("in.txt");
        Map<String,List<String>> map = makeAnagrams(set);
        writeAnagrams(map,filename);
        StringBuilder sb = new StringBuilder();
        try(FileReader fr = new FileReader(filename)){
            BufferedReader br = new BufferedReader(fr);
            String line = br.readLine();
            while(line != null){
                sb.append(line).append("\n");
                line = br.readLine();
            }
        } catch (FileNotFoundException e) { //file not found error
            throw new AnagramException("File Not Found!",e);
        } catch (IOException e) { // file was never opened error
            throw new AnagramException("File was never opened!",e);
        }
        String actual = sb.toString();

        //assert
        assertEquals(expected,actual);
    }

    /**
     * Test for makeAnagrams if ".txt" file not supplied
     */
    @Test
    public void makeAnagramNotTxt() {
        //setup
        String filename = "in";
        //assert
        try {
            Collection<String> set = readWords("in.txt");
            Map<String,List<String>> map = makeAnagrams(set);
            writeAnagrams(map,filename);
        } catch (AnagramException e) {
            assertEquals(e.getMessage(),".txt file supported only!");
        }
    }

    /**
     * Test for makeAnagrams if blank file supplied
     */
    @Test
    public void makeAnagramBlank() {
        //setup
        String filename = "";
        //assert
        try {
            Collection<String> set = readWords("in.txt");
            Map<String,List<String>> map = makeAnagrams(set);
            writeAnagrams(map,filename);
        } catch (AnagramException e) {
            assertEquals(e.getMessage(),"Destination path cannot be empty!");
        }
    }
}