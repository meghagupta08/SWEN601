package myactivities;

public class primitives {
    public static void main(String[] args) {
        int w = 5;
        double x = 5.0;
        int y = w;
        int z = 4;

        System.out.println(w == w);
        System.out.println(w == 5);
        System.out.println(w == x);
        System.out.println(w == y);
        System.out.println(w == z);
    }
}
