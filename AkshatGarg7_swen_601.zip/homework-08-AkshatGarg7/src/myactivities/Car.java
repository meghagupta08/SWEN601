package myactivities;

import activities.car;

public class Car {

    private Make make;
    private String model;
    private int year;
    private String color;
    private String vin;
    private static int CarCount = 0;

    public Car(Make make, String model, int year, String color, String vin){
        this.make = make;
        this.model = model;
        this.year = year;
        this.color = color;
        this.vin = vin;
        CarCount++;
    }

    public Make getMake(){
        return make;
    }
    public String getModel(){
        return model;
    }
    public int getYear(){
        return year;
    }
    public String getColor(){
        return color;
    }
    public String getVin(){
        return vin;
    }
    public int getCarCount(){
        return CarCount;
    }

    public void setColor(String color){
        this.color = color;
    }

    @Override
    public String toString(){
        return "Car[make= " + make
                +" ,model= " + model
                +" ,year= " + year
                +" ,color= " + color
                +" ,vin= " + vin
                +"]";
    }

    @Override
    public boolean equals(Object o){
        if(o instanceof Car){
            Car c = (Car) o;
            return this.vin.equals(c.vin);
        }
        else{
            return false;
        }
    }

    public static void main(String[] args) {
        System.out.println(Car.CarCount);
        Car car1 = new Car(Make.Dodge, "Dart", 2013, "red", "1234ABCD5");
        System.out.println(car1);
        System.out.println(Car.CarCount);
        Car car2 = new Car(Make.Dodge, "Dart", 2013, "red", "1234ABCD5");
        //System.out.println(car2);
        System.out.println(Car.CarCount);
        Car car4 = new Car(Make.Audi, "D200", 2003, "Black", "123ABC5");
        System.out.println(Car.CarCount);
        System.out.println(CarCount);
        //System.out.println(Car.getCarCount());

        //System.out.println(car1 == car2);
        Car car3 = car1;
        System.out.println(car1 == car3);

        //System.out.println(car1.equals(car2));
        //System.out.println(car1.equals(car4));
    }

}
