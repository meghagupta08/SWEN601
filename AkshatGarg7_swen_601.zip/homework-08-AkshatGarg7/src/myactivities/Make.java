package myactivities;

public enum Make {
    Ford,Dodge,Audi,BMW,Maruti;
}
