package myactivities;

import java.util.Scanner;

public class StringTester {
    public static void main(String[] args) {
        String x = "Buttercup";
        String y = "Buttercup";
        String z = "Thunder";

        System.out.println(x == x);
        System.out.println(x == y);
        System.out.println(x == z);

        Scanner s = new Scanner(System.in);
        String a = s.next();
        String b = s.next();
        s.close();

        System.out.println(a == b);

    }

}
