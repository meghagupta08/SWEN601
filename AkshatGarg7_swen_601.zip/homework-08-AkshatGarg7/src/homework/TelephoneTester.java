package homework;

import java.util.Objects;

/**
 * Class TelephoneTester tests the other classes in the package by calling them
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class TelephoneTester {
    public static void main(String[] args) {
        //new telephones
        Telephone t1 = new Telephone(Types.mobile);
        Telephone t2 = new Telephone(Types.landline);
        Telephone t3 = new Telephone(Types.satellite);
        //testing out
        System.out.println(t1.getNumber());
        System.out.println(t2.getNumber());
        System.out.println(t1.redial());
        t1.setNumbertodial(t2.getNumber());
        System.out.println(t1.dial());
        System.out.println(t1.disconnect());
        System.out.println(t1.redial());
        System.out.println(t1.disconnect());
        t1.setNumbertodial(t3.getNumber());
        System.out.println(t1.dial());
        System.out.println(t1.disconnect());
        System.out.println(t1.redial());
        System.out.println(t1.disconnect());
        System.out.println("Recently Dial-> " + t1.displayDials());
        System.out.println(t1);
        t2.setNumbertodial(t3.getNumber());
        System.out.println(t2.dial());
        System.out.println(t2.disconnect());
        System.out.println(Telephone.totalDials);
        System.out.println(t1.equals(t2));
    }
}
