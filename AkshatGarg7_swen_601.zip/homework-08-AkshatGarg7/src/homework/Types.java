package homework;

/**
 * Enum Types makes an enum of different types of phone
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public enum Types {
    landline, mobile, satellite;
}
