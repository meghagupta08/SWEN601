package homework;
import java.util.ArrayList;
import java.lang.*;

/**
 * Class Telephone initiates a constructor to create a new phone with defined Types of phone from enum list and assigns
 * a new number to it.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class Telephone {
    // fields initiating
    private Types type;
    private long number, numbertodial;
    private static long newNumber = 0;
    private boolean oncall = false;
    private boolean redialnumber;
    private ArrayList<Long> recentDials;
    public static long totalDials = 0;

    /**
     * Creates a new constructor and assigns new number to it.
     *
     * @param type type of the phone used
     */

    public Telephone(Types type) {
        this.type = type;
        this.number = 5550001; //default starting value of any new number
        this.number += newNumber;
        newNumber++;
        redialnumber = false; // initially no number to redial
        this.recentDials = new ArrayList<>(); // Assigning an array list to store all the number dialed.
    }

    /**
     * Returns the number assigned to the phone
     *
     * @return assigned number to the phone
     */

    public long getNumber() {
        return this.number; // returns the assigned number
    }

    /**
     * getTotalDials returns total dials made by every phone using Telephone class.
     *
     * @return total dials made by every phone.
     */

    public static long getTotalDials(){
        return totalDials; // total dials using Telephone class
    }

    /**
     * setNumbertodial takes input of number that has to be dialed or disconnected.
     *
     * @param numbertodial telephone number to be dialed or disconnected.
     */

    public void setNumbertodial(long numbertodial) {
        this.numbertodial = numbertodial; // number to be dialed or disconnected
    }

    /**
     * Method dial(), dials the number set by user and checks the conditions, such as, if it is same number it will return error
     * or if you are already on call it will return error or else if all previous conditions are false then it will dial
     * the number and return same.
     *
     * @return String based on condition met
     */

    public String dial() {
        this.redialnumber = true; // redial will be true as number has been dialed
        this.recentDials.add(numbertodial); // added the dialed number to list
        totalDials++; // increasing total dials by 1
        if (this.numbertodial == this.number) { // same number condition
            return "Error: You called your own number " + this.number;
        } else if (oncall) { // if already on call condition
            return "Error: Call Already in progress!";
        } else { //if above condition are false, it will call the number
            oncall = true; // set the oncall status true
            return this.number + " is calling " + numbertodial;
        }
    }

    /**
     * If the user is not on call it will return error or else will disconnect the call from the telephone number
     * entered previously
     *
     * @return String based on condition
     */

    public String disconnect() {
        if (!oncall) { // no call condition
            return "Error: No call in progress!";
        } else { // if on call it will disconnect
            oncall = false; // set the oncall status as false
            return "Call ended between you " + this.number + " and " + this.numbertodial;
        }
    }

    /**
     * If there is no number dialed previously will throw an error or else will redial the last number
     *
     * @return based on condition met, if number was called, redial will use dial() function to call again.
     */

    public String redial() {
        if (!redialnumber) { // if no number is dialed, so no redial
            return "Error: No number to redial!";
        } else { // calls dial() if there is any number was dialed
            return dial();
        }
    }

    /**
     * Returns the last 10 or less number called by user phone from most recent calls.
     *
     * @return the last 10 or less number called from most recent to least.
     */

    public ArrayList<Long> displayDials(){
        ArrayList<Long> a = new ArrayList<Long>(); //Creating a new array list to store reverse of list 
        if(recentDials.size() < 11) { // iff size is less than or equal to 10 
            for (int i = recentDials.size() - 1; i >= 0; i--) {
                a.add(recentDials.get(i));// storing dials in reverse order

            }
            return a;
        }
        else{
            ArrayList<Long> b = new ArrayList<Long>(); // creating new list to store value 
            for (int i = recentDials.size() - 1; i >= 0; i--) {
                a.add(recentDials.get(i)); //reversing first 
            }
            for(int j = 0; j < 10; j++){
                b.add(a.get(j)); // adding elements upto 10 
            }
            return b;
        }
    }

    /**
     * returns a formatted toString method.
     *
     * @return formatted toString String.
     */

    @Override
    public String toString(){ // String format for desired output string
        return "Telephone[PhoneNumber= " + this.number
                +" ,PhoneType= " + this.type
                +" ,RecentlyDialed= " + (!redialnumber ? "None" : numbertodial)
                +"]";
    }

    /**
     * If object and parameter t has same number it will return true else false.
     *
     * @param o Object with which we have to compare
     * @return boolean if number is same returns true else false.
     */

    @Override
    public boolean equals(Object o){
        if(o instanceof Telephone){
            Telephone t = (Telephone) o;
            return this.number == t.number; //as it long type we can directly compare
        }
        else{
            return false;
        }
    }
}

