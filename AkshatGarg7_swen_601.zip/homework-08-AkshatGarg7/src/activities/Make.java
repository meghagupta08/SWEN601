package activities;

public enum Make
{
    FERRARI,
    FORD,
    AUDI,
    BMW,
    MARUTI
}
