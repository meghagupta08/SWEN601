package activities;

public class primitives
{
    public static void main(String[] main)
    {
        int x=5;
        int y =5;
        System.out.println(x==y);

        float a = 5.0f;
        System.out.println(x==a);
        float b = 5.1f;
        System.out.println(x==b);
        double c = 1.00000000000000001;
        double d = 1;
        System.out.println(c==d);

    }
}
