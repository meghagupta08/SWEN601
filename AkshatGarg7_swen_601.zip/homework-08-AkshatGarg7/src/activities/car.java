package activities;

import javax.swing.plaf.synth.SynthTextAreaUI;

public class car
{
    private Make make;
    private String model;
    private int year;
    private String colour;
    private String vin;
    private static int carCount=0;

    public car(Make make, String model, int year, String colour, String vin)
    {
        this.make = make;
        this.model = model;
        this.year = year;
        this.colour = colour;
        this.vin = vin;
        carCount++;
    }

    public Make getMake()
    {
        return make;
    }
    public String getModel()
    {
        return model;
    }
    public int getYear()
    {
        return year;
    }
    public String getColour()
    {
        return colour;
    }
    public String getVin()
    {
        return vin;
    }
    public void setColour(String colour)
    {
        this.colour=colour;
    }
    @Override
    public String toString()
    {
        return "Car {"
                +"Make: "+ this.make
                +", Model: "+ this.model
                +", Year: "+ this.year
                +", Colour: "+ this.colour
                +", VIN: "+ this.vin
                +"}";

    }
    @Override
    public boolean equals(Object o)
    {
        if(o instanceof car)
        {
            car c = (car) o;
            return this.vin.equals(c.vin);
        }
        else
        {
            return false;
        }
    }
    public static int getCarCount()
    {
        return carCount;
    }
    public static void main(String[] args)
    {
        car car1 = new car(Make.AUDI, "Q3", 2023, "White", "123ABC4");
        car car2 = new car(Make.BMW, "D200", 2003, "Black", "123ABC5");
        System.out.println(car1 + "\n" + car2);
        //System.out.println(car1.equals(car2));
        //System.out.println(car1.carCount);
        //when using static variable use class name(car) not instance name(car1/car2/....).
        System.out.println(car.carCount); //static variable is common for all, has overall car count
        System.out.println(car.getCarCount()); //getter
    }

}
