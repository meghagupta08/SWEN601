package activities;

import java.util.Scanner;

public class stringTester
{
    public static void main(String[] args)
    {
        String a = "Buttercup";
        String b = "Buttercup";
        String c = "Thunder";
        String d = "Butter"+"cup";
        String e = "Butter";
               e = e+ "cup";
        System.out.println(a == b);
        System.out.println(b == c);
        System.out.println(b == d);
        System.out.println(b == e);
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the string");
        String first = sc.nextLine();
        System.out.println("Enter the string");
        String second = sc.nextLine();
        System.out.println(first==second);

        }
    }
