package homework;
import java.util.Scanner;
import java.util.Arrays;

/**
 * Class SievePrime uses the Sieve of Eratosthenes to find weather which number are prime
 * or non-prime between 2 to n. We return the first n prime numbers using Sieve of Eratosthenes.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class SievePrime {

    /** Function Sieve returns a string which contains all the first n prime number
     * <p>
     * Function takes boolean array 'prime' and number of n prime number is parameter,
     * it counts the first n prime number which is equal to size, by checking which element
     * is true or false, if it is true we store the index at which the element is true and
     * save it in new array. this index is our prime number. Function converts this array to string and
     * returns it as output.
     *
     * @param prime boolean array, contains weather a number is true or false.
     * @param size inter type, to print how many first n prime numbers to print
     * @return string, which contains all first n prime numbers
     */
    public static String Sieve(boolean[] prime, int size){

        int[] a = new int[size]; // creating a new
        int count = 0;
        for(int x = 0; x <= 10000000; x++){ //running through array to find which is true or false
            if (count < size ){
                if (prime[x]){ //if the element is true
                    a[count] = x; // we save the index in an array which is a prime number
                    count ++; //incrementing by 1

                }
            }
        }
        String b = Arrays.toString(a); // converting array to string
        return "\nThe first " + size +" prime numbers are -> " + "\n" + b; //output return

    }

    /**
     * Function main takes the input from user for upto what first n prime numbers we need for output.
     * We first create a boolean of size of 10000000 and set every value to true initially, we then traverse through
     * the list and find which are prime or not by letting prime stay true and others false. We will run through 2 to
     * square root of 10000000, because it is more efficient and cache friendly. We check in loop if the chosen element is true or not
     * , if it is true then we change all the multiples from 2 to 10000000 of that elements to false as they wont be prime.
     * We print out the output by calling the method and also print the execution time.
     *
     * @param args none
     */

    public static void main(String[] args) {

        System.out.print("Enter the number you need to print: ");
        Scanner s = new Scanner(System.in);
        int size = s.nextInt();
        s.close();

        long startTime = System.currentTimeMillis(); // timer start
        boolean[] prime = new boolean[10000001]; // creating a boolean array of size 10000001
        for (int i = 0; i <= 10000000; i++){ // converting all the element value to true
            prime[i] = true;
        }
        prime[0] = false; // as 0 and 1 are non prime
        prime[1] = false;

        for (int i = 2; i*i <= 10000000; i++) { // iterating from 2 to square root of 10000000
            if (prime[i]) { //if it is true, we check for multiples of i
                for (int j = i; j*i <= 10000000; j ++) { // checking for all the multiples from i to 10000000 and changing them to false
                    prime[j*i] = false;
                }
            }
        }

        System.out.println(Sieve(prime,size)); // calling the method
        long endTime = System.currentTimeMillis(); // timer ends
        System.out.println("\nIt took " + (endTime - startTime) + " ms"); // execution time


    }
}//end of class
