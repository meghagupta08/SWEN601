package homework;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Class PrimeDifferentLoop uses 'for', 'while' and 'do-while' loop to return n prime numbers.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class PrimeDifferentLoop {

    /**Function PrimeFor uses 'for' loop to return weather an integer is Prime or not.
     * <p>
     * The function initially considers the integer as prime. We know 2 is the prime number, so eliminate every even number first,
     * and then we start checking for odd integer, for this we use 'for' loop to iterate every number from 3 to n/2
     * (as any number greater than n/2 will not be divisible) and use condition if(n % i == 0) and if it true then number is not prime,
     * and we break out of it immediately.
     *
     * @param n long type, integer to be checked
     * @return boolean type, if it is prime it will return true else false
     */

    public static Boolean PrimeFor(long n) {
        boolean flag = true; //initially every integer is prime
        if (n % 2 == 0){ // if it is even or not
            flag = false;
        }
        else {
            for (int i = 3; i < (n / 2); i++) { // iterating from 3 to n/2
                if (n % i == 0) { // checking integer is divisible by any other number or not
                    flag = false;// divisible
                    break; // we break immediately as soon as we find it is not prime
                }
            }
        }
        return flag; // return statement
    }

    /**Function PrimeWhile uses 'while' loop to return weather an integer is Prime or not.
     * <p>
     * The function initially considers the integer as prime. We know 2 is the prime number, so eliminate every even number first,
     * and then we start checking for odd integer, for this we use 'while' loop to iterate every number from 3 to n/2
     * (as any number greater than n/2 will not be divisible) and use condition if(n % i == 0) and if it true then number is not prime,
     * and we break out of it immediately.
     *
     * @param n long type, integer to be checked
     * @return boolean type, if it is prime it will return true else false
     */

    public static Boolean PrimeWhile(long n){
        boolean flag = true;//initially every integer is prime
        if (n%2 == 0){ // if it is even or not
            flag = false;
        }
        else {
            int i = 3;
            while(i < n/2){ // iterating from 3 to n/2
                if(n%i == 0){// checking integer is divisible by any other number or not
                    flag = false;// divisible
                    break;// we break immediately as soon as we find it is not prime
                }
                i++;//incrementing by 1
            }
        }
        return flag;// return statement
    }

    /**Function PrimeFor uses 'do-while' loop to return weather an integer is Prime or not.
     * <p>
     * The function initially considers the integer as prime. We know 2 is the prime number, so eliminate every even number first,
     * and then we start checking for odd integer, for this we use 'do-while' loop to iterate every number from 3 to n/2
     * (as any number greater than n/2 will not be divisible) and use condition if(n % i == 0) and if it true then number is not prime,
     * and we break out of it immediately.
     *
     * @param n long type, integer to be checked
     * @return boolean type, if it is prime it will return true else false
     */

    public static Boolean PrimeDo(long n){
        boolean flag = true;//initially every integer is prime
        if (n%2 == 0){ // if it is even or not
            flag = false;
        }
        else{
            int i = 3;//initializing
            do{
                if(n%i == 0){// checking integer is divisible by any other number or not
                    flag = false;// divisible
                    break;// we break immediately as soon as we find it is not prime
                }
                i++;//incrementing by 1
            }while(i< n/2);//as soon as i >= n/2 the loop will break and give return value
        }
        return flag;// return statement
    }

    /**
     * Function main takes the input from user and sees which loop the user has asked for, i.e., 'for','while' and 'do-while'.
     * Once the parameter matches it goes inside the counting loop, in which it counts until we get first n prime numbers,
     * and shows the output as string array. If user types '0' the program exits, otherwise the program continues to run.
     * It will also display the time it took to run the program each time user inputs new input.
     *
     * @param args none
     */
    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        System.out.println("To print the first N prime numbers using one of the following "); // input instructions
        System.out.println("please enter input like this: \n1) For loop -> <number of prime numbers> f");
        System.out.println("2) While loop -> <number of prime numbers> w\n3) Do While loop -> <number of prime numbers> d");
        while(true){ //infinite loop, unless exit condition is met
            System.out.print("\nEnter the input or type \"0\" to exit: "); // some more input instruction
            int i = 3, count = 1;
            int x = s.nextInt(); // scanning for the integer
            if (x == 0){ // exit condition
                break;
            }
            else{
                char loop = s.next().charAt(0); //scanning for char
                long startTime = System.currentTimeMillis(); //timer start
                int[] arrayPrime = new int[x]; // new integer array
                arrayPrime[0] = 2; // setting 1st element as 2 as 2 is always prime
                while(true){// counter loop
                    if (count < x){ // checking if count is less than input
                        if(loop == 'f'){ //for loop condtion
                            if(PrimeFor(i)){
                                arrayPrime[count] = i; //if it is true it will store in array
                                count ++;
                            }
                            i++;

                        }
                        else if (loop == 'w'){//while loop condition
                            if(PrimeWhile(i)){
                                arrayPrime[count] = i; //if it is true it will store in array
                                count ++;
                            }
                            i++;

                        }
                        else if (loop == 'd'){//do-while condition
                            if(PrimeDo(i)){
                                arrayPrime[count] = i; //if it is true it will store in array
                                count ++;
                            }
                            i++;

                        }
                        else{
                            System.out.println("Please give correct input!"); //invalid input
                            long endTime = System.currentTimeMillis();//Timer stop
                            long Time = endTime - startTime;// difference
                            System.out.println("Total execution time is " + Time + " ms.");//output
                            break;
                        }
                    }
                    else{
                        String b = Arrays.toString(arrayPrime);//converting int array to string arr
                        System.out.print("Your first " + x + " prime numbers are -> "); //output
                        System.out.println(b);
                        long endTime = System.currentTimeMillis();// timer stop
                        long Time = endTime - startTime;//difference in time
                        System.out.println("Total execution time is " + Time + " ms.");//execution time
                        break;
                    }
                }
            }
        }
    }
}// End of Class

