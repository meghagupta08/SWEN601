package activites;

import java.util.Scanner;

public class CountDown {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the n: ");
        int n = s.nextInt();
        s.close();

        while(n >= 0){
            System.out.println(n);
            n--;
        }

        System.out.println("Done!");

        System.out.println((9));
    }

}
