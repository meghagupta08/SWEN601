package activites;

import java.util.Arrays;
import java.util.Scanner;

public class ArrayStuff {

    public static int[] makeArray(int size) {

        int[] A;
        A = new int[size];

        for(int i = 0; i < size;i++) {
            A [i] = i * 10;
        }
        return A;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the n: ");
        int n = s.nextInt();
        s.close();
        int[] A = makeArray(n);
        for(int i = 0; i < A.length; i++){
            System.out.println(A[i]);
        }

        String arrayString = Arrays.toString(A); //python way :p
        System.out.println(arrayString);

        for(int i : A){ // You cant skip any element LIMITATIONS
            System.out.println(i);
        }
    }
}
