/*
package activites;
import java.util.Arrays;
public class TwoDArray {
    public static void main(String[] args) {
        int [][] M = new int[10][10];
        for(int i = 0; i < 10; i++){
            for(int j; j < 10; j++){
                int value = (i+1)*(j+1);
                M[i][j] = value;
            }
        }
        String arrayString = Arrays.toString(M);
        System.out.println(arrayString);
    }

}
*/