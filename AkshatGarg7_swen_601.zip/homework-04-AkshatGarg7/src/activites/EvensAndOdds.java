package activites;

import java.util.Scanner;

public class EvensAndOdds {

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        int n;
        String loop;
        do {
            System.out.print("Enter the n: ");
            n = s.nextInt();
            System.out.println(n % 2 == 0? "Number is Even":"Number is odd");

        }
        while(n != 0);

    }
}