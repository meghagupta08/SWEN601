package activites;

import java.util.Scanner;

public class CountUp {
    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        System.out.print("Enter the n: ");
        int n = s.nextInt();
        s.close();
        for(int i = 0; i < n + 1; i++){
            System.out.println(i);
        }
        System.out.println("Done!");
    }
}
