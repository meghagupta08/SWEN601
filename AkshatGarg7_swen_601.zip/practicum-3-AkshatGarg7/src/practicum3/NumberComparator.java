package practicum3;

import java.util.Comparator;

public class NumberComparator implements Comparator<Element> {

    @Override
    public int compare(Element o1, Element o2) {
        return o1.getNumber() - o2.getNumber();
    }
}
