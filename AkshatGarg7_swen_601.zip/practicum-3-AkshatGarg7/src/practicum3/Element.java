package practicum3;

import java.util.Objects;

public class Element implements Comparable<Element>{
    private int number;
    private String name;
    private String symbol;
    private double weight;

    public Element(int number, String name, String symbol, double weight) {
        this.number = number;
        this.name = name;
        this.symbol = symbol;
        this.weight = weight;
    }

    public int getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public String getSymbol() {
        return symbol;
    }

    public double getWeight() {
        return weight;
    }

    @Override
    public String toString() {
        return "Element{" +
                "number=" + number +
                ", name='" + name + '\'' +
                ", symbol='" + symbol + '\'' +
                ", weight=" + weight +
                '}';
    }

    @Override
    public int compareTo(Element o) {
        return this.name.toLowerCase().compareTo(o.name.toLowerCase());
    }

    @Override
    public boolean equals(Object o){
        if(o instanceof Element){
            Element oe = (Element) o;
            return this.number == oe.number;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return (int) (this.number*this.weight);
    }
}
