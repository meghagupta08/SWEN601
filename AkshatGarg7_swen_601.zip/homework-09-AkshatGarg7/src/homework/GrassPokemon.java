package homework;

/**
 * The child class for Grass type Pokémon
 *
 * @author Akshat Garg ag2193@rit.com
 */

public class GrassPokemon extends Pokemon{

    /**
     * Creates a new Grass type Pokémon
     *
     * @param name name of Pokémon
     * @param type type of Pokémon, Grass type
     * @param attack attack value of Pokémon
     * @param health health point of Pokémon
     */

    public GrassPokemon(String name, PokemonType type, double attack, double health) {
        super(name, PokemonType.GRASS, attack, health);
    }

    /**
     * Checks and return damage modifier based on opponent Pokémon.
     *
     * @param type opponent Pokémon type
     * @return value of damage modifier
     */

    @Override
    public double modifier(PokemonType type) {
        if (type == PokemonType.FIRE) {
            return 0.5;
        } else if (type == PokemonType.WATER) {
            return 2.0;
        } else {
            return 1;
        }
    }
}
