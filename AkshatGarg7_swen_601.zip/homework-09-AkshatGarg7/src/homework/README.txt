a. How is this lab an example of reuse through inheritance?
Answer: In this lab, we have set common states and behaviour for pokemon in parent class Pokemon
. We can see child inherits all the behaviours and we also modified(Override) an existing behaviour
"modifiers" in each of the child class(FirePokemon, WaterPokemon, and GrassPokemon).


b. Which parts of the lab are examples of polymorphism?
Answer: Firstly, we can see that in Child Classes(FirePokemon, WaterPokemon, and GrassPokemon)
we used actual type name of child classes and reference type to parent class(Pokemon) in Arena
class and TestMain class. Secondly, when we change the value of modifier in child class, it
changes value in parent class during compilation of code, and we do this Arena class.