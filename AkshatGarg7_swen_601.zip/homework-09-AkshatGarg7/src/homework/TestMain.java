package homework;

import java.util.Random;
import java.util.Scanner;

/**
 * Runs the Pokemon class
 */

public class TestMain {

    /**
     * return a random Pokémon type from enum list
     *
     * @return random Pokémon type from enum list
     */

    public static PokemonType randomType() {
        Random r = new Random();
        return PokemonType.values()[r.nextInt(PokemonType.values().length)];
    }

    /**
     * Creates a random Pokémon by selecting random type, random attack value and random health point
     *
     * @param name name of Pokémon
     * @return Pokémon based on types, attack value or health point
     */

    public static Pokemon pokemonCreation(String name) {
        PokemonType x = randomType(); // randomly choosen type
        Random a = new Random();
        switch (x) { // based on type returns Pokemon details
            case FIRE:
                return new FirePokemon(name, x, (a.nextInt(50) + 50), (a.nextInt(500) + 500));
            case WATER:
                return new WaterPokemon(name, x, (a.nextInt(50) + 50), (a.nextInt(500) + 500));
            case GRASS:
                return new GrassPokemon(name, x, (a.nextInt(50) + 50), (a.nextInt(500) + 500));
            default:
                return new Pokemon(name, x, (a.nextInt(50) + 50), (a.nextInt(500) + 500));
        }
    }

    /**
     * Runs all the classes
     *
     * @param args None
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int answer;
        while (true) { // infinite loop
            Pokemon p1 = pokemonCreation("A"); // Pokemon 1
            Pokemon p2 = pokemonCreation("B"); // Pokemon 2
            Arena.battle(p1, p2); // battling out pokemons
            System.out.print("\nDo you wanna watch another Pokemon Battle?\nType \"1\" to watch another battle or \"2\" to stop watching battle");
            answer = s.nextInt(); // checking for input
            if (answer == 2){
                break;// exits the loop
            }
        }
    }
}