package homework;

/**
 * The enum for Pokémon types
 *
 * @author Akshat Garg ag2193@rit.com
 */

public enum PokemonType {
    NORMAL, FIRE, GRASS, WATER; // all pokemon types
}
