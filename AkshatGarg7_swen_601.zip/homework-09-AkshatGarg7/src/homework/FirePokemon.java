package homework;

/**
 * The child class for Fire type Pokémon
 *
 * @author Akshat Garg ag2193@rit.com
 */

public class FirePokemon extends Pokemon {

    /**
     * Creates a new Fire type Pokémon
     *
     * @param name name of Pokémon
     * @param type type of Pokémon, Fire type
     * @param attack attack value of Pokémon
     * @param health health point of Pokémon
     */

    public FirePokemon(String name, PokemonType type, double attack, double health) {
        super(name, PokemonType.FIRE, attack, health);
    }

    /**
     * Checks and return damage modifier based on opponent Pokémon.
     *
     * @param type opponent Pokémon type
     * @return value of damage modifier
     */

    @Override
    public double modifier(PokemonType type) {
        if (type == PokemonType.WATER) {
            return 0.5;
        } else if (type == PokemonType.GRASS) {
            return 2.0;
        } else {
            return 1;
        }
    }
}
