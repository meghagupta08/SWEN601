package homework;

/**
 * Arena class is the utility class that can be used to make battles to different Pokémon
 */

public class Arena {

    /**
     * This method first displays the info of both Pokémon. Then we find damage modifiers for both Pokémon.
     * Then we make both the Pokémon battle unless one falls unconscious,i.e., health is 0.
     *
     * @param p1 Pokemon
     * @param p2 Opponent's Pokemon
     */

    public static void battle(Pokemon p1, Pokemon p2) {
        //Info display
        System.out.println("\n" + p1);
        System.out.println(p2);
        //Attack modifiers
        double m1 = p1.modifier(p2.getType());
        double m2 = p2.modifier(p1.getType());
        int count = 0; // just to keep count

        //Battle start display message
        System.out.println("\nIts a battle between " + p1.getName() + " and " + p2.getName() + " !!!!");
        System.out.println(p1.getName() + " will attack first!!");
        while (true) { //infinite loop
            System.out.println("\nPokemon " + p1.getName() + " attacks " + (count > 0 ? "again " : "") + "pokemon " + p2.getName());
            System.out.println("After attack Stats of Pokemon " + p2.getName() + " ->"); // after attacks stats of p2
            System.out.println("Damage done -> " + p1.damageDone(p2, m1) + " DMG"); // damage done by p1 to p2
            System.out.println("Health remaining of " + p2.getName() + " is -> " + p2.getHealth() + " HP"); // remaining health of p2
            if (!p2.alive()) { // checks weather p2 is conscious or not
                System.out.println("\nAnd Pokemon " + p1.getName() + " wins the battle by knocking out Pokemon " + p2.getName());
                break; // exits the loop
            }

            System.out.println("\nNow pokemon " + p2.getName() + " attacks " + (count > 0 ? "again " : "") + "pokemon " + p1.getName());
            System.out.println("After attack Stats of Pokemon " + p1.getName() + " ->"); // after attacks stats of p1
            System.out.println("Damage done -> " + p2.damageDone(p1, m2) + " DMG"); // damage done by p2 to p1
            System.out.println("Health remaining of " + p1.getName() + " is -> " + p1.getHealth() + " HP"); // remaining health of p1
            if (!p1.alive()) { // checks weather p1 is conscious or not
                System.out.println("\nAnd Pokemon " + p2.getName() + " wins the battle by knocking out Pokemon " + p1.getName());
                break; // exits the loop
            }

            count++;
        }
    }
}

