package homework;

/**
 * The child class for Water type Pokémon
 *
 * @author Akshat Garg ag2193@rit.com
 */

public class WaterPokemon extends Pokemon{

    /**
     * Creates a new Water type Pokémon
     *
     * @param name name of Pokémon
     * @param type type of Pokémon, Water type
     * @param attack attack value of Pokémon
     * @param health health point of Pokémon
     */

    public WaterPokemon(String name, PokemonType type, double attack, double health) {
        super(name, PokemonType.WATER, attack, health);
    }

    /**
     * Checks and return damage modifier based on opponent Pokémon.
     *
     * @param type opponent Pokémon type
     * @return value of damage modifier
     */

    @Override
    public double modifier(PokemonType type) {
        if (type == PokemonType.GRASS) {
            return 0.5;
        } else if (type == PokemonType.FIRE) {
            return 2.0;
        } else{
            return 1;
        }
    }
}
