package homework;

/**
 * The parent class for all Pokémon types
 *
 * @author Akshat Garg ag2193@rit.com
 */

public class Pokemon {
    /**
     * The name of Pokémon
     */
    private String name;
    /**
     * Type of Pokémon, default value is NORMAL
     */
    private PokemonType type = PokemonType.NORMAL;
    /**
     * Attack value of Pokémon
     */
    private double attack;
    /**
     * Health point of Pokémon
     */
    private double health;

    /**
     * Creates a new Pokémon
     *
     * @param name Pokémon name
     * @param type Type of Pokémon
     * @param attack Attack value of Pokémon
     * @param health Health point of Pokémon
     */

    public Pokemon(String name, PokemonType type, double attack, double health) {
        this.name = name;
        this.type = type;
        this.attack = attack;
        this.health = health;
    }

    /**
     * Gets the name of the Pokémon
     *
     * @return name of Pokémon
     */

    public String getName() {
        return name;
    }

    /**
     * Gets the type of Pokémon
     *
     * @return type of Pokémon
     */

    public PokemonType getType() {
        return type;
    }

    /**
     * Gets the attack value of Pokémon
     *
     * @return attack value of Pokémon
     */

    public double getAttack() {
        return attack;
    }

    /**
     * sets a new attack value for Pokémon
     *
     * @param attack new attack value of Pokémon
     */

    public void setAttack(double attack) {
        this.attack = attack;
    }

    /**
     * gets the health point of Pokémon
     *
     * @return health point of Pokémon
     */

    public double getHealth() {
        return health;
    }

    /**
     * sets the new health point of Pokémon
     *
     * @param health new health point of Pokémon
     */

    public void setHealth(double health) {
        this.health = health;
    }

    /**
     * Returns the value of damage modifiers based on opponent Pokémon type. This cannot be computed for all Pokémon types,
     * and so this method must be overridden in a child class.
     *
     * @param type opponent Pokémon type
     * @return value of damage modifiers
     */

    public double modifier(PokemonType type){
        return 1;
    }

    /**
     * Returns damage done to the opponent Pokémon type. This is calculated based on input parameters of opponents Pokémon
     * and damage modifier. We first calculate remaining health of Pokémon after the damage is done, if remaining health
     * is more than 0, we return the damage done and set the health of opponent Pokémon as remaining health. Else, if
     * remaining health is less than or equal to 0, we return damage done to opponent as health remaining before attack,
     * and set opponent health to 0.
     *
     * @param p Opponent Pokémon
     * @param modifier damage modifier for attacking
     * @return damage done to opponent Pokémon
     */

    public double damageDone(Pokemon p, double modifier) {
        double healthRemaining = p.getHealth() - (modifier * this.attack);
        if(healthRemaining > 0){
            p.setHealth(healthRemaining);
            return modifier * this.attack;
        }
        else{
            double d = p.getHealth();
            p.setHealth(0);
            return d;
        }
    }

    /**
     * Returns the state of Pokémon, true if it is still has some health else false if health is 0.
     *
     * @return Pokémon is conscious or not
     */

    public boolean alive(){
        if(this.health > 0){
            return true;
        }else{
            return false;
        }
    }

    /**
     * Override the toString method to our desired output String
     *
     * @return formatted string with desired output format
     */

    @Override
    public String toString() {
        return "Pokemon{" +
                "name='" + name + '\'' +
                ", type=" + type +
                ", attack=" + attack +
                " DMG, health=" + health +
                " HP}";
    }
}
