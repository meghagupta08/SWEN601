package activities;

public class Circle extends Shape{

    private int radius;

    public Circle(Position position, int radius){
        super(position);
        this.radius = radius;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    @Override
    public float perimeter(){
        return (float) (2*Math.PI*radius);
    }

    @Override
    public float area(){
        return (float) (Math.PI * (radius * radius));
    }

    public static void main(String[] args) {
        Position pos = new Position(0,0);
        Circle c1 = new Circle(pos, 4);
        System.out.println(c1);
        //System.out.println(Shape.area());
        System.out.println(c1.area());
        System.out.println(c1.perimeter());
        ShapeMover.moveShape(c1,new Position(10,10));
    }
}
