package activities;

public class Shape {

    private Position position;
    private String fillColor, outlineColor;

    public Shape(Position position, String fillColor, String outlineColor) {
        this.position = position;
        this.fillColor = fillColor;
        this.outlineColor = outlineColor;
    }

    public Shape(Position position){
        this(position, "white","black");
    }

    public float area(){
        return 0;
    }
    public float perimeter(){
        return 0;
    }
    public void move(Position position) {
        this.position = position;
    }

    public Position getPosition() {
        return position;
    }

    public String getFillColor() {
        return fillColor;
    }

    public String getOutlineColor() {
        return outlineColor;
    }

    public void setFillColor(String fillColor) {
        this.fillColor = fillColor;
    }

    public void setOutlineColor(String outlineColor) {
        this.outlineColor = outlineColor;
    }

    @Override
    public String toString() {
        return "Shape{" +
                "position=" + position +
                ", fillColor='" + fillColor + '\'' +
                ", outlineColor='" + outlineColor + '\'' +
                '}';
    }

}
