package activities;

public class Rectangle extends Shape{
    private int width,height;

    public Rectangle(Position position, int width, int height){
        super(position);
        this.width = width;
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    @Override
    public float perimeter(){
        return width*2 + height*2;
    }

    @Override
    public float area(){
        return width*height;
    }

    public static void main(String[] args) {
        Position pos = new Position(0,0);
        Rectangle r1 = new Rectangle(pos, 10, 20);
        System.out.println(r1);
        System.out.println(r1.area());
        System.out.println(r1.perimeter());
        System.out.println(r1.getOutlineColor());
    }
}
