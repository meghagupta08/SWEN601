package activities;

public class ShapeMover {
    public static void moveShape(Shape shape, Position pos){
        System.out.println(shape);
        shape.move(pos);
        System.out.println(shape);
        System.out.println("Area:" + shape.area());
    }
}
