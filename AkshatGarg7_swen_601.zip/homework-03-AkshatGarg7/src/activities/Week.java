package activities;
import java.util.Scanner;

public class Week {

    public static String day(int n){
        String x;
        switch(n){
            case 0:
                x = "Monday";
                break;
                //return "Monday";
            case 1:
                x = "Tuesday";
                break;
                //return "Tuesday";
            case 2:
                x = "Wednesday";
                break;
                //return "Wednesday";
            case 3:
                x = "Thursday";
                break;
                //return "Thursday";
            case 4:
                x = "Friday";
                break;
                //return "Friday";
            case 5:
                x = "Saturday";
                break;
                //return "Saturday";
            case 6:
                x = "Sunday";
                break;
                //return "Sunday";
            default:
                x = "not a Valid Day";
                break;
        }
        return x;
    }

    public static void main(String[] args) {

        System.out.print("Enter the number of the day you want to print: ");
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        s.close();

        System.out.println("It is " + day(n));

    }
}
