package activities;

import java.util.Scanner;

public class Register {

    public static String MakeChange(float charge, float payment){
        float change = payment - charge;
        int dollars = (int)change;
        int cents = (int)((change - dollars) * 100);

        String result = "Your change is " + dollars + (dollars == 1 ? " dollar" : " dollars") + " and " + cents + (cents == 1 ? " cent" : " cents");
        return result;
    }

    public static void main(String[] args) {

        System.out.print("Pease enter charge and payment amount: ");
        Scanner s = new Scanner(System.in);
        float charge = s.nextFloat();
        float payment = s.nextFloat();
        s.close();

        System.out.println(MakeChange(charge,payment));

    }

}
