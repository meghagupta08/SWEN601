package activities;
import java.util.Scanner;

public class EvenOrOdds {

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        System.out.print("Enter the number: ");
        int n = s.nextInt();
        s.close();

        if (n%5 == 0){
            System.out.println("Number is divisible by 5");
        }
        else if (n%2 == 0){
            System.out.println("Number is Even");
        }
        else{
            System.out.println("Number is Odd");
        }


    }
}
