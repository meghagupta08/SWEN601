package homework;
import java.util.Scanner;

/**
 * Class MusicMovie return a set of comments based on user choice of input
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class MusicMovie {

    /** Main function returns comments based on user choices
     * <p>
     * The function first ask the user for choice between music and movie.
     * Based on the choice, if user selected music, they are prompted to either they like
     * Queens or not, and get reaction based on that. If the user selected movie,
     * they are prompted which episode of star wars they like and get reaction based on that.
     *
     * @param args none
     */

    public static void main(String[] args) {

        System.out.println("Enter \"1\" to discuss Music! \nEnter \"2\" to discuss Movies!"); // Asking user to select what to discuss
        System.out.print("Enter what you want to discuss? ");
        Scanner s = new Scanner(System.in);
        int x = s.nextInt(); // scanning for input

        if(x == 1){
            System.out.println("Great! Do you like \"Queens\"? \nType \"1\" for yes and type \"2\" for no."); // asking whether user likes Queens or not
            //Scanner t = new Scanner(System.in);
            int y = s.nextInt(); // scanning for input
            s.close();
            System.out.println((y == 1) ? "Good taste!":"There is no accounting for taste!"); //music output
        }
        else if(x == 2){
            System.out.print("Great! Which Star Wars episode was best? Enter the episode number: "); // asking which episode of Star Wars they like?
            int z = s.nextInt(); // scanning for input
            s.close();
            System.out.println((z < 3 ? "Um,no." : (z < 6 ? "I agree!" : "I like those, too!") )); // movie output

        }

    }

}// End of Class
