package homework;
import java.util.Scanner;

/**
 * Class DateConvertor converts YYYY/MM/DD to Month Day, Year
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class DateConvertor {

    /** Function Year checks for leap year
     * <p>
     * For the given year, we first divide it with 4, and remainder is 0
     * we will check if it is divisible by 100, if yes check if it is divisible by 400
     * (because, for eg 1900, is not a leap year), if yes return true else false.
     *
     * @param Y integer type, Year input
     * @return boolean type return
     */

    public static boolean Year(int Y){
        if (Y % 4 == 0){ // checking if year is divisible by 4
            if ( Y % 100 == 0){// checking if year is divisible by 100
                if ( Y % 400 == 0){// checking if year is divisible by 400
                    return true; //output
                }
                else{
                    return false;//output
                }
            }
            else{
                return true;//output
            }
        }
        else{
            return false;//output
        }
    }

    /** Function Month returns month name based on input
     * <p>
     * Function takes input and searches for the months
     * and returns name of same.
     *
     * @param M integer type, month input
     * @return String type, returns month name based on input number
     */

    public static String Month(int M){

        switch(M){
            case 1://case if input is 1
                return "January";//output
            case 2://case if input is 2
                return "February";//output
            case 3://case if input is 3
                return "March";//output
            case 4://case if input is 4
                return "April";//output
            case 5://case if input is 5
                return "May";//output
            case 6://case if input is 6
                return "June";//output
            case 7://case if input is 7
                return "July";//output
            case 8://case if input is 8
                return "August";//output
            case 9://case if input is 9
                return "September";//output
            case 10://case if input is 10
                return "October";//output
            case 11://case if input is 11
                return "November";//output
            case 12://case if input is 12
                return "December";//output
            default://default case if not valid month
                return "Not a Valid Month";//output
        }
    }

    /** Function Day returns String type based on the last digit of the day
     * <p>
     * Only and only if day is 11, 12 or 13 of the month we return "th" at the end.
     * We take input for day and divide by 10 to get the unit place digit of day and
     * searching through the conditions for the return string.
     *
     * @param D integer type, input day
     * @return String type, return the appropriate string.
     */

    public static String Day(int D) {
        if (D == 11 || D == 12 || D == 13){ //checking if input is either 11,12 or 13
            return "th"; //output
        }
        else{
            switch(D % 10){ // dividing by 10 to get unit place digit
                case 1:
                    return "st"; //output
                case 2:
                    return "nd"; //output
                case 3:
                    return "rd"; //output
                default:
                    return "th"; //output
            }
        }
    }

    /** Function Convert takes date input and converts to required format
     * <p>
     * Function first finds year,month and day using substring and
     * converting each of string to integer type.
     * We then check if the input date is valid or not, if it is we return the expected output
     *
     * @param K String type, input date of format YYYY/MM/DD
     * @return string type, output
     */

    public static String Convert(String K) {

        String DateYear = K.substring(0, 4); //Finding year from the string
        String DateMonth = K.substring(5, 7);//Finding month from the string
        String DateDay = K.substring(8, 10);//Finding day from the string
        int Y = Integer.parseInt(DateYear); // Converting string to int
        int M = Integer.parseInt(DateMonth); // Converting string to int
        int D = Integer.parseInt(DateDay); // Converting string to int
        if (M > 12 || M < 1 || D < 1 || D > 31 || (M == 2 && D > 29) || (M == 2 && D == 29 && (!Year(Y)))) { //Checking if Date input is valid or not
            return "Enter a Valid Date";
        } else {
            return "For the given date following is the output -> " + Month(M) + " " + D + Day(D) + ", " + Y; //output
        }
    }

    /**
     * Function main takes user input and calls function Date
     *
     * @param args none
     */

    public static void main(String[] args) {

        System.out.print("Enter the date in given format YYYY/MM/DD: ");//input from user
        Scanner s = new Scanner(System.in);//start scanning
        String Date = s.next();//scanning for date string
        s.close();//scanner close
        System.out.println(Convert(Date));//output
    }
}//end of class

