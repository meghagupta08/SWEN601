package homework;
import java.util.Scanner;

/**
 * Class ProgrammingVsAge return comment based on age entered
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class ProgrammingVsAge {

    /** Function Age return string for given input n
     * <p>
     * The function Age takes input integer n from user and
     * based on value of n it checks for which condition it satisfy
     * and return a string based on that
     *
     * @param n integer type
     * @return String type based on n
     */

    public static String Age(int n){
        if (n <= 0){ //Eliminating 0 and negative values as age cannot be negative
            return "Invalid Age";
        }
        if (n < 10){//condition check for age less than 10
            return "Is this your first program?";
        }
        else if (n < 13){//condition check for age between 10 and less than 13
            return "A tween!";
        }
        else if (n < 20){//condition check for age between 13 and less than 20
            return "A teen!";
        }
        else if (n < 30){//condition check for age between 20 and less than 30
            return "A twenty-something!";
        }
        else{//condition check for other ages
            return "With age comes experience.";
        }
    }

    /**
     * Asks the user to enter an age of integer type
     * and calls the function Age for output for given input
     *
     * @param args none
     */

    public static void main(String[] args) {

        System.out.print("Enter the age: ");//asking user for input
        Scanner s = new Scanner(System.in);//starting scanner
        int n = s.nextInt();//getting the input
        s.close();//closing the scanner
        System.out.println(Age(n));//output

    }
}//End of class
