package weighted;

import java.util.HashSet;
import java.util.Set;

class Vertex<T> {

    private T value;
    private Set<Edge<T>> edges;

    Vertex(T value) {
        this.value = value;
        edges = new HashSet<>();
    }

    T getValue() {
        return value;
    }

    void addNeighbor(Vertex<T> neighbor, int weight) {
        Edge<T> edge = new Edge<>(this, neighbor, weight);
        edges.add(edge);
    }

    Set<Edge<T>> getEdges() {
        return edges;
    }

    @Override
    public String toString(){
        return "Vertex(" + value + ")";
    }
}
