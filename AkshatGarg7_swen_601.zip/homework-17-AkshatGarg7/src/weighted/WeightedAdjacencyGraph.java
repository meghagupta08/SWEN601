package weighted;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WeightedAdjacencyGraph<T> implements WeightedGraph<T> {
    private final Map<T, Vertex<T>> vertices;

    public WeightedAdjacencyGraph() {
        vertices = new HashMap<>();
    }

    @Override
    public void addValue(T value) {
        Vertex<T> vertex = new Vertex<>(value);
        vertices.put(value,vertex);
    }

    @Override
    public void connect(T value, T neighbor, int weight) {
        Vertex<T> v = vertices.get(value);
        Vertex<T> n = vertices.get(neighbor);
        v.addNeighbor(n,weight);
    }

    @Override
    public List<T> dijkstrasShortestPath(T start, T end) {
        return null;
    }
}
