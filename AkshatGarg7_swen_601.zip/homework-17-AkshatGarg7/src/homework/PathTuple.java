package homework;

public class PathTuple<T> {
    private T predecessor;
    private int cost;

    public PathTuple(T predecessor, int cost) {
        this.predecessor = predecessor;
        this.cost = cost;
    }

    public T getPredecessor() {
        return predecessor;
    }

    public void setPredecessor(T predecessor) {
        this.predecessor = predecessor;
    }

    public int getCost() {
        int prevCost = cost;
        cost = 0;
        return prevCost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }
}
