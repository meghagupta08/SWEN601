package homework;

import java.util.*;

public class WeightedAdjacencyGraph<T> implements WeightedGraph<T> {
    private final Map<T, Vertex<T>> vertices;

    public WeightedAdjacencyGraph() {
        this.vertices = new HashMap<>();
    }

    @Override
    public void addValue(T value) {
        Vertex<T> vertex = new Vertex<>(value);
        vertices.put(value, vertex);
    }

    @Override
    public void connect(T value, T neighbor, int weight) {
        Vertex<T> v = vertices.get(value);
        Vertex<T> n = vertices.get(neighbor);
        v.addNeighbor(n, weight);
        n.addNeighbor(v,weight);
    }

    @Override
    public List<T> dijkstrasShortestPath(T start, T end) {
//        computePath(start);
//        return getShortestPath(end);
        Vertex<T> s = new Vertex<>(start);
        Vertex<T> e = new Vertex<>(end);

        Set<Vertex<T>> settle = new HashSet<>();
        Set<Vertex<T>> unsettle = new HashSet<>();

        Map<T, PathTuple<T>> costs = new HashMap<>();

        for(Map.Entry entry : vertices.entrySet()){
            costs.put((T) entry.getKey(),new PathTuple<T>(null,Integer.MAX_VALUE));
        }

        costs.put(s.getValue(),new PathTuple<T>(null,0));
        unsettle.add(s);

        while(unsettle.size() > 0){
            Vertex<T> cur = getShortestDistance(unsettle,costs);
            unsettle.remove(cur);

            for(Edge<T> edge: cur.getEdges()){
                Vertex<T> v = edge.getTo();
                int vCost = edge.getWeight();

                if(!settle.contains(v)){
                    calculateMin(v,vCost,cur,costs);
                    unsettle.add(v);
                }
            }
            settle.add(cur);
        }
        List<T> path = new LinkedList<>();
        T temp = e.getValue();
        int cost = costs.get(e.getValue()).getCost();

        while(e.getValue() != null){
            path.add(0,temp);
            temp = costs.get(temp).getPredecessor();
        }
        return path;
    }

    private void calculateMin(Vertex<T> v, int vCost, Vertex<T> source, Map<T, PathTuple<T>> costs){
        int sCost = costs.get(source.getValue()).getCost();
        if((sCost + vCost) < costs.get(v.getValue()).getCost()){
            costs.put(v.getValue(), new PathTuple<>(source.getValue(), sCost + vCost));
        }
    }

    private Vertex<T> getShortestDistance(Set<Vertex<T>> unsettle, Map<T, PathTuple<T>> costs){
        Vertex<T> shortest = null;
        int shortCost = Integer.MAX_VALUE;

        for(Vertex<T> v : unsettle){
            int vDist = costs.get(v.getValue()).getCost();

            if(vDist < shortCost){
                shortCost = vDist;
                shortest = v;
            }
        }
        return shortest;
    }
}
//    }
//    private void computePath(T start){
//        Vertex<T> s = new Vertex<>(start);
//        s.setMinDistance(0);
//        PriorityQueue<Vertex<T>> pq = new PriorityQueue<>();
//        pq.add(s);
//
//        while(pq.size() > 0){
//            Vertex<T> cur = pq.poll();
//            for(Edge<T> edge : cur.getEdges()){
//                Vertex<T> v = edge.getTo();
//                int w = edge.getWeight();
//                int minDistance = cur.getMinDistance() + w;
//
//                if(minDistance < v.getMinDistance()){
//                    pq.remove(cur);
//                    v.setPreviousVertex(cur);
//                    v.setMinDistance(minDistance);
//                    pq.add(v);
//                }
//            }
//        }
//    }
//
//    private List<T> getShortestPath(T end){
//        Vertex<T> t = new Vertex<>(end);
//        List<T> path = new ArrayList<>();
//        for(Vertex<T> v = t; v != null; v = v.getPreviousVertex()){
//            path.add(v.getValue());
//        }
//
//        Collections.reverse(path);
//        return path;
//    }

