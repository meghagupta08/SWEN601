package homework;

import java.util.HashSet;
import java.util.Set;

class Vertex<T>{ //implements Comparable<Vertex<T>>{

    private T value;
    private Set<Edge<T>> edges;
//    private boolean visited;
//    private Integer minDistance = Integer.MAX_VALUE;
//    private Vertex<T> previousVertex;


    Vertex(T value) {
        this.value = value;
        edges = new HashSet<>();
    }

    T getValue() {
        return value;
    }

    void addNeighbor(Vertex<T> neighbor, int weight) {
        Edge<T> edge = new Edge<>(this, neighbor, weight);
        edges.add(edge);
    }

    Set<Edge<T>> getEdges() {
        return edges;
    }

//    public boolean isVisited() {
//        return visited;
//    }
//
//    public void setVisited(boolean visited) {
//        this.visited = visited;
//    }
//
//    public Vertex<T> getPreviousVertex() {
//        return previousVertex;
//    }
//
//    public void setPreviousVertex(Vertex<T> previousVertex) {
//        this.previousVertex = previousVertex;
//    }
//
//    public Integer getMinDistance() {
//        return minDistance;
//    }
//
//    public void setMinDistance(Integer minDistance) {
//        this.minDistance = minDistance;
//    }

    @Override
    public String toString(){
        return value.toString();
    }

//    @Override
//    public int compareTo(Vertex<T> otherVertex){
//        return Integer.compare(this.minDistance,otherVertex.minDistance);
//    }
}
