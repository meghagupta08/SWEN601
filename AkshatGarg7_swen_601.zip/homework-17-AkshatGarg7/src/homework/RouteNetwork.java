package homework;

import java.util.List;

public class RouteNetwork {
    public static void main(String[] args) {
        WeightedGraph<String> airport = new WeightedAdjacencyGraph<>();
        airport.addValue("ROC");
        airport.addValue("DCA");
        airport.addValue("ATL");
        airport.addValue("MCO");
        airport.addValue("ORD");
        airport.addValue("PDX");
        airport.addValue("SFO");
        airport.addValue("LAX");

        airport.connect("ROC","DCA",10);
        airport.connect("ROC","ATL",22);
        airport.connect("ROC","MCO",24);
        airport.connect("ROC","ORD",15);
        airport.connect("DCA","SFO",25);
        airport.connect("DCA","LAX",36);
        airport.connect("ATL","LAX",31);
        airport.connect("MCO","LAX",31);
        airport.connect("ORD","PDX",26);
        airport.connect("ORD","SFO",37);
        airport.connect("ORD","LAX",35);
        airport.connect("PDX","LAX",21);
        airport.connect("SFO","LAX",10);

        List<String> answer = airport.dijkstrasShortestPath("DCA","ORD");
        System.out.println(answer);
        //System.out.println(airport.dijkstrasShortestPath("DCA","ORD"));
//        Vertex<String> v1 = new Vertex<>("ROC");
//        Vertex<String> v2 = new Vertex<>("DCA");
//        Vertex<String> v3 = new Vertex<>("ATL");
//        Vertex<String> v4 = new Vertex<>("MCO");
//        Vertex<String> v5 = new Vertex<>("ORD");
//        Vertex<String> v6 = new Vertex<>("PDX");
//        Vertex<String> v7 = new Vertex<>("SFO");
//        Vertex<String> v8 = new Vertex<>("LAX");
//
//        v1.addNeighbor(v2,10);
//        v1.addNeighbor(v3,22);
//        v1.addNeighbor(v4,24);
//        v1.addNeighbor(v5,15);
//        v2.addNeighbor(v7,25);
//        v2.addNeighbor(v8,36);
//        v3.addNeighbor(v8,31);
//        v4.addNeighbor(v8,31);
//        v5.addNeighbor(v6,26);
//        v5.addNeighbor(v7,37);
//        v5.addNeighbor(v8,35);
//        v6.addNeighbor(v8,21);
//        v7.addNeighbor(v8,10);
//
//        System.out.println(new WeightedAdjacencyGraph<String>().dijkstrasShortestPath("DCA","ORD"));
    }
}
