public class HelloWorld { //create class with same name as program file name
    public static void main(String[] args){ //creating main

        System.out.println("Hello, World!"); //prints the hello world!
    }
}
