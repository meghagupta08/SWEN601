public class Carroll {/* creating a class name Carroll
*My name is Akshat Garg
*My email id is ag2193@rit.edu
*We are doing this assignment to understand
*learn and use java with git
*/
    /*We are printing out each statement
     *in new line using println and
     *making sure "d" of "and" and "l" of "Carroll"
     *appears in same line
     */
    public static void main (String[] agrs){

        System.out.println("\"Begin at the");
        System.out.println("beginning,\", the King");
        System.out.println("said, very gravely, \"and");
        System.out.println("go on till you come to");
        System.out.println("the end: then stop.\"");
        System.out.println("          -Lewis Carroll");
    }
}
//end of class Carroll
