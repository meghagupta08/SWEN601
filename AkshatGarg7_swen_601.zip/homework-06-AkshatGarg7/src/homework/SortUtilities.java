package homework;

import java.util.Arrays;
import java.util.Random;

/**
 * Class SortUtilities contains all utilities required for sorting algo.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class SortUtilities {

    /**
     * Function RNG generates a random number based on the seed provided
     */

    private static final Random RNG = new Random(1);//same seed is provided because to generate the same array

    /** Function sorted checks weather the given is sorted or not.
     * <p>
     * We traverse through the array to check each element if it is sorted or not, if it is not sorted
     * we return false, suggesting it is not sorted.
     *
     * @param array integer type array
     * @return boolean, if sorted it returns true
     */

    public static boolean sorted(int[] array){
        for (int i = 1; i< array.length; i++){
            if(array[i] < array[i-1]){
                return false;
            }
        }
        return true;
    }

    /**
     *  Function swap, reverses the given input indexes of the given array
     *
     * @param array integer type array
     * @param a integer type, index of the array
     * @param b integer type, index of the array
     */

    public static void swap(int[] array, int a, int b){
        int temp = array[a]; // storing in temp value
        array[a] = array[b];
        array[b] = temp;
    }

    /**
     * Function makeArray creates a random array of size n, using RNG function
     *
     * @param size integer type, size of array
     * @return integer random array
     */

    public static int[] makeArray(int size){
        int[] newArray = new int[size];
        for(int i = 0; i < size; i++){
            newArray[i] = RNG.nextInt(size); // creating new array based on size
        }
        return newArray;
    }

    /**
     * Function divide divides given array into two parts, based on if index is even or not.
     * It returns divided array into evens and odds index.
     *
     * @param array integer type array
     * @return 2-d array, array divided into 2 parts
     */

    public static int[][] divide(int[] array){
        //finding the size of two arrays
        int[] odds = new int[array.length/2];
        int[] evens = new int[array.length - odds.length];
        int i = 0;
        int count_odds = 0;
        int count_evens = 0;

        while(i < array.length){
            if(i%2 != 0){ // if odd
                odds[count_odds] = array[i];
                count_odds++;
            }
            else{ //if even
                evens[count_evens] = array[i];
                count_evens++;
            }
            i ++;
        }
        return new int[][] {evens,odds};
    }

    /**
     * Function merge,merges the two arrays by comparing elements of two arrays and sorting it.
     * It returns a merged array.
     *
     * @param a integer type array
     * @param b integer type array
     * @return integer array, merged array a and b
     */

    public static int[] merge(int[] a, int[] b) {
        // just in case if array is empty
        if (a.length == 0) {
            return b;
        } else if (b.length == 0) {
            return a;
        }

        int[] merged = new int[a.length + b.length]; // new merged array size
        int aIndex = 0, bIndex = 0;
        while (aIndex < a.length && bIndex < b.length) {
            if (a[aIndex] < b[bIndex]) {
                merged[aIndex + bIndex] = a[aIndex];
                aIndex++;
            } else {
                merged[aIndex + bIndex] = b[bIndex];
                bIndex++;
            }
        }
        // if suppose any array is completed and another one is not finish we concatenate the reaming array to new array
        if(aIndex < a.length){
            System.arraycopy(a, aIndex, merged, aIndex + bIndex, a.length - aIndex);
        }
        else{
            System.arraycopy(b, bIndex, merged, aIndex + bIndex, b.length - bIndex);
        }
        return merged;
    }

    /**
     * Function cat, concatenate given arrays( any number of input) into a single array.
     *
     * @param arrays integer type arrays
     * @return single concatenated integer array
     */

    public static int[] cat(int[] ... arrays){
        int l = 0;
        for(int[] array : arrays){
            l += array.length; // saving the length to create a single array of same size
        }
        //System.out.println(l);
        int cp = 0; // checkpoint to check at what to start new concatenation
        int[] returnArray = new int[l]; // new array of size l
        for(int[] array : arrays){
            System.arraycopy(array, 0 , returnArray, cp, array.length); // copying the array in new array
            cp += array.length;
        }
        return returnArray;
        //System.out.println(Arrays.toString(returnArray));
    }

    /**
     * Function main, calls the above sorting utilities and passes a random array size to test.
     *
     * @param args none
     */

    public static void main(String[] args) {
        int[] a = {1,3,5,6,7,9,10};
        int[] b = {1,3,4,8,5,9,10};
        System.out.println(sorted(a));
        System.out.println(sorted(b));

        swap(b,3,4);
        System.out.println(sorted(b));

        int[] rando = makeArray(11);
        System.out.println(Arrays.toString(rando));

        int[][] divided = divide(rando);
        System.out.println(Arrays.toString(divided[0]));
        System.out.println(Arrays.toString(divided[1]));

        int[] merged = merge(divided[0],divided[1]);
        System.out.println(Arrays.toString(merged));

        cat(new int[] {1,2,3}, new int[] {4}, new int[] {5,6,7});
    }

}

