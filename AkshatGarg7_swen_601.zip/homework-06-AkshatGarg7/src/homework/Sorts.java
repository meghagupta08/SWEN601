package homework;

import java.util.Arrays;
import static activites.SortUtilities.*; // importing sortutilities in the same package

/**
 * Class Sorts contains all the sorting methods.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class Sorts {

    /** Function insertionSort returns a sorted array for given input array using insertion sort algo.
     * <p>
     * We first create a partition for the array and sort all the elements in the partition group
     * and move partition by 1 till end of the array.
     *
     * @param array integer type array
     */

    public static void insertionSort(int[] array) {
        int partition = 0;//we can get away with 1 as outer loop won't do anything
        while (partition < array.length) {
            int i = partition;
            while (i > 0 && array[i] < array[i - 1]) {
                swap(array, i, i - 1); //interchanging values
                i--;
            }
            partition++; // increasing the partition size in the array
        }
    }

    /** Function mergeSort returns a sorted array for given input array using merge sort algo.
     * <p>
     * We divide array into two parts and sort each part recursively
     * and returning a sorted array.
     *
     * @param array integer type array
     */

    public static int[] mergeSort(int[] array){
        if (array.length < 2){
            return array; // if array size is 0 or 1
        }
        else{
            int[][] divided = divide(array); // dividing array in 2 parts
            int[] left = mergeSort(divided[0]); // saving one part in left
            int[] right = mergeSort(divided[1]); // saving another in right
            return merge(left,right); // returning the output
            //return merged;
        }
    }

    /** Function bubbleSort returns a sorted array for given input array using bubble sort algo.
     * <p>
     * We traverse through array from 1 to array length -2 and check if array[i] > array[i+1], if yes it will swap
     * both values and continue with next element. It will continue till end of the array.
     *
     * @param array integer type array
     */

    public static int[] bubbleSort(int[] array) {
        for (int count = 0; count < array.length - 1; count++) { // outer loop to traverse through the array
            boolean swapping = false; // flag
            for (int i = 0; i < array.length - count - 1; i++) { // inner loop to traverse through the array - i
                if (array[i + 1] < array[i]) {
                    swap(array, i, i + 1); // swapping the values
                    swapping = true; // flag true
                }
                //System.out.println(Arrays.toString(array));
            }
            if (!swapping) {
                break; // if there is no swapping we break out of inner loop
            }
        }
        return array; // output
    }

    /** Function quickSort returns a sorted array for given input array using quick sort algo.
     * <p>
     * We divide array into three parts based on pivot point,i.e ,first element of the array,
     * less than pivot array, equal to pivot array and greater than pivot array. We then recursively
     * run quicksort on less than pivot array and greater array. The returned array is a sorted array.
     *
     * @param array integer type array
     */

    public static int[] quickSort(int[] array) {
        if (array.length < 2) {
            return array; // if array size is 0 or 1
        } else {
            int pivot = array[0]; // keeping the value of pivot as first element of array
            int l = 0, e = 0, g = 0, i = 0;

            //Checking for the size of each array to be created
            while (i < array.length) {
                if (array[i] < pivot) {
                    l++;
                } else if (array[i] == pivot) {
                    e++;
                } else {
                    g++;
                }
                i++;
            }

            int count = 0;
            int ln = 0, en = 0, gn = 0;
            //creating new array based on previous counting
            int[] less = new int[l];
            int[] equal = new int[e];
            int[] greater = new int[g];
            // saving the values in arrays
            while (count < array.length) {
                if (array[count] < pivot) {
                    less[ln] = array[count];
                    ln++;
                } else if (array[count] == pivot) {
                    equal[en] = array[count];
                    en++;
                } else {
                    greater[gn] = array[count];
                    gn++;
                }
                count++;
            }

            // running recursively
            int[] left = quickSort(less);
            int[] right = quickSort(greater);
            array = SortUtilities.cat(left, equal, right);
            return array; //output
        }
    }

    /**
     * Function main, calls the above sorting methods and passes a random array to sort it through given methods.
     *
     * @param args none
     */

    public static void main(String[] args) {

        int[] array = makeArray(11);
        System.out.println(Arrays.toString(array));
        System.out.println(sorted(array));
        insertionSort(array);
        System.out.println(Arrays.toString(array));
        System.out.println(sorted(array));

        int[] rando = makeArray(100);
        System.out.println(Arrays.toString(rando));
        int[] sorted_array = mergeSort(rando);
        System.out.println(Arrays.toString(sorted_array));
        System.out.println(sorted(sorted_array));

        int[] rando_new = makeArray(10);
        System.out.println(Arrays.toString(rando_new));
        //int[] array_copy = Arrays.copyOf(rando_new,rando_new.length);
        //System.out.println(Arrays.toString(bubbleSort(array_copy)));

        int[] array_copy = Arrays.copyOf(rando_new,rando_new.length);
        //int[] array1=quickSort(array_copy);
        System.out.println(Arrays.toString(quickSort(array_copy)));
        System.out.println(sorted(quickSort(array_copy)));
    }
}

