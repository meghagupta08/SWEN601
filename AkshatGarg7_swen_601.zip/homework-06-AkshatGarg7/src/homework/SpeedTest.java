package homework;

import java.util.Arrays;
import java.util.Scanner;
import static homework.SortUtilities.*;
import static homework.Sorts.*;

/**
 * Class SpeedTest calculates the time taken by each sorting algo to sort a given same random array.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class SpeedTest {

    /**
     * Function performanceInsertionSort, uses insertion sort method on a given array and print out
     * time taken in milliseconds. We also check if the array is sorted before and after the sorting and print out
     * the same.
     *
     * @param array integer type array
     */

    public static void performanceInsertionSort(int[] array){
        int[] rando_insertion = Arrays.copyOf(array, array.length); //copying array to new variable
        System.out.println("Insertion Sort on " + rando_insertion.length + " elements");
        System.out.println("Pre-sorted: " + sorted(rando_insertion)); // checking if the array is presorted
        long start_in = System.currentTimeMillis(); // initiating time
        insertionSort(rando_insertion); // running sorting algo
        long end_in = System.currentTimeMillis(); // ending time
        System.out.println("Completed in " + (end_in - start_in) + " milliseconds."); // printing out the time taken by method to run
        System.out.println("Sorted: " + sorted(rando_insertion)); // checking if the array is sorted
    }

    /**
     * Function performanceBubbleSort, uses bubble sort method on a given array and print out
     * time taken in milliseconds. We also check if the array is sorted before and after the sorting and print out
     * the same.
     *
     * @param array integer type array
     */

    public static void performanceBubbleSort(int[] array){
        int[] rando_bubble = Arrays.copyOf(array, array.length);//copying array to new variable
        System.out.println("Bubble Sort on " + rando_bubble.length + " elements");
        System.out.println("Pre-sorted: " + sorted(rando_bubble));// checking if the array is presorted
        long start_in = System.currentTimeMillis();// initiating time
        int[] sort = bubbleSort(rando_bubble);// running sorting algo
        long end_in = System.currentTimeMillis();// ending time
        System.out.println("Completed in " + (end_in - start_in) + " milliseconds.");// printing out the time taken by method to run
        System.out.println("Sorted: " + sorted(sort)); // checking if the array is sorted
    }

    /**
     * Function performanceQuickSort, uses quick sort method on a given array and print out
     * time taken in milliseconds. We also check if the array is sorted before and after the sorting and print out
     * the same.
     *
     * @param array integer type array
     */

    public static void performanceQuickSort(int[] array){
        int[] rando_quick = Arrays.copyOf(array, array.length);//copying array to new variable
        System.out.println("Quick Sort on " + rando_quick.length + " elements");
        System.out.println("Pre-sorted: " + sorted(rando_quick));// checking if the array is presorted
        long start_in = System.currentTimeMillis();// initiating time
        int[] sort = quickSort(rando_quick);// running sorting algo
        long end_in = System.currentTimeMillis();// ending time
        System.out.println("Completed in " + (end_in - start_in) + " milliseconds.");// printing out the time taken by method to run
        System.out.println("Sorted: " + sorted(sort)); // checking if the array is sorted
    }

    /**
     * Function performanceMergeSort, uses merge sort method on a given array and print out
     * time taken in milliseconds. We also check if the array is sorted before and after the sorting and print out
     * the same.
     *
     * @param array integer type array
     */

    public static void performanceMergeSort(int[] array){
        int[] rando_merge = Arrays.copyOf(array, array.length);//copying array to new variable
        System.out.println("Merge Sort on " + rando_merge.length + " elements");
        System.out.println("Pre-sorted: " + sorted(rando_merge));// checking if the array is presorted
        long start_in = System.currentTimeMillis();// initiating time
        int[] sort = mergeSort(rando_merge);// running sorting algo
        long end_in = System.currentTimeMillis();// ending time
        System.out.println("Completed in " + (end_in - start_in) + " milliseconds.");// printing out the time taken by method to run
        System.out.println("Sorted: " + sorted(sort)); // checking if the array is sorted
    }

    /**
     * Function main calls each of the performance method and passes the same random array of size n, asked by user.
     *
     * @param args none
     */

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the array size n: "); // asking user input for size of array
        int n = s.nextInt();
        s.close();
        int[] rando = makeArray(n); // generating a random array based on size n
        //Performance calculation for Insertion Sort
        performanceInsertionSort(rando);
        System.out.println(" ");
        //Performance calculation for Bubble Sort
        performanceBubbleSort(rando);
        System.out.println(" ");
        //Performance calculation for Quick Sort
        performanceQuickSort(rando);
        System.out.println(" ");
        //Performance calculation for Merge Sort
        performanceMergeSort(rando);
    }

}
