Insertion Sort on 100000 elements
Pre-sorted: false
Completed in 1771 milliseconds.
Sorted: true

Bubble Sort on 100000 elements
Pre-sorted: false
Completed in 15992 milliseconds.
Sorted: true

Quick Sort on 100000 elements
Pre-sorted: false
Completed in 43 milliseconds.
Sorted: true

Merge Sort on 100000 elements
Pre-sorted: false
Completed in 25 milliseconds.
Sorted: true