package activites;
import java.util.Arrays;

import static activites.SortUtilities.*;
public class Sorts {

    public static void insertionSort(int[] array) {
        int partition = 0;//we can get away with 1 as outer loop won't do anything
        while (partition < array.length) {
            int i = partition;
            while (i > 0 && array[i] < array[i - 1]) {
                swap(array, i, i - 1);
                i--;
            }
            partition++;
        }
    }

    public static int[] mergeSort(int[] array){
        if (array.length < 2){
            return array;
        }
        else{
            int[][] divided = divide(array);
            int[] left = mergeSort(divided[0]);
            int[] right = mergeSort(divided[1]);
            int[] merged = merge(left,right);
            return merged;
        }
    }
/*
    public static int[] cat(int[] ... arrays){
        /**
         * [1,3,5]
         * [7]
         * [8,9]
         * =
         * [1,3,5,7,8,9]

        int totalLength = 0;
        for (int[] array : arrays){
            totalLength += array.length;
        }
        int [] returnValue = new int[totalLength];
        // a loop that uses System.arrayCopy() to copy
        // each array in arrays into the correct index
        // in returnValue

    }
*/
    public static void main(String[] args) {

        int[] array = makeArray(11);
        System.out.println(Arrays.toString(array));
        System.out.println(sorted(array));
        insertionSort(array);
        System.out.println(Arrays.toString(array));
        System.out.println(sorted(array));

        int[] rando = makeArray(11);
        System.out.println(Arrays.toString(rando));
        int[] sorted = mergeSort(rando);
        System.out.println(Arrays.toString(sorted));
        System.out.println(sorted(sorted));

    }
}
