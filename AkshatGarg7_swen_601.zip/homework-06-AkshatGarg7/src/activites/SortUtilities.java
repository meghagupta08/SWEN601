package activites;

import java.util.Arrays;
import java.util.Random;

public class SortUtilities {
    private static final Random RNG = new Random(1);//same seed is provided because to generate the same array

    public static boolean sorted(int[] array){
        for (int i = 1; i< array.length; i++){
            if(array[i] < array[i-1]){
                return false;
            }
        }
        return true;
    }
    public static void swap(int[] array, int a, int b){
        int temp = array[a];
        array[a] = array[b];
        array[b] = temp;
    }

    public static int[] makeArray(int size){
        int[] newArray = new int[size];
        for(int i = 0; i < size; i++){
            newArray[i] = RNG.nextInt(size);
        }
        return newArray;
    }

    public static int[][] divide(int[] array){
        int[] odds = new int[array.length/2];
        int[] evens = new int[array.length - odds.length];
        int i = 0;
        int count_odds = 0;
        int count_evens = 0;
        while(i < array.length){
            if(i%2 != 0){
                odds[count_odds] = array[i];
                count_odds++;
            }
            else{
                evens[count_evens] = array[i];
                count_evens++;
            }
            i ++;
        }
        return new int[][] {evens,odds};
    }

    public static int[] merge(int[] a, int[] b) {
        // just in case if array is empty
        if (a.length == 0) {
            return b;
        } else if (b.length == 0) {
            return a;
        }
        int[] merged = new int[a.length + b.length];
        int aIndex = 0, bIndex = 0;
        while (aIndex < a.length && bIndex < b.length) {
            if (a[aIndex] < b[bIndex]) {
                merged[aIndex + bIndex] = a[aIndex];
                aIndex++;
            } else {
                merged[aIndex + bIndex] = b[bIndex];
                bIndex++;
            }
        }
        if(aIndex < a.length){
            System.arraycopy(a, aIndex, merged, aIndex + bIndex, a.length - aIndex);
        }
        else{
            System.arraycopy(b, bIndex, merged, aIndex + bIndex, b.length - bIndex);
        }
        return merged;
    }

    public static void main(String[] args) {
        int[] a = {1,3,5,6,7,9,10};
        int[] b = {1,3,4,8,5,9,10};
        System.out.println(sorted(a));
        System.out.println(sorted(b));

        swap(b,3,4);
        System.out.println(sorted(b));

        int[] rando = makeArray(11);
        System.out.println(Arrays.toString(rando));

        int[][] divided = divide(rando);
        System.out.println(Arrays.toString(divided[0]));
        System.out.println(Arrays.toString(divided[1]));

        int[] merged = merge(divided[0],divided[1]);
        System.out.println(Arrays.toString(merged));
    }

}
