package session;

import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {
        TreeSet<ComicBook> comics = new TreeSet<>();

        comics.add(new ComicBook("Marvel","Spider-Man",1));
        comics.add(new ComicBook("DC","Detective Comics",2));
        comics.add(new ComicBook("DC","Speed",3));

        for(ComicBook comic : comics){
            System.out.println(comic);
        }

        TreeSet<ComicBook> comics_new = new TreeSet<>(new PublisherComparator());

        comics_new.add(new ComicBook("Marvel","Spider-Man",1));
        comics_new.add(new ComicBook("DC","Detective Comics",2));
        comics_new.add(new ComicBook("DC","Speed",3));

        for(ComicBook comic : comics_new){
            System.out.println(comic);
        }
    }
}
