package session;

import java.util.Comparator;

public class PublisherComparator implements Comparator<ComicBook> {
    @Override
    public int compare(ComicBook a,ComicBook b){
        //return a.getPublisher().compareTo(b.getPublisher());
        int result = a.getPublisher().compareTo(b.getPublisher());
        if(result == 0){
            result = a.getTitle().compareTo(b.getTitle());
        }
        return result;
    }
}
