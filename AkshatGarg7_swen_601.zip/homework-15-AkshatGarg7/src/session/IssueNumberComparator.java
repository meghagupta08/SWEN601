package session;

import java.util.Comparator;

public class IssueNumberComparator implements Comparator<ComicBook> {
    @Override
    public int compare(ComicBook a, ComicBook b){
        //return 0;
        return b.getIssueNumber() - a.getIssueNumber();
    }
}
