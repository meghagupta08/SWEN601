package session;

import java.util.Comparator;
import java.util.Objects;

public class ComicBook implements Comparable<ComicBook> {
    private String publisher;
    private String title;
    private int issueNumber;

    public ComicBook(String publisher, String title, int issueNumber) {
        this.publisher = publisher;
        this.title = title;
        this.issueNumber = issueNumber;
    }

    public String getPublisher() {
        return publisher;
    }

    public String getTitle() {
        return title;
    }

    public int getIssueNumber() {
        return issueNumber;
    }

    @Override
    public int compareTo(ComicBook comic){
        //<0 if this comes before other is sorted
        //0 if this and other are equal
        //>0 if this comes after other in sorted order
        return this.title.compareTo(comic.title);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ComicBook comicBook = (ComicBook) o;
        return issueNumber == comicBook.issueNumber && Objects.equals(publisher, comicBook.publisher) && Objects.equals(title, comicBook.title);
    }

    @Override
    public int hashCode() {
        return Objects.hash(publisher, title, issueNumber);
    }

    @Override
    public String toString() {
        return "ComicBook{" +
                "publisher='" + publisher + '\'' +
                ", title='" + title + '\'' +
                ", issueNumber=" + issueNumber +
                '}';
    }
}
