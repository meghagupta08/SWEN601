package session;

public class HeapMain {
    public static void main(String[] args) {
        Heap heap = new ArrayHeap();
        heap.add(7);
        System.out.println(heap);
        heap.add(60);
        System.out.println(heap);
        heap.add(21);
        System.out.println(heap);
        heap.add(10);
        System.out.println(heap);
        heap.add(50);
        System.out.println(heap);
        heap.add(43);
        System.out.println(heap);
        heap.add(24);
        System.out.println(heap);
        heap.add(68);
        System.out.println(heap);
        heap.add(66);
        System.out.println(heap);

        while(heap.size() > 0){
            System.out.println(heap.remove());
        }
    }
}
