package homework;

/**
 * Implementation of a queue
 *
 * @param <T> This describes my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */

public interface Queue<T> {
    /**
     * Adds the specified element based on min heap.
     *
     * @param value my type parameter value
     */
    void enqueue(T value);
    /**
     * Returns a reference to the element at the top of the Heap queue.
     * The element is not removed from the heap.
     *
     * @return a reference to the element at the top of the heap
     */
    T peek();
    /**
     * Removes the element at the root of the heap and returns a
     * reference to it.
     *
     * @return removes the element at the root of the queue and returns a reference to it
     */
    T dequeue();
    /**
     * Returns the number of elements currently in this queue.
     *
     * @return the number of elements currently in this queue
     */
    int size();
}