package homework;

/**
 * Main function to test implementation of priority queue
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class PriorityQueueMain {
    public static void main(String[] args) {
        System.out.println("String:"); //String test
        Queue<String> queueString = new PriorityQueue<>(new StringComp()); //passing comparator
        queueString.enqueue("a");
        queueString.enqueue("Z");
        queueString.enqueue("Ehk");
        queueString.enqueue("vBj");
        queueString.enqueue("tgD");
        queueString.enqueue("qW");
        queueString.enqueue("bN");
        queueString.enqueue("DgH");
        StringBuilder actual = new StringBuilder();
        while (queueString.size() > 1) {
            String a = queueString.dequeue();
            actual.append(a).append(",");
        }
        actual.append(queueString.dequeue());
        System.out.println("Priority Queue after dequeued-> [" + actual + "]");
        System.out.println("----------------------------------------------------------------------------------------------------------------------");

        System.out.println("Integer:"); //integer test
        Queue<Integer> queue = new PriorityQueue<>();//not passing comparator
        queue.enqueue(5);
        queue.enqueue(3);
        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(4);
        queue.enqueue(6);
        queue.enqueue(9);
        queue.enqueue(7);
        queue.enqueue(0);
        queue.enqueue(8);
        StringBuilder actualInt = new StringBuilder();
        while (queue.size() > 1) {
            int a = queue.dequeue();
            actualInt.append(a).append(",");
        }
        actualInt.append(queue.dequeue());
        System.out.println("Priority Queue after dequeued-> [" + actualInt + "]");
    }
}
