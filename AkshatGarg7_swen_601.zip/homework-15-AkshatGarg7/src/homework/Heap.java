package homework;

/**
 * Interface for implementation of Heap
 *
 * @param <T> This describes my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */

public interface Heap<T> {
    /**
     * Add value to Heap
     *
     * @param value to be added to heap
     */
    void add(T value);

    /**
     * Value to be removed from heap
     *
     * @return removed value from heap
     */
    T remove();

    /**
     * @return size of heap
     */
    int size();
}
