package homework;

import java.util.Arrays;
import java.util.Comparator;

/**
 * Implementation of Heaps Interface
 *
 * @param <T> This describes my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */

public class MyHeap<T> implements Heap<T>{

    /**
     * required fields
     */
    private Object[] array;
    private int size;
    private Comparator<T> comparator;

    /**
     * Constructor with comparator as parameter
     *
     * @param comparator my type comparator
     */
    public MyHeap(Comparator<T> comparator) {
        this.array = new Object[8];
        this.size = 0;
        this.comparator = comparator;
    }

    /**
     * Constructor with null input
     */
    public MyHeap() {
        this(null);
    }

    /**
     * @return top priority node/root of heap
     */
    public T getArray(){
        return (T) array[0];
    }

    /**
     * Compare to objects and returns <,=,> 0 based on comparison
     *
     * @param a Object 1
     * @param b object 2
     * @return <,=,> 0 integer based on comparison
     */
    private int compare(T a, T b){
        if(comparator != null){
            return comparator.compare(a,b);
        }else{ // if comparator is not passed
            Comparable<T> ca = (Comparable<T>)a;
            Comparable<T> cb = (Comparable<T>)b;
            return ca.compareTo((T) cb);
        }
    }

    /**
     * Sifts a value up from the specified index in a heap.
     *
     * @param array The heap.
     * @param index The index to begin sifting up.
     */
    void siftUp(Object[] array, int index) {
        int parent = (index - 1) / 2;
        while(compare((T) array[parent],(T) array[index]) > 0) {
            swap(array, index, parent);
            index = parent;
            parent = (index - 1) / 2;
        }
    }

    /**
     * Sifts a value down from the root in a heap.
     *
     * @param array The heap.
     * @param size The size of the heap.
     */
    void siftDown(Object[] array, int size) {
        int to = 0;
        int from;
        do {
            from = to;

            int left = 2 * from + 1;
            int right = left + 1;
            if(left < size && ((compare((T) array[left], (T)array[to])) < 0)) {
                to = left;
            }

            if(right < size && ((compare((T) array[right], (T)array[to])) < 0)) {
                to = right;
            }

            swap(array, from, to);

        } while(from != to);
    }

    /**
     * Swaps the values at the specified indexes.
     *
     * @param array The array in which the values should be swapped.
     * @param from The first index.
     * @param to The second index.
     */
    void swap(Object[] array, int from, int to) {
        if(from != to) {
            T tmp = (T)array[from];
            array[from] = array[to];
            array[to] = tmp;
        }
    }

    /**
     * Add value to Heap
     *
     * @param value to be added to heap
     */
    @Override
    public void add(T value) {
        if(size == array.length){
            array = Arrays.copyOf(array, size*2);
        }
        array[size] = value;
        siftUp(array,size);
        size++;
    }

    /**
     * Value to be removed from heap
     *
     * @return removed value from heap
     */
    @Override
    public T remove() {
        T value = (T) array[0];
        size --;
        array[0] = array[size];
        array[size] = null;
        siftDown(array,size);
        return value;
    }

    /**
     * @return size of heap
     */
    @Override
    public int size() {
        return this.size;
    }

    @Override
    public String toString() {
        return "MyHeap{" +
                "array=" + Arrays.toString(array) +
                ", size=" + size +
                '}';
    }
}
