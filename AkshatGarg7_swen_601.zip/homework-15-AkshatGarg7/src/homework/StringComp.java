package homework;
import java.util.Comparator;

/**
 * StringComp first converts string to lower case and then compares string and returns an int value based on comparison
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class StringComp implements Comparator<String> {
    @Override
    public int compare(String o1, String o2) {
        return (o1.toLowerCase()).compareTo(o2.toLowerCase());
    }
}
