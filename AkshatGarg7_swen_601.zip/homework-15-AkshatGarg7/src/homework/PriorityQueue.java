package homework;

import java.util.Comparator;

/**
 * Implementation of Queue as PriorityQueue
 *
 * @param <T> This describes my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */

public class PriorityQueue<T> implements Queue<T>{

    /**
     * Required Fields
     */
    private MyHeap<T> heap;

    /**
     * Constructor with comparator as parameter
     *
     * @param comparator my type comparator
     */
    public PriorityQueue(Comparator<T> comparator) {
        this.heap = new MyHeap<>(comparator);
    }

    /**
     * Constructor with null input
     */
    public PriorityQueue(){
        this(null);
    }

    /**
     * Adds the specified element based on min heap.
     *
     * @param value my type parameter value
     */
    @Override
    public void enqueue(T value) {
        heap.add(value);
    }

    /**
     * Returns a reference to the element at the top of the Heap queue.
     * The element is not removed from the heap.
     *
     * @return a reference to the element at the top of the heap
     */
    @Override
    public T peek() {
        return heap.getArray();
    }

    /**
     * Removes the element at the root of the heap and returns a
     * reference to it.
     *
     * @return removes the element at the root of the queue and returns a reference to it
     */
    @Override
    public T dequeue() {
        return heap.remove();
    }

    /**
     * Returns the number of elements currently in this queue.
     *
     * @return the number of elements currently in this queue
     */
    @Override
    public int size() {
        return heap.size();
    }
}
