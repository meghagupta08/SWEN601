package homework;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Test for MyHeap implementation
 *
 * @author Akshat Garg ag2193@rit.edu
 */

class MyHeapTest {
    /**
     * Initial condition of myHeap check.
     */
    @Test
    public void initialCond(){
        //setup
        MyHeap<String> heap = new MyHeap<>();
        String expected = "MyHeap{array=[null, null, null, null, null, null, null, null], size=0}";
        //invoke
        String actual = heap.toString();
        //assert
        assertEquals(expected,actual);
    }

    /**
     * Adding elements to heap and taking output.
     */
    @Test
    public void addCond(){
        //setup
        MyHeap<Integer> heap = new MyHeap<>();
        String expected = "MyHeap{array=[7, 10, 21, 60, 50, 24, 43, null], size=7}";

        //invoke
        heap.add(60);
        heap.add(7);
        heap.add(21);
        heap.add(50);
        heap.add(10);
        heap.add(24);
        heap.add(43);
        String actual = heap.toString();
        //assert
        assertEquals(expected,actual);
    }

    /**
     * adding more element than initial array size
     */
    @Test
    public void addMoreCond(){
        //setup
        MyHeap<Integer> heap = new MyHeap<>();
        String expected = "MyHeap{array=[1, 7, 21, 10, 50, 24, 43, 60, 100, null, null, null, null, null, null, null], size=9}";

        //invoke
        heap.add(60);
        heap.add(7);
        heap.add(21);
        heap.add(50);
        heap.add(10);
        heap.add(24);
        heap.add(43);
        heap.add(1);
        heap.add(100);
        String actual = heap.toString();
        //assert
        assertEquals(expected,actual);
    }

    /**
     * removing elements from heap
     */
    @Test
    public void removeCond(){
        //setup
        Heap<Integer> heap = new MyHeap<>();
        String expected = "MyHeap{array=[10, 43, 21, 60, 50, 24, null, null], size=6}";

        //invoke
        heap.add(60);
        heap.add(7);
        heap.add(21);
        heap.add(50);
        heap.add(10);
        heap.add(24);
        heap.add(43);
        heap.remove();
        String actual = heap.toString();
        //assert
        assertEquals(expected,actual);
    }

    /**
     * returning the size of heap
     */
    @Test
    public void sizeCond(){
        //setup
        MyHeap<Integer> heap = new MyHeap<>();
        int expected = 7;

        //invoke
        heap.add(60);
        heap.add(7);
        heap.add(21);
        heap.add(50);
        heap.add(10);
        heap.add(24);
        heap.add(43);
        int actual = heap.size();
        //assert
        assertEquals(expected,actual);
    }

    /**
     * comparator pass check
     */
    @Test
    public void passingComparatorTest(){
        //setup
        MyHeap<String> heap = new MyHeap<>(new StringComp());
        String expected = "MyHeap{array=[a, dgh, bn, tgd, vbj, qw, ehk, z], size=8}";
        //invoke
        heap.add("a");
        heap.add("z");
        heap.add("ehk");
        heap.add("vbj");
        heap.add("tgd");
        heap.add("qw");
        heap.add("bn");
        heap.add("dgh");
        String actual = heap.toString();
        //assert
        assertEquals(expected,actual);
    }
}