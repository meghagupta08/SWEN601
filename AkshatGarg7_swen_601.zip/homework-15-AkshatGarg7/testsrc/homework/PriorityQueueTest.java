package homework;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PriorityQueueTest {
    /**
     * Checking queue enqueue for single enqueue
     */
    @Test
    public void queueEnqueueSingle() {
        //setup
        Queue<String> queue = new PriorityQueue<>(new StringComp());
        String input = "abc";
        int expected = 1;

        //invoke
        queue.enqueue(input);
        int actual = queue.size();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking integer queue enqueue for single enqueue
     */
    @Test
    public void queueEnqueueSingleInteger() {
        //setup
        Queue<Integer> queue = new PriorityQueue<>();
        int input = 1;
        int expected = 1;

        //invoke
        queue.enqueue(input);
        int actual = queue.size();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking queue enqueue for single enqueue
     */
    @Test
    public void queueEnqueueMultiple() {
        //setup
        Queue<String> queue = new PriorityQueue<>(new StringComp());
        int expected = 2;

        //invoke
        queue.enqueue("abc");
        queue.enqueue("def");
        int actual = queue.size();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking integer queue enqueue for single enqueue
     */
    @Test
    public void queueEnqueueMultipleInteger() {
        //setup
        Queue<Integer> queue = new PriorityQueue<>();
        int expected = 5;

        //invoke
        queue.enqueue(5);
        queue.enqueue(3);
        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(4);
        int actual = queue.size();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking queue enqueue to see if array doubles when reached at its capacity
     */
    @Test
    public void queueEnqueueMoreThanCapacity() {
        //setup
        Queue<String> queue = new PriorityQueue<>(new StringComp());
        int expected = 5;

        //invoke
        queue.enqueue("abc");
        queue.enqueue("def");
        queue.enqueue("ghi");
        queue.enqueue("jkl");
        queue.enqueue("mno");
        int actual = queue.size();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking integer queue enqueue to see if array doubles when reached at its capacity
     */
    @Test
    public void queueEnqueueMoreThanCapacityInteger() {
        //setup
        Queue<Integer> queue = new PriorityQueue<>();
        int expected = 10;

        //invoke
        queue.enqueue(5);
        queue.enqueue(3);
        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(4);
        queue.enqueue(6);
        queue.enqueue(9);
        queue.enqueue(7);
        queue.enqueue(0);
        queue.enqueue(8);
        int actual = queue.size();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking queue peek for single element in queue
     */
    @Test
    public void queuePeekSingle() {
        //setup
        Queue<String> queue = new PriorityQueue<>(new StringComp());
        queue.enqueue("abc");
        String expected = "abc";

        //invoke
        String actual = queue.peek();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking integer queue peek for single element in queue
     */
    @Test
    public void queuePeekSingleInteger() {
        //setup
        Queue<Integer> queue = new PriorityQueue<>();
        queue.enqueue(1);
        int expected = 1;

        //invoke
        int actual = queue.peek();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking queue peek for multiple element in queue
     */
    @Test
    public void queuePeekMultiple() {
        //setup
        Queue<String> queue = new PriorityQueue<>(new StringComp());
        queue.enqueue("zbc");
        queue.enqueue("def");
        queue.enqueue("ghi");
        String expected = "def";

        //invoke
        String actual = queue.peek();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking integer queue peek for multiple element in queue
     */
    @Test
    public void queuePeekMultipleInteger() {
        //setup
        Queue<Integer> queue = new PriorityQueue<>();
        queue.enqueue(5);
        queue.enqueue(3);
        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(4);
        int expected = 1;

        //invoke
        int actual = queue.peek();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking queue dequeue for single element in queue
     */
    @Test
    public void queueDequeueSingle() {
        //setup
        Queue<String> queue = new PriorityQueue<>(new StringComp());
        queue.enqueue("abc");
        String expected = "abc";

        //invoke
        String actual = queue.dequeue();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking integer queue dequeue for single element in queue
     */
    @Test
    public void queueDequeueSingleInteger() {
        //setup
        Queue<Integer> queue = new PriorityQueue<>();
        queue.enqueue(1);
        int expected = 1;

        //invoke
        int actual = queue.dequeue();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking queue dequeue for multiple element in queue
     */
    @Test
    public void queueDequeueMultiple() {
        //setup
        Queue<String> queue = new PriorityQueue<>(new StringComp());
        queue.enqueue("abc");
        queue.enqueue("def");
        queue.enqueue("ghi");
        String expected = "abc\ndef\nghi";

        //invoke
        StringBuilder actual = new StringBuilder();
        while (queue.size() > 1) {
            String a = queue.dequeue();
            actual.append(a).append("\n");
        }
        actual.append(queue.dequeue());

        //assert
        assertEquals(expected, actual.toString());
    }

    /**
     * Checking integer queue dequeue for multiple element in queue
     */
    @Test
    public void queueDequeueMultipleInteger() {
        //setup
        Queue<Integer> queue = new PriorityQueue<>();
        queue.enqueue(5);
        queue.enqueue(3);
        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(4);
        String expected = "1 2 3 4 5";

        //invoke
        StringBuilder actual = new StringBuilder();
        while (queue.size() > 1) {
            int a = queue.dequeue();
            actual.append(a).append(" ");
        }
        actual.append(queue.dequeue());

        //assert
        assertEquals(expected, actual.toString());
    }

    /**
     * Checking queue dequeue for zero element in queue
     */
    @Test
    public void queueDequeueZero() {
        // Code is expected to throw an Array out of bound exception
        // because there is no element to dequeue in array queue
        // Hence this assertion will pass
        Queue<String> queue = new PriorityQueue<>(new StringComp());
        assertThrows(ArrayIndexOutOfBoundsException.class, queue::dequeue);
    }

    /**
     * Checking integer queue dequeue for zero element in queue
     */
    @Test
    public void queueDequeueZeroInteger() {
        // Code is expected to throw an Array out of bound exception
        // because there is no element to dequeue in array queue
        // Hence this assertion will pass
        Queue<Integer> queue = new PriorityQueue<>();
        assertThrows(ArrayIndexOutOfBoundsException.class, queue::dequeue);
    }

    /**
     * If no comparator is passed the output is wrong
     */
    @Test
    public void comparatorNoPass(){
        //setup
        Queue<String> queueString = new PriorityQueue<>();
        queueString.enqueue("a");
        queueString.enqueue("Z");
        queueString.enqueue("Ehk");
        queueString.enqueue("vBj");
        queueString.enqueue("tgD");
        queueString.enqueue("qW");
        queueString.enqueue("bN");
        queueString.enqueue("DgH");
        String expected = "[DgH,Ehk,Z,a,bN,qW,tgD,vBj]";

        //invoke
        StringBuilder actual = new StringBuilder("[");
        while (queueString.size() > 1) {
            String a = queueString.dequeue();
            actual.append(a).append(",");
        }
        actual.append(queueString.dequeue()).append("]");

        //assert
        assertEquals(expected,actual.toString());
    }

    /**
     * If comparator is passed the output is correct
     */
    @Test
    public void comparatorPass(){
        //setup
        Queue<String> queueString = new PriorityQueue<>(new StringComp());
        queueString.enqueue("a");
        queueString.enqueue("Z");
        queueString.enqueue("Ehk");
        queueString.enqueue("vBj");
        queueString.enqueue("tgD");
        queueString.enqueue("qW");
        queueString.enqueue("bN");
        queueString.enqueue("DgH");
        String expected = "[a,bN,DgH,Ehk,qW,tgD,vBj,Z]";

        //invoke
        StringBuilder actual = new StringBuilder("[");
        while (queueString.size() > 1) {
            String a = queueString.dequeue();
            actual.append(a).append(",");
        }
        actual.append(queueString.dequeue()).append("]");

        //assert
        assertEquals(expected,actual.toString());
    }
}