package homework;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Test for StringComp
 *
 * @author Akshat Garg ag2193@rit.edu
 */

class StringCompTest {

    /**
     * both string lower check
     */
    @Test
    public void lowerTest(){
        //setup
        StringComp stringComp = new StringComp();
        int expected = -1;
        //invoke
        int actual = stringComp.compare("abcgvxgbsgderg","bcdewffdgbdbhdt");
        //assert
        assertEquals(expected,actual);
    }

    /**
     * both string upper check
     */
    @Test
    public void upperTest(){
        //setup
        StringComp stringComp = new StringComp();
        int expected = -1;
        //invoke
        int actual = stringComp.compare("ABC","BCD");
        //assert
        assertEquals(expected,actual);
    }

    /**
     * both string random upper and lower case letter check
     */
    @Test
    public void upperLowerTest(){
        //setup
        StringComp stringComp = new StringComp();
        int expected = -1;
        //invoke
        int actual = stringComp.compare("aBc","Bcd");
        //assert
        assertEquals(expected,actual);
    }

    /**
     * both string same check
     */
    @Test
    public void equalTest(){
        //setup
        StringComp stringComp = new StringComp();
        int expected = 0;
        //invoke
        int actual = stringComp.compare("abC","ABc");
        //assert
        assertEquals(expected,actual);
    }

    /**
     * if first string is bigger than another one
     */
    @Test
    public void moreTest(){
        //setup
        StringComp stringComp = new StringComp();
        int expected = 2;
        //invoke
        int actual = stringComp.compare("CAsvcdzxzv","adzfgesvsdzv");
        //assert
        assertEquals(expected,actual);
    }
}