package activities;

public interface Map<K,V> { //K = String, V = Patron //(example)
    void put(K key, V value);
    V get(K key);
    int size();
}
