package activities;

public class HashingMap<K,V> implements Map<K,V>{

    private Object[] entries;//private Entry<K,V>[] entries;
    private int size;

    public HashingMap(Object[] entries) {
        entries = new Object[100];//new Entry<K,V>[100];
        size = 0;
    }

    private int getIndex(K key){
        int hashCode = key.hashCode();
        if(hashCode < 0){
            hashCode *= -1;
        }
        int index = hashCode % entries.length;
        return index;
    }

    @Override
    public void put(K key, V value) {
       int index = getIndex(key);//int hashCode = key.hashCode();
       Entry<K,V> entry = new Entry<>(key,value);
       entries[index] = entry;
       size++;
    }

    @Override
    public V get(K key) {
        int index = getIndex(key);//int hashCode = key.hashCode();
        Entry<K,V> entry = (Entry<K, V>) entries[index];
        return entry.getValue();
    }

    @Override
    public int size() {
        return size;
    }
}
