package homework;

import java.util.HashMap;

/**
 * An example of HashMap implementation in java
 *
 * @author Akshat Garg ag2193@rit.edu
 */
public class HashMapTest {
    /**
     * main method few methods of HashMap in java
     *
     * @param args none
     */
    public static void main(String[] args) {
        HashMap<String,Integer> hashmap = new HashMap<>();
        //Adding elements to HashMap
        hashmap.put("Apple", 1);
        hashmap.put("Banana", 2);
        hashmap.put("Mango", 3);
        hashmap.put("Grapes", 4);
        System.out.println("Our hashmap created-> " + hashmap);

        //Returning value of particular value
        System.out.println("Returning the value of \"Apple\" : " + hashmap.get("Apple"));

        //Removing the newly added key
        hashmap.put("Cherry",5);
        System.out.println("Our new hashmap created-> " + hashmap);
        hashmap.remove("Cherry");
        System.out.println("After removing a key from hashmap-> " + hashmap);

        //Two same key different value
        hashmap.put("Grapes", 6);
        System.out.println("Returning the value of \"Grapes\" : " + hashmap.get("Grapes")); //returns new value for key

        //Size of hashmap
        System.out.println("Size of hashmap-> " + hashmap.size());

        //Iterate over the keys in hashmap using for each loop
        System.out.println("Iterating over hashmap->");
        for(String fruit : hashmap.keySet()){
            System.out.println("key: " + fruit + " value: " + hashmap.get(fruit));
        }
    }
}
