package homework;

import java.util.Iterator;

/**
 * Main method to test the implementation of set
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class MapSetMain {

    /**
     * returns a String of converted map key to string
     *
     * @param mapSet Integer type MapSet parameter
     * @return String of converted map set
     */
    private static String stringConv(MapSet<Integer> mapSet){
        Iterator<Integer> i = mapSet.iterator();
        StringBuilder actual = new StringBuilder("{");
        while(i.hasNext()){
            Object entry = i.next();//key value in mapSet
            if(!i.hasNext()){//if last element
                actual.append(entry).append("}");
            }else{//every element except last element
                actual.append(entry).append(",");
            }
        }
        return actual.toString();
    }

    /**
     * main method to test implementation
     *
     * @param args none
     */
    public static void main(String[] args) {
        //initialization
        MapSet<Integer> ms = new MapSet<>();

        //adding the elements
        for(int i = 0; i < 20; i++){
            ms.add(i);
        }
        System.out.println("After adding element: " + stringConv(ms));
        System.out.println("size after adding the elements -> " + ms.size()); //20

        //trying to add duplicate
        ms.add(10);
        ms.add(15);
        System.out.println("\ntrying to add duplicate -> "  + stringConv(ms));
        System.out.println("size after trying to add duplicate -> "+ms.size()); //20

        //removing the element
        ms.remove(13);
        ms.remove(3);
        System.out.println("\nafter removing the element-> "  + stringConv(ms));
        System.out.println("size after removing the element-> "+ms.size()); //18

        //removing the element not present in list
        ms.remove(34);
        ms.remove(23);
        System.out.println("\nremoving the element not present in list-> " + stringConv(ms));
        System.out.println("size after removing the element not present in list-> "+ms.size()); //18

        //checking if element is present or not
        System.out.println("\nElement \"20\" present-> " + ms.contains(20)); //false
        System.out.println("Element \"5\" present-> " + ms.contains(5)); //true
    }
}
