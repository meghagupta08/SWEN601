package homework;

import java.util.HashMap;
import java.util.Iterator;

/**
 * Implementation of Set using Map and HashMap
 *
 * @param <E> my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */

public class MapSet<E> implements Set<E>{

    //Required Fields
    private HashMap<E,Object> mapset;
    int size;
    private static final Object PRESENT = null; //dummy value

    //constructor
    public MapSet() {
        this.mapset = new HashMap<>();
        this.size = 0;
    }

    /**
     * Adds a new element to the set. If element is present it ignores
     * the repeated value.
     *
     * @param element My type element to be added to set.
     */
    @Override
    public void add(E element) {
        if(!mapset.containsKey(element)) { //if element is already present it will not add
            this.mapset.put(element, PRESENT);
            this.size++;
        }
    }

    /**
     * Removes an element from the set.
     *
     * @param element My type element to be removed to set.
     */
    @Override
    public void remove(E element) {
        if(mapset.containsKey(element)) { //if element is present then it would be removed else no
            this.mapset.remove(element);
            this.size--;
        }
    }

    /**
     * Returns true if the element is in the set, else false
     *
     * @param element to be searched in set
     * @return true if present else false
     */
    @Override
    public boolean contains(E element) {
        return mapset.containsKey(element);
    }

    /**
     * Returns size of set
     *
     * @return size of set
     */
    @Override
    public int size() {
        return this.size;
    }

    /**
     * Returns an iterator that
     * can be used to
     * iterate over the elements in the set.
     *
     * @return an iterator that can be used to iterate over the elements in the set.
     */
    @Override
    public Iterator<E> iterator() {
        return mapset.keySet().iterator();
    }
}
