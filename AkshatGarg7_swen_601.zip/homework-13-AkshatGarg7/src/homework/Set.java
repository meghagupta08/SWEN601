package homework;

import java.util.Iterator;

/**
 * Interface of Set with generic type parameter E
 *
 * @param <E> my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */

public interface Set<E> {

    /**
     * Adds a new element to the set. If element is present it ignores
     * the repeated value.
     *
     * @param element My type element to be added to set.
     */
    void add(E element);

    /**
     * Removes an element from the set.
     *
     * @param element My type element to be removed to set.
     */
    void remove(E element);

    /**
     * Returns true if the element is in the set, else false
     *
     * @param element to be searched in set
     * @return true if present else false
     */
    boolean contains(E element);

    /**
     * Returns size of set
     *
     * @return size of set
     */
    int size();

    /**
     * Returns an iterator that
     * can be used to
     * iterate over the elements in the set.
     *
     * @return an iterator that can be used to iterate over the elements in the set.
     */
    Iterator<E> iterator();
}
