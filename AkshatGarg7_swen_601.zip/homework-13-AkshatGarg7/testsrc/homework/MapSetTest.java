package homework;

import org.junit.jupiter.api.Test;
import java.util.Iterator;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Test to test the MapSet implementation of Set and HashMap
 *
 * @author Akshat Garg ag2193@rit.edu
 */
class MapSetTest {
    /**
     * Adding only single element in MapSet
     */
    @Test
    public void addSingle() {
        //setup
        MapSet<Integer> ms = new MapSet<>();
        int input = 5;
        int expected = 1;

        //invoke
        ms.add(input);
        int actual = ms.size();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Adding multiple element in MapSet
     */
    @Test
    public void addMultiple() {
        //setup
        MapSet<Integer> ms = new MapSet<>();
        int expected = 5;

        //invoke
        for(int i = 0; i < 5; i++) {
            ms.add(i); //adding element from 0 to 4
        }
        int actual = ms.size();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Adding duplicate element in MapSet
     */
    @Test
    public void addDuplicate() {
        //setup
        MapSet<Integer> ms = new MapSet<>();
        int input = 5;
        int expected = 3;

        //invoke
        ms.add(input);
        ms.add(6);
        ms.add(7);
        ms.add(input); //duplicate
        int actual = ms.size();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Removing an element in MapSet of size = 1
     */
    @Test
    public void removeSingle() {
        //setup
        MapSet<Integer> ms = new MapSet<>();
        int input = 5;
        ms.add(input);
        int expected = 0;

        //invoke
        ms.remove(input);
        int actual = ms.size();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Removing an element in MapSet of size > 1
     */
    @Test
    public void removeMultiple() {
        //setup
        MapSet<Integer> ms = new MapSet<>();
        for(int i = 0; i < 5; i++) {
            ms.add(i);
        }
        int input = 2; // any random value to be removed from MapSet
        int expected = 4;

        //invoke
        ms.remove(input);
        int actual = ms.size();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Removing an element not in MapSet of size => 1
     */
    @Test
    public void removeNotPresentInMap() {
        //setup
        MapSet<Integer> ms = new MapSet<>();
        for(int i = 0; i < 5; i++) {
            ms.add(i);
        }
        int input = 6; // not present in MapSet
        int expected = 5;

        //invoke
        ms.remove(input);
        int actual = ms.size();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking if an element in MapSet is present or not
     */
    @Test
    public void containsNotPresentInMap() {
        //setup
        MapSet<Integer> ms = new MapSet<>();
        for(int i = 0; i < 5; i++) {
            ms.add(i);
        }
        int input = 6; // not present in MapList
        boolean expected = false;

        //invoke
        boolean actual = ms.contains(input);//false

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking if an element in MapSet is present or not
     */
    @Test
    public void removePresentInMap() {
        //setup
        MapSet<Integer> ms = new MapSet<>();
        for(int i = 0; i < 5; i++) {
            ms.add(i);
        }
        int input = 2;//Element present
        boolean expected = true;

        //invoke
        boolean actual = ms.contains(input);//true

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checking if iterator works in MapSet
     */
    @Test
    public void iteratorMultiple() {
        //setup
        MapSet<String> ms = new MapSet<>();
        ms.add("a");
        ms.add("b");
        ms.add("c");
        ms.add("d");
        ms.add("e");
        String expected = "{a,b,c,d,e}"; //expected output

        //invoke
        Iterator<String> i = ms.iterator();
        StringBuilder actual = new StringBuilder("{");
        while(i.hasNext()){
            String entry = i.next();
            if(!i.hasNext()){
                actual.append(entry).append("}");
            }else{
                actual.append(entry).append(",");
            }
        }


        //assert
        assertEquals(expected, actual.toString());
    }
}