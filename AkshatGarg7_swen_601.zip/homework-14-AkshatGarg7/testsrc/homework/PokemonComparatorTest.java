package homework;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit test for PokemonComparator
 * @author Akshat Garg ag2193@rit.edu
 */
class PokemonComparatorTest {
    /**
     * if a > b
     */
    @Test
    public void lessTest(){
        //Setup
        Pokemon a = new Pokemon("Pikachu",25);
        Pokemon b = new Pokemon("Charliezard", 9);
        PokemonComparator<Pokemon> comparator = new PokemonComparator<>();
        int expected = -16;

        //Invoke
        int actual = comparator.compare(a,b);

        //Assert
        assertEquals(expected,actual);
    }

    /**
     * if a = b
     */
    @Test
    public void equalTest(){
        //Setup
        Pokemon a = new Pokemon("Pikachu",25);
        Pokemon b = new Pokemon("Pikachu", 25);
        PokemonComparator<Pokemon> comparator = new PokemonComparator<>();
        int expected = 0;

        //Invoke
        int actual = comparator.compare(a,b);

        //Assert
        assertEquals(expected,actual);
    }

    /**
     * if a < b
     */
    @Test
    public void moreTest(){
        //Setup
        Pokemon a = new Pokemon("Pikachu",25);
        Pokemon b = new Pokemon("Piku", 50);
        PokemonComparator<Pokemon> comparator = new PokemonComparator<>();
        int expected = 25;

        //Invoke
        int actual = comparator.compare(a,b);

        //Assert
        assertEquals(expected,actual);
    }
}