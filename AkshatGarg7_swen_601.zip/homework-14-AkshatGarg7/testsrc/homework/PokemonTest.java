package homework;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit test for Pokemon
 * @author Akshat Garg ag2193@rit.edu
 */
class PokemonTest {
    /**
     * Checks if pokemon name and number is passed properly or not
     */
    @Test
    public void nameNumberTest() {
        //setup
        Pokemon p = new Pokemon("Pikachu", 25);
        String expectedName = "Pikachu";
        int expectedNumber = 25;

        //invoke
        String actualName = p.getName();
        int actualNumber = p.getNumber();

        //assert
        assertEquals(expectedName, actualName);
        assertEquals(expectedNumber, actualNumber);
    }
    /**
     * Checks if pokemon toString is passed properly or not
     */
    @Test
    public void stringTest() {
        //setup
        Pokemon p = new Pokemon("Pikachu", 25);
        String expected = "Pikachu(25)";

        //invoke
        String actual = p.toString();

        //assert
        assertEquals(expected, actual);
    }

    /**
     * Checks if pokemon and object are equal or not
     */
    @Test
    public void equalsFalseTest(){
        //setup
        Pokemon p = new Pokemon("Pikachu", 25);
        Object o = new Pokemon("Pika",118);
        boolean expected = false;

        //invoke
        boolean actual = p.equals(o);

        //assert
        assertEquals(expected, actual);
    }

    @Test
    public void equalsTrueTest(){
        //setup
        Pokemon p = new Pokemon("Pikachu", 25);
        Object o = new Pokemon("Pikachu",25);
        boolean expected = true;

        //invoke
        boolean actual = p.equals(o);

        //assert
        assertEquals(expected, actual);
    }

    @Test
    public void hashCodeTest() {
        //setup
        Pokemon p = new Pokemon("Pikachu", 25);
        int expected = 25;

        //invoke
        int actual = p.hashCode();

        //assert
        assertEquals(expected, actual);
    }

    @Test
    public void compareLessTest(){
        //setup
        Pokemon p = new Pokemon("Pikachu", 25);
        Pokemon o = new Pokemon("Charlizard",9);
        int expected = 16;

        //invoke
        int actual = p.compareTo(o);

        //assert
        assertEquals(expected, actual);
    }
    @Test
    public void equalTest(){
        //Setup
        Pokemon a = new Pokemon("Pikachu",25);
        Pokemon b = new Pokemon("Pikachu", 25);
        int expected = 0;

        //Invoke
        int actual = a.compareTo(b);

        //Assert
        assertEquals(expected,actual);
    }

    @Test
    public void moreTest(){
        //Setup
        Pokemon a = new Pokemon("Pikachu",25);
        Pokemon b = new Pokemon("Piku", 50);
        int expected = -25;

        //Invoke
        int actual = a.compareTo(b);

        //Assert
        assertEquals(expected,actual);
    }
}