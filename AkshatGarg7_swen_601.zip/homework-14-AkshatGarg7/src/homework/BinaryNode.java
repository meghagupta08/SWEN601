package homework;
import java.util.Comparator;

/**
 * BinaryNode implements BST methods for Pokemon
 *
 * @param <T> my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */

public class BinaryNode<T> {
    //Fields
    private T value;
    private BinaryNode<T> left, right;
    private Comparator<T> comparator;

    //Constructor
    public BinaryNode(T value, Comparator<T> comparator) {
        this.value = value;
        this.comparator = comparator;
        this.left = null;
        this.right = null;
    }

    //Constructor is comparator is null
    public BinaryNode(T value) {
        this(value, null);
    }

    /**
     * @return left node value
     */
    public BinaryNode<T> getLeft() {
        return left;
    }

    /**
     * @return right node value
     */
    public BinaryNode<T> getRight() {
        return right;
    }

    /**
     * @param left sets left node value
     */
    public void setLeft(BinaryNode<T> left) {
        this.left = left;
    }

    /**
     * @param right sets right node value
     */
    public void setRight(BinaryNode<T> right) {
        this.right = right;
    }

    /**
     * @return current node value
     */
    public T getValue() {
        return value;
    }

    /**
     * Checks if comparator is passed or not. And compare based on input.
     *
     * @return compared value, i.e., <,=,> 0.
     */
    public int compare(T a, T b) {
        if (comparator != null) {
            return comparator.compare(b, a);
        } else {
            //casting a and b into instances comparable
            Comparable<T> aCom = (Comparable<T>) a;
            Comparable<T> bCom = (Comparable<T>) b;
            return aCom.compareTo((T) bCom);
            //return ((Pokemon)a).compareTo(b);
        }
    }

    /**
     * Traverses through the binary tree in infix order
     *
     * @param visitor node to be visited
     */
    public void infixTraversal(Visitor<T> visitor) {
        if (comparator != null) { //traversing in opposite order
            //if the right subtree is not null, visit it
            if (right != null) {
                right.infixTraversal(visitor);
            }

            //then visit this node
            visitor.visit(this);

            //if the left subtree is not null, visit it
            if (left != null) {
                left.infixTraversal(visitor);
            }
        }
        else {
            //if the left subtree is not null, visit it
            if (left != null) {
                left.infixTraversal(visitor);
            }

            //then visit this node
            visitor.visit(this);

            //if the right subtree is not null, visit it
            if (right != null) {
                right.infixTraversal(visitor);
            }
        }
    }


    /**
     * Inserting node in binary tree.
     *
     * @param value node to inserted
     */
    public void binaryInsert(T value) {
        if (compare(this.value, value) > 0) {
            //if(value < this.value){
            if (left == null) {
                this.left = new BinaryNode<T>(value, this.comparator);
            } else {
                left.binaryInsert(value);
            }
        } else {
            if (right == null) {
                this.right = new BinaryNode<T>(value, this.comparator);
            } else {
                right.binaryInsert(value);
            }
        }
    }


    /**
     * Searches for the node in bst and returns true if found else false
     *
     * @param target node to searched
     * @return true if found else false
     */
    public boolean binarySearch(T target) {
        if (compare(this.value, target) == 0) {
            return true;
        } else if (compare(this.value, target) > 0 && left != null) { // else if(target < this.value)
            return left.binarySearch(target); //return left !=null && left.binarySearch(target)
        } else if (compare(this.value, target) < 0 && right != null) { // else if(target > this.value)
            return right.binarySearch(target);//return right !=null && right.binarySearch(target)
        }
        return false;
    }

    /**
     * @return Custom toString
     */
    @Override
    public String toString(){
        return "BinaryNode{"
                +"value=" + this.value
                +" left=" + this.left
                +" right="+ this.right
                +"}";
    }
}
