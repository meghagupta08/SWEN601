package homework;

public class Main {
    public static void main(String[] args) {
//        BinaryNode<Integer> root = new BinaryNode<>(5);
//
//        BinaryNode<Integer> left = new BinaryNode<Integer>(3);
//        left.setLeft(new BinaryNode<Integer>(1));
//        left.setRight(new BinaryNode<Integer>(4));
//        root.setLeft(left);
//
//        BinaryNode<Integer> right = new BinaryNode<Integer>(6);
//        right.setLeft(new BinaryNode<Integer>(7));
//        right.setRight(new BinaryNode<Integer>(9));
//        root.setRight(right);
//
//        Visitor visitor = new StringVisitor();
//        root.infixTraversal(visitor);
//        System.out.println(visitor);
//
//        System.out.println(root.search(11));
//        System.out.println(root.search(9));
//        System.out.println(root.search(4));
//
////        BinaryNode<Integer> bst = new BinaryNode<Integer>(9);
////        bst.binaryInsert(7);
////        bst.binaryInsert(8);
////        bst.binaryInsert(16);
////        bst.binaryInsert(2);
////        bst.binaryInsert(11);
////        bst.binaryInsert(3);
////        bst.binaryInsert(10);
////        System.out.println(bst);
//
////        visitor = new StringVisitor();
////        bst.infixTraversal(visitor);
////        System.out.println(visitor);
////
////        System.out.println(bst.search(3));
////        System.out.println(bst.search(4));
//    }
//}
    }
}