package homework;

/**
 * Visits the node in bst
 *
 * @param <T> my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */

public interface Visitor<T> {
    void visit(BinaryNode<T> node);
}
