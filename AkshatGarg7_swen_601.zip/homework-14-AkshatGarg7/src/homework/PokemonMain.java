package homework;

/**
 * main function for BinaryNode and Pokemon
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class PokemonMain {
    /**
     * Testing BinaryNode and Pokemon
     * @param args None
     */
    public static void main(String[] args) {
        //if comparator is passed
        BinaryNode<Pokemon> rootPokemon = new BinaryNode<>(new Pokemon("Bellsprout", 69),new PokemonComparator<>());
        rootPokemon.binaryInsert(new Pokemon("Sandslash", 28));
        rootPokemon.binaryInsert(new Pokemon("Hypno", 97));
        rootPokemon.binaryInsert(new Pokemon("Pidgeot", 18));
        rootPokemon.binaryInsert(new Pokemon("Diglett", 50));
        rootPokemon.binaryInsert(new Pokemon("Grimer", 88));
        rootPokemon.binaryInsert(new Pokemon("Marowak", 105));
        rootPokemon.binaryInsert(new Pokemon("Bulbasaur", 1));
        rootPokemon.binaryInsert(new Pokemon("Raticate", 20));
        rootPokemon.binaryInsert(new Pokemon("Arcanine", 59));
        rootPokemon.binaryInsert(new Pokemon("Slowbro", 80));
        rootPokemon.binaryInsert(new Pokemon("Drowzee", 96));
        rootPokemon.binaryInsert(new Pokemon("Ponyta", 77));
        rootPokemon.binaryInsert(new Pokemon("Natu", 177));

        System.out.println(rootPokemon);
        System.out.println(rootPokemon.binarySearch(new Pokemon("Slowbro", 80)));
        System.out.println(rootPokemon.binarySearch(new Pokemon("Doduo", 84)));
        StringVisitor<Pokemon> string = new StringVisitor<>();
        rootPokemon.infixTraversal(string);
        System.out.println(string);
        System.out.println("\n\n----------------------------------------------------------------------------------------------------\n\n");

        //if comparator is not passed and comparable is used
        BinaryNode<Pokemon> rootPokemonNew = new BinaryNode<>(new Pokemon("Bellsprout", 69));
        rootPokemonNew.binaryInsert(new Pokemon("Sandslash", 28));
        rootPokemonNew.binaryInsert(new Pokemon("Hypno", 97));
        rootPokemonNew.binaryInsert(new Pokemon("Pidgeot", 18));
        rootPokemonNew.binaryInsert(new Pokemon("Diglett", 50));
        rootPokemonNew.binaryInsert(new Pokemon("Grimer", 88));
        rootPokemonNew.binaryInsert(new Pokemon("Marowak", 105));
        rootPokemonNew.binaryInsert(new Pokemon("Bulbasaur", 1));
        rootPokemonNew.binaryInsert(new Pokemon("Raticate", 20));
        rootPokemonNew.binaryInsert(new Pokemon("Arcanine", 59));
        rootPokemonNew.binaryInsert(new Pokemon("Slowbro", 80));
        rootPokemonNew.binaryInsert(new Pokemon("Drowzee", 96));
        rootPokemonNew.binaryInsert(new Pokemon("Ponyta", 77));
        rootPokemonNew.binaryInsert(new Pokemon("Natu", 177));

        System.out.println(rootPokemonNew);
        System.out.println(rootPokemonNew.binarySearch(new Pokemon("Slowbro", 80)));
        System.out.println(rootPokemonNew.binarySearch(new Pokemon("Doduo", 84)));
        StringVisitor<Pokemon> stringNew = new StringVisitor<>();
        rootPokemonNew.infixTraversal(stringNew);
        System.out.println(stringNew);
    }
}
