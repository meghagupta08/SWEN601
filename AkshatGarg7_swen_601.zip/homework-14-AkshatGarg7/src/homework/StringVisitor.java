package homework;

/**
 * StringVisitor Implements of Visitor
 *
 * @param <T> my type parameter
 * @author Akshat Garg ag2193@rit.edu
 */

public class StringVisitor<T> implements Visitor<T> {

    //fields
    private StringBuilder builder;

    //constructor
    public StringVisitor() {
        this.builder = new StringBuilder();
    }

    /**
     * value of current node is stored in builder
     * @param node current value of node in bst
     */
    @Override
    public void visit(BinaryNode<T> node) {
        builder.append(node.getValue());
        builder.append(" ");
    }

    /**
     * @return builder in String
     */
    @Override
    public String toString(){
        return builder.toString();
    }
}
