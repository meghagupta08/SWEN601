package activities;

public class SumVisitor implements Visitor{

    private int sum;

    public SumVisitor() {
        this.sum = 0;
    }

    @Override
    public void visit(BinaryNode node) {
        sum += node.getValue();
    }

    @Override
    public String toString(){
        return Integer.toString(sum);
    }
}
