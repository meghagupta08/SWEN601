package activities;

public interface Visitor {
    void visit(BinaryNode node);
}
