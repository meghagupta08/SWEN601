package activities;

public class BinaryNode {
    private int value;
    private BinaryNode left, right;

    public BinaryNode(int value) {
        this.value = value;
        this.left = null;
        this.right = null;
    }

    public BinaryNode getLeft() {
        return left;
    }

    public BinaryNode getRight() {
        return right;
    }

    public void setLeft(BinaryNode left) {
        this.left = left;
    }

    public void setRight(BinaryNode right) {
        this.right = right;
    }

    public int getValue() {
        return value;
    }

    public void infixTraversal(Visitor visitor){
        //if the left subtree is not null, visit it
        if(left != null){
            left.infixTraversal(visitor);
        }
        //then visit this node
        visitor.visit(this);
        //if the right subtree is not null, visit it
        if(right != null){
            right.infixTraversal(visitor);
        }
    }

    public boolean search(int target){
        if(target == this.value){
            return true;
        }else{
            boolean found = false;
            if(left != null){
                found = left.search(target);
            }
            if(!found && right != null){
                found = right.search(target);
            }
            return found;
        }
    }

    public void binaryInsert(int value){
        if(value < this.value){
            if(left == null){
                this.left = new BinaryNode(value);
            }else{
                left.binaryInsert(value);
            }
        }else{
            if(right == null){
                this.right = new BinaryNode(value);
            }else{
                right.binaryInsert(value);
            }
        }
    }

    public boolean binarySearch(int target){

        //return target == this.value ? ((target < this.value && left != null) ? left.binarySearch() : )

        if(target == this.value){
            return true;
        }else if(target < this.value && left != null){ // else if(target < this.value)
            return left.binarySearch(target); //return left !=null && left.binarySearch(target)
        }else if(target > this.value && right != null){ // else if(target > this.value)
            return right.binarySearch(target);//return right !=null && right.binarySearch(target)
        }else{
            return false;
        }
    }

    @Override
    public String toString(){
        return "BinaryNode{"
                +"value=" + this.value
                +" left=" + this.left
                +" right="+ this.right
                +"}";
    }

    public static void main(String[] args) {
        BinaryNode root = new BinaryNode(5);
        root.setLeft(new BinaryNode(7));
        root.setRight(new BinaryNode(3));

        System.out.println(root);
    }
}
