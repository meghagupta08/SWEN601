package activities;

public class Main {
    public static void main(String[] args) {
        BinaryNode root = new BinaryNode(5);

        BinaryNode left = new BinaryNode(3);
        left.setLeft(new BinaryNode(1));
        left.setRight(new BinaryNode(4));
        root.setLeft(left);

        BinaryNode right = new BinaryNode(6);
        right.setLeft(new BinaryNode(7));
        right.setRight(new BinaryNode(9));
        root.setRight(right);

        Visitor visitor = new StringifyVisitor();
        root.infixTraversal(visitor);
        System.out.println(visitor);

        Visitor visitorSum = new SumVisitor();
        root.infixTraversal(visitorSum);
        System.out.println(visitorSum);

        System.out.println(root.search(11));
        System.out.println(root.search(9));
        System.out.println(root.search(4));

        BinaryNode bst = new BinaryNode(9);
        bst.binaryInsert(7);
        bst.binaryInsert(8);
        bst.binaryInsert(16);
        bst.binaryInsert(2);
        bst.binaryInsert(11);
        bst.binaryInsert(3);
        bst.binaryInsert(10);
        System.out.println(bst);

        visitor = new StringifyVisitor();
        bst.infixTraversal(visitor);
        System.out.println(visitor);

        System.out.println(bst.search(3));
        System.out.println(bst.search(4));
    }
}
