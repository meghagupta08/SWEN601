package activities;

public class StringifyVisitor implements Visitor{

    private StringBuilder builder;

    public StringifyVisitor() {
        this.builder = new StringBuilder();
    }

    @Override
    public void visit(BinaryNode node) {
        builder.append(node.getValue());
        builder.append(" ");
    }

    @Override
    public String toString(){
        return builder.toString();
    }
}
