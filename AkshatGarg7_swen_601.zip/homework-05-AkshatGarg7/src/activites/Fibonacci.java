package activites;

public class Fibonacci {
    public static int fib(int n) {
        if (n <= 0) {
            return 0;
        } else if (n == 1) {
            return 0;
        } else if (n == 2) {
            return 1;
        } else {
            return fib(n - 1) + fib(n - 2);
        }

    }

    public static void main(String[] args) {
        int n =1;
        while (n < 100) {
            System.out.println(fib(n));
            n++; //Takes too long because we are calculating same value again and again
        }
    }
}

