package activites;

public class Search {
    public static boolean sea(int[] array, int target){
        for(int i :array){
            if(i == target){
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        int[] array = new int[5];
        array[0] = 1;
        array[1] = 3;
        array[2] = 6;
        array[3] = 9;
        array[4] = 2;
        System.out.println(sea(array,9));
    }
}
