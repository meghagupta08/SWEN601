package activites;

import java.util.Scanner;

public class Recursion {

    public static void countdownrec(int n){
        if(n >= 0) {
            System.out.println(n);
            n--;
            countdownrec(n);
        }
    }

    public static void countdown(int n){
        for ( int i = n; i>=0; i--){
            System.out.println(i);
        }
    }

    public static void countup(int n){
        if(n >= 0){
            int rest = n - 1;
            countup(rest);
            System.out.println(n);

        }
    }
    public static void main(String[] args) {
        countup(10);
    }

}
