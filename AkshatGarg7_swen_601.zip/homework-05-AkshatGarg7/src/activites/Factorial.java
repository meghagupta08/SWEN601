package activites;

public class Factorial {

    public static int fact(int n) {
        /* if(n<0){
        return 0;}
        else if(n ==0 || n == 1){
        return 1}
        else{
        int next = n-1;
        int rest = fact(next);
        return n * rest;
        }w
         */
        if (n <= 1){
            return 1;
        }
        else {
            int next = n -1;
            int rest = fact(next);
            return n*rest;
            // return n*fact(n-1)
        }

    }

    public static void main(String[] args) {
        System.out.println(fact(5));

    }
}
