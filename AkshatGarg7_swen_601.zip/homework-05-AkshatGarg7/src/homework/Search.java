package homework;

import java.util.Scanner;

/**
 * Class Search finds the target value in the array and returns the index, if not found it returns 1.
 * It uses both linear search and binary search for finding the element.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class Search {
    /** Function LinearSearch finds the array from left to right in the array to find the target value and return the index of the same.
     * <p>
     * We traverse through the array to find the element and return the index of the element if found. We check
     * each element of the array from left to right.
     *
     * @param array integer type
     * @param target integer type, element to be checked
     * @return index if element is found or -1
     */

    public static int LinearSearch(int[] array, int target){
        for(int i = 0; i < array.length;i++){ // traversing through the array
            if(array[i] == target){ // if element is found return index
                return i;
            }
        }
        return -1; // element not found
    }
    /** Function binarySearch finds the target value in the array and returns the index of target or -1 if not found.
     * <p>
     * We check if target is in mid if not, we check if target value is less or more than mid value. If
     * target is more than mid we check from mid + 1 to last index, else if target is less than mid, we search through
     * start to mid -1 index. If the target is not found we return -1 else the index of the target in the array.
     *
     * @param array integer type
     * @param target integer type, element to be checked
     * @param s integer type, start of array
     * @param l integer type, end of array
     * @return index if element is found or -1
     */
    public static int binarySearch(int[] array, int target, int s, int l) {
        int m = (s + l) / 2; // finding the mid index
        if ( s > l) { // if start is more than last index we return -1
            return -1;
        } else if (array[m] == target) { // checking if target is equal to mid
            return m;
        } else if (target < array[m]) { // checking if target is less than mid
            return binarySearch(array, target, s, m - 1);
        } else{ // checking if target is more than mid
            return binarySearch(array, target, m + 1, l);
        }
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the value of m, n and k in order -> "); // asking for user input for generating the array
        int m = s.nextInt();
        int n = s.nextInt();
        int k = s.nextInt();
        System.out.print("\nEnter the target value to be searched -> "); // asking for target value
        int target = s.nextInt();
        s.close();
        int range = ((n - m) / k) + 1; // range of the array
        System.out.println("Index of the target in array by Linear Search-> " + LinearSearch((Range.makeRange(m,n,k)), target)); // linear search output
        System.out.println("Index of the target in array by Binary Search-> " + binarySearch((Range.makeRange(m,n,k)), target, 0 , range - 1));// binary search output
    }
}// End of class
