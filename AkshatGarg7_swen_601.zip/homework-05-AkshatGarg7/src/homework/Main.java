package homework;

import java.util.Scanner;

/**
 * Class Main uses user input to make an array and asks user for target to be searched repeatedly until user exit
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class Main {

    /**
     * Function main asks user for input for array and target value and searches through the array and uses both
     * linear search and binary search and time taken for each search.
     *
     * @param args none
     */

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the value of m, n and k in order -> "); // User input
        int m = s.nextInt();
        int n = s.nextInt();
        int k = s.nextInt();
        int range = ((n - m) / k) + 1; // array size
        int[] array = Range.makeRange(m,n,k); // making the array
        System.out.println("Size of the array-> " + range); // output for size
        int target;
        while(true){ // infinite loop
            System.out.print("Enter the value of the target value and enter \"-1\" to exit: "); // asking for target value to be searched
            target = s.nextInt();
            if (target < 0){
                break; // exit condition
            }
            else{
                long start_time = (long) (System.nanoTime() * (Math.pow(10,-6))); // start time
                int ls = Search.LinearSearch(array,target); // linear search calling
                System.out.println((ls > -1) ? "The targeted value was found at " + ls : "The targeted value was not found"); // output
                long mid_time = (long) (System.nanoTime() * (Math.pow(10,-6)));
                long Total_time_linear = mid_time - start_time;
                System.out.println("Time taken to execute the linear search is " + Total_time_linear + " ms"); // linear search time taken
                int bs = Search.binarySearch(array, target, 0 , range - 1);// binary search calling
                System.out.println((bs > -1) ? "The targeted value was found at " + bs : "The targeted value was not found"); //output
                long stop_time = (long) (System.nanoTime() * (Math.pow(10,-6)));
                long Total_time_binary = stop_time - mid_time;
                System.out.println("Time taken to execute the binary search is " + Total_time_binary + " ms");// binary search time taken
                System.out.println("The difference in time between binary search and linear search -> " + (Total_time_binary - Total_time_linear) + " ms"); // difference in time
            }
        }
    }
}// End of class