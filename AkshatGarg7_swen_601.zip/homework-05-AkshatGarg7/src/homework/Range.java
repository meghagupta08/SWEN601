package homework;

import java.util.Arrays;
import java.util.Scanner;

/**
 * Class Range generates an array from m to n with a difference of k
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class Range {

    /** Function makeRange takes the input m,n and k and generates an array based on input
     *<p>
     *First we find out range/size for which we have to generate the array. We do this by the formula,
     * and make a new array of same range. then we start generating the array based on same using loop.
     *
     * @param m integer type, starting element of array
     * @param n integer type, maximum value of element in the array
     * @param k integer type, steps value
     * @return array
     */

    public static int[] makeRange(int m,int n,int k){
        int range = ((n-m)/k + 1); //finding the size of array
        int[] arr = new int[range]; // generating new array of same size
        int count = 0;
        for(int i = m;i <= n ; i = i + k) { // initial value of 'm', finial value of array 'n' and step size of 'k'
            if (count < range) {
                arr[count] = i; // saving the element in the array
                count ++;

            }
        }
        return arr; // output
    }

    /**
     * Function makeRange_k uses step size of 1, instead of asking from the user.
     *
     * @param m integer type, starting element of array
     * @param n integer type, maximum value of element in the array
     * @return array
     */
    public static int[] makeRange_k(int m,int n){
        return makeRange(m,n,1); // calling makeRange function and giving step value as 1
    }

    /**
     * Function makeRange_m uses step size of 1 and initial value of 0, instead of asking from the user.
     * @param n integer type, maximum value of element in the array
     * @return array
     */

    public static int[] makeRange_m(int n){
        return makeRange(0,n,1); // calling makeRange function and giving initial value as 0 and step size as 1
    }

    /**
     * Function main use scanner to take input from user and based on value of step size, 'k' and initial value, 'm'
     * it decides which method to use from and returns the string of generated array
     *
     * @param args none
     */

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in); // initiating scanner
        String b;
        System.out.print("Enter the value of m, n and k in order ->"); // asking for user input
        int m = s.nextInt(); // checking for initial value
        int n = s.nextInt(); // checking for max value
        int k = s.nextInt(); // checking for step value
        s.close(); // stopping scanner
        if (k == 1){ // checking for step value
            if (m == 0){ // checking for initial value
                b = Arrays.toString(makeRange_m(n));
            }
            else{
                b = Arrays.toString(makeRange_k(m,n));
            }
        }
        else{
            b = Arrays.toString(makeRange(m,n,k));
        }
        System.out.println("The generated array is-> \n" + b); // output
    }
}// End of class
