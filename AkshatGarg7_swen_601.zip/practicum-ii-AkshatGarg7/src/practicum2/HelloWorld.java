package practicum2;

public class HelloWorld {
}
