package practicum2;

public class Grade {
    private LetterGrade letterGrade;
    private int credits;

    public Grade(LetterGrade letterGrade, int credits) {
        this.letterGrade = letterGrade;
        this.credits = credits;
    }

    public LetterGrade getLetterGrade() {
        return letterGrade;
    }

    public void setLetterGrade(LetterGrade letterGrade) {
        this.letterGrade = letterGrade;
    }

    public double getCredits() {
        return credits;
    }

    public boolean includeInGPA(LetterGrade letterGrade){
        return letterGrade != LetterGrade.P && letterGrade != LetterGrade.S;
    }

    public double getScore(){
        return this.letterGrade.getPoints() * this.credits;
    }

    @Override
    public String toString(){
        return "Grade{letter=" + this.letterGrade
                + ", points=" + this.letterGrade.getPoints()
                + ", credits=" + this.credits
                + ", score=" + getScore()
                +"}";
    }

    @Override
    public boolean equals(Object o){
        if(o instanceof Grade){
            Grade g = (Grade) o;
            return this.letterGrade.equals(g.letterGrade) && (this.credits == g.credits);
        }else {
            return false;
        }
    }
}
