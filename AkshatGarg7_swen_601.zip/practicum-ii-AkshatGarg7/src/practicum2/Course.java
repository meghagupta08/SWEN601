package practicum2;

import java.util.Arrays;

public class Course {
    private int year;
    private int term;
    private Student[] students;
    private int count;

    public Course(int year, int term) {
        this.year = year;
        this.term = term;
        this.students = new Student[10];
    }

    public int getYear() {
        return year;
    }

    public int getTerm() {
        return term;
    }

    public Student[] getStudents() {
        return students;
    }

    private void extendArray(Student[] array){
        array = Arrays.copyOf(array, array.length * 2);
    }

    public void addStudent(Student student){
        if(count > students.length){
            extendArray(students);
        }
        this.students[count] = student;
        count ++;
    }

    public double averageGPA(){
        return 0;
    }

    public static void main(String[] args) {
        System.out.println(" ");
    }
}
