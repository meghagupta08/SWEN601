package practicum2;

public interface Student {
//    String name = null;
//    String id = null;
//    String email = null;
//
    String getName();
    String getId();
    String getEmail();

    void addGrade(LetterGrade letterGrade);
    LetterGrade[] getGrades(); // not this bcoz of credits
    //Grade[] getGrades();
    double calculateGPA();
}
