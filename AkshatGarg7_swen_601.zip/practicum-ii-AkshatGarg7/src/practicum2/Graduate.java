package practicum2;

import java.util.Arrays;

public class Graduate implements Student{
    private String name;
    private String id;
    private String email;
    private LetterGrade[] arr;
    private LetterGrade[] newArr;
    private int[] cred;
    private int[] newCred;
    private int count;
    private int credCount;

    public Graduate(String name, String id) {
        this.name = name;
        this.id = id;
        this.email = id + "@grad.rit.edu";
        arr = new LetterGrade[10];
        newArr = new LetterGrade[10];
        cred = new int[10];
        newCred = new int[10];
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getEmail() {
        return email;
    }

    private void extendArray(LetterGrade[] array){
        array = Arrays.copyOf(array, array.length * 2);
    }
    private void extendArrayInt(int[] array) {
        array = Arrays.copyOf(array, array.length * 2);
    }

    @Override
    public void addGrade(LetterGrade letterGrade) {
        if(count == arr.length){
            extendArray(arr);
        }
        this.arr[this.count] = letterGrade;
        count++;
    }

    private void addCred(int credit){
        if(credCount > cred.length){
            extendArrayInt(cred);
        }
        this.cred[this.credCount] = credit;
        credCount++;
    }

    @Override
    public LetterGrade[] getGrades() {
        int j = 0;
        while (j< newArr.length){
            for (int i = 0; i < arr.length; i++) {
                if (j > newArr.length) {
                    extendArray(newArr);
                    extendArrayInt(newCred);
                }
                if (arr[i] != null) {
                    newArr[j] = arr[i];
                    newCred[j] = cred[i];
                    j++;
                }
            }
        }
        return newArr;
    }

    @Override
    public double calculateGPA() {
        double totalScore = 0;
        int totalCredit = 0;
        for(int i =0; i < newArr.length;i++){
            Grade g = new Grade(newArr[i],newCred[i]);
            if(g.getLetterGrade() == LetterGrade.C_MINUS || g.getLetterGrade() == LetterGrade.C_PLUS){
                g.setLetterGrade(LetterGrade.C);
            }
            if(g.includeInGPA(g.getLetterGrade())){
                totalScore += g.getScore();
                totalCredit += newCred[i];
            }
        }
        return totalScore/totalCredit;
    }

    @Override
    public String toString(){
        return "Graduate{name=" + getName()
                +",id=" + getId()
                +",email=" + getEmail()
                +",GPA=" + calculateGPA()
                +"}";
    }
}
