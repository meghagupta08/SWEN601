package practicum2;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

class LetterGradeTest {
    @Test
    public void checkJUnit() {
        LetterGrade letter = LetterGrade.B_MINUS;
        assertEquals(2.67, letter.getPoints());
    }
}