package practicum2;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

class GraduateTest {
    @Test
    public void nameCheck() {
        Student s = new Graduate("Aldrin, Buzz", "bea2784");
        String expected = "Aldrin, Buzz";
        String actual = s.getName();
        assertEquals(expected, actual);
    }
    @Test
    public void idCheck() {
        Student s = new Graduate("Aldrin, Buzz", "bea2784");
        String expected = "bea2784";
        String actual = s.getId();
        assertEquals(expected, actual);
    }
    @Test
    public void emailCheck() {
        Student s = new Graduate("Aldrin, Buzz", "bea2784");
        String expected = "bea2784@grad.rit.edu";
        String actual = s.getEmail();
        assertEquals(expected, actual);
    }
    @Test
    public void stringCheck(){
        Student s = new Graduate("Aldrin, Buzz", "bea2784");
        String expected = "Graduate{name=Aldin, Buzz,id=bea2784, email=bea2784@ug.rit.edu, GPA=0}";
        String actual = s.toString();
        assertEquals(expected,actual);
    }
}