package practicum1;

import utils.SortUtilities;

import static practicum1.ArrayUtilities.*;

public class Bumper {
    public static void sort(int[] arr) {

        int[] countsArr = counts(arr);
        int count = 0;
        for(int j = 0; j < countsArr.length; j++){
            fill(arr, j, count, countsArr[j]);
            count = count + countsArr[j];
        }
        System.out.println(arrayToString(arr));
    }

    public static void main(String[] args) {
        int[] rand = SortUtilities.makeArray(15);
        System.out.println(arrayToString(rand));
        sort(rand);
        //System.out.println(ArrayUtilities.arrayToString(arr));
    }
}
