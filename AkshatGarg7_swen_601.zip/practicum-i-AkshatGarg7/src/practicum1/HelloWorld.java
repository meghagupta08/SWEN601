package practicum1;

/**
 * Provided to test that the project is configured appropriately.
 */
public class HelloWorld {
    /**
     * A simple hello world program.
     *
     * @param args Not used.
     */
    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }
}
