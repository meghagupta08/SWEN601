package practicum1;

public class ArrayUtilities {
    public static String arrayToString(int[] arr) {
        if (arr.length < 1) {
            return "[]";
        }
        else{
            String a = "[";
            for(int i = 0; i < arr.length - 1;i++){
                a += arr[i] + ", ";
            }
            return a + arr[arr.length - 1] + "]";
        }
// bobby solution
//        StringBuilder builder = new StringBuilder();
//        builder.append("[");
//        if(arr.length >= 1) {
//            for (int i = 1; i < arr.length; i++) {
//                builder.append(" ,");
//                builder.append(arr[i]);
//            }
//        }
//        builder.append("]");
//        return builder.toString();
    }

    public static int[] counts(int[] arr) {
        if (arr.length < 1) {
            return new int[]{};
        } else {
            int max = 0;
            for (int i = 0; i < arr.length; i++) {
                if (max < arr[i]) {
                    max = arr[i];
                }
            }
            //System.out.println(max);
            int[] countArr = new int[max + 1];
// check once time complexcity is o(n) bobby solution
//            for (int value : arr) {
//                countArr[value]++;
//            }

            for (int j = 0; j < max + 1; j++) {
                int count = 0;
                for (int k = 0; k < arr.length; k++) {
                    if (arr[k] == j) {
                        count++;
                    }
                }
                countArr[j] = count;
            }

            //System.out.println(Arrays.toString(countArr));
            return countArr;
        }
    }


    public static void fill(int[] arr, int value, int index, int times){
            for(int i = index; i < index + times; i++){
                arr[i] = value;
            }
            //System.out.println(arrayToString(arr));
        }

    public static void main(String[] args) {
        System.out.println(arrayToString(new int[] {}));
        System.out.println(arrayToString(new int[] {1, 2, 3}));
        System.out.println(arrayToString(new int[] {2, 3, 5, 7, 11, 13}));
        System.out.println("\n\n");
        int[] arr = new int[] {1, 2, 3, 4, 4, 1, 1, 2, 0, 6};
        //System.out.println(arrayToString(arr));
        System.out.println(arrayToString(counts(arr)));
        System.out.println("\n\n");
        int[] newarr = new int[] {0,0,0,0,0,0,0,0,0,0,0,0};
        fill(newarr, 5 , 4, 4);
        System.out.println(arrayToString(newarr));
    }
}


