package finalexam;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class Problem01 {
    public static void main(String[] args) {
        if(args.length != 1){
            System.out.println("Usage: java Problem01 <filename>");
            System.exit(1);
        }

        String filename = args[0];

        File file = new File(filename);
        if(!file.exists()){
            System.out.println("Input file does not exist: " + filename);
            System.exit(1);
        }

        //System.out.println(Arrays.toString((" ".getBytes(StandardCharsets.UTF_8))));

        try(FileInputStream fin = new FileInputStream(file)) {
//            FileInputStream fin = new FileInputStream(file);
            byte[] bytes = new byte[10240];

            int n = 1;
            long count = 0;
            long totalSum = 0;

            while(n > 0){
                n = fin.read(bytes);
                if(n > 0){
                    count += n;
                    for(int i = 0; i < n; i++){
                        totalSum += bytes[i];
                    }
                }
            }
//            fin.close();

            System.out.println("Reading file: " + filename);
            System.out.println("sum of bytes: " + totalSum);
            System.out.println("count of bytes: " + count);
        } catch (IOException e) {
            System.out.println(e.getMessage());
            System.exit(1);
        }
    }
}
