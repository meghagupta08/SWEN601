package finalexam;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Problem03 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter a server name: ");
        String server = s.next();

        System.out.println("Sending GET request to " + server);
        System.out.println("Reading response...");

        try {
            InetAddress inetAddress = InetAddress.getByName(server);
            Socket sock = new Socket(inetAddress.getHostAddress() , 80);

            OutputStream out = sock.getOutputStream();
            PrintWriter pw = new PrintWriter(out);
            pw.println("GET / HTTP/1.1");
            pw.println("Host: " + server);
            pw.println();
            pw.flush();

            InputStream in = sock.getInputStream();
            InputStreamReader ir = new InputStreamReader(in);
            BufferedReader br = new BufferedReader(ir);
            String line = null;
            while((line = br.readLine()) != null){
                System.out.println(line);
            }
            in.close();
            sock.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
            System.exit(1);
        }
    }
}
