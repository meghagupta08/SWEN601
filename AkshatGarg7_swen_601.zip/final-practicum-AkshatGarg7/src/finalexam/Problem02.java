package finalexam;

import java.util.ArrayList;

public class Problem02 implements Runnable {

    private static Integer count = 1;
    private int id;
    private Object lock;

    public Problem02(int id) {//,ArrayList<Thread> threads) {
        this.id = id;
//        this.threads = threads;
    }

    public void number(){
        synchronized (lock){
            lock.notifyAll();
        }
    }

    @Override
    public void run() {
        while(true) {
            synchronized (lock) {
                if (this.count > 1000) {
                    break;
                }
                System.out.println(this.id + ":" + count);
                count++;
            }
        }
    }

    public static void main(String[] args) {
        System.out.println("STARTING!");
        ArrayList<Thread> threads = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Problem02 problem = new Problem02(i);
            Thread thread = new Thread(problem);
            threads.add(thread);
            thread.start();
        }
        for(Thread thread : threads){
            try {
                thread.join();
            } catch (InterruptedException e) {}
        }
        System.out.println("FINISHED!");
    }
}

