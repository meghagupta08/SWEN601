package finalexam;

public class HelloWorld {
    public static String hello(String name) {
        return "Hello, " + name + "!";
    }

    public static void main(String[] args) {
        String message = hello("World");
        System.out.println(message);
    }
}
