package finalexam;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HelloWorldTest {
    @Test
    public void hello() {
        // setup
        String name = "Buttercup";
        String expected = "Hello, Buttercup!";

        // invoke
        String actual = HelloWorld.hello(name);

        // analyze
        assertEquals(expected, actual);
    }
}