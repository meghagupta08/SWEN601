package activities;

public class Dog {
    private String Name;
    private int age;
    private String Breed;
    private double Weight;

    public Dog(){
        this("Rex",1,"idk",50.0);
        /*
        Name = "Rex";
        age = 1;
        Breed = "idk";
        Weight = 50.0;
         */
    }
    public Dog(String Name, String Breed){
        this(Name,1,Breed,50.0);
    }

    public void walk(int distance){
        double calories = distance * 100;
        double pounds = calories/3000.0;
        this.Weight -= pounds;
    }

    public void eat(double calories){ //dont make it static!!!!!!
        double pounds = calories/3000.0;
        this.Weight += pounds;
    }

    public Dog(String Name, int age, String Breed, double Weight) {
        this.Name = Name;
        this.age = age;
        this.Breed = Breed;
        this.Weight = Weight;
    }

    public void setName(String Name){
        this.Name = Name;
    }
    public String Breed(String Breed){
        this.Breed = Breed;
        return Breed;
    }

    @Override
    public String toString(){
        return "Dog[name=" + Name
                + ", age=" + age
                +", Breed=" + Breed
                + ", Weight=" + Weight
                +"]";
    }

    public static void main(String[] args) {
        Dog dog1 = new Dog("Lays", 5, "idk", 78);
        Dog dog2 = new Dog("Burrito", 10, "againidk", 50);
        System.out.println(dog1.Name);
        System.out.println(dog1.age);
        System.out.println(dog2.Name);
        System.out.println(dog2.age);

        Dog dog3 = new Dog();
        System.out.println(dog3.Name);
        System.out.println(dog3.age);

        dog1.eat(6000);
        System.out.println(dog1.Weight);
        dog1.walk(1);
        System.out.println(dog1.Weight);

        System.out.println(dog1);
    }
}
