package homework;

/**
 * Class physicalElements takes input for new elements given by user and gives output.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class physicalElements {

    // Declaring private field variables
    private String name, symbol;
    private int atomicNumber;
    private double atomicWeigh;

    /**
     * Constructor physicalElements
     *
     * @param name String type, Name of element
     * @param symbol String type, symbol by which is known
     * @param atomicNumber integer type, Atomic number of element
     * @param atomicWeigh double type, atomic weight of element
     */

    public physicalElements(String name, String symbol, int atomicNumber, double atomicWeigh){
        this.name = name;
        this.symbol = symbol;
        this.atomicNumber = atomicNumber;
        this.atomicWeigh = atomicWeigh;
    }

    /**
     * Method toString to modify the output of toString for easier readability
     *
     * @return String type of desired output string format
     */

    @Override
    public String toString(){
        return "physicalElement[name=" + name
                + ", symbol=" + symbol
                +", atomicNumber=" + atomicNumber
                +", atomicWeigh=" + atomicWeigh
                +"]"; //desired output format
    }

    /**
     * Getter getName returns name of the element and is unique to element
     *
     * @return name of the element
     */

    public String getName() {
        return name;
    }

    /**
     * Getter getSymbol returns symbol of the element and is unique to element
     *
     * @return symbol of the element
     */

    public String getSymbol() {
        return symbol;
    }

    /**
     * Getter getAtomicNumber returns atomic number of the element and is unique to element
     *
     * @return atomic number of the element
     */

    public int getAtomicNumber() {
        return atomicNumber;
    }

    /**
     * Setter setAtomicWeigh sets the atomic weight of the element and can be changed as atomic weight of element can be changed.
     *
     * @param atomicWeigh double type, atomic weight of the element
     */

    public void setAtomicWeigh(double atomicWeigh) {
        this.atomicWeigh = atomicWeigh;
    }
}//End of class
