package homework;

/**
 * Class test creates a main function and tests out other classes by giving input and output
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class test {
    public static void main(String[] args) {
        //To print first 10 unique element using physicalElements
        physicalElements hydrogen = new physicalElements("Hydrogen", "H", 1, 1.0079);// setting new element
        physicalElements helium = new physicalElements("Helium", "He", 2, 4.0026);
        physicalElements lithium = new physicalElements("Lithium", "Li", 3, 6.941);
        physicalElements beryllium = new physicalElements("Beryllium", "Be", 4, 9.0122);
        physicalElements boron = new physicalElements("Boron", "B", 5, 10.811);
        physicalElements carbon = new physicalElements("Carbon", "C", 6, 12.0107);
        physicalElements nitrogen = new physicalElements("Nitrogen", "N", 7, 14.0067);
        physicalElements oxygen = new physicalElements("Oxygen", "O", 8, 15.9994);
        physicalElements fluorine = new physicalElements("Fluorine", "F", 9, 18.9984);
        physicalElements neon = new physicalElements("Neon", "Ne", 10, 20.1779);
        System.out.println(hydrogen + "\n" + helium + "\n" + lithium + "\n" + beryllium + "\n" + boron + "\n" + carbon); //Printing out the output
        System.out.println(nitrogen + "\n" + oxygen + "\n" + fluorine + "\n" + neon);
        System.out.println(" ");
        System.out.println(" ");

        //To get temperature from Thermometer
        Thermometer temp1 = new Thermometer();
        Thermometer temp2 = new Thermometer();
        Thermometer temp3 = new Thermometer();
        Thermometer temp4 = new Thermometer();
        Thermometer temp5 = new Thermometer();
        temp1.setCelsius(100); // setting celsius as 100
        System.out.println("Updated Fahrenheit: " + temp1.getFahrenheit());//getting only fahrenheit by using getFahrenheit
        temp2.setCelsius(32);
        System.out.println(temp2);
        temp3.setFahrenheit(-100); // setting fahrenheit to -100
        System.out.println(temp3); //output
        temp4.setKelvin(100); // setting kelvin to 100
        System.out.println(temp4);
        temp5.setCelsius(-14.59);
        System.out.println(temp5);

        Rate prof1 = new Rate("Parany","Marje","Rochester Institute of Technology","MSDS-101",4.5,2); // Details of 1st professor
        Rate prof2 = new Rate("Garnet","Arek","Rochester Institute of Technology","MATH-501",4,2.5); // Details of 2nd professor
        System.out.println("\n\n\n" + prof1 + "\n");//before changes output for professor 1
        System.out.println(prof2 + " \n");//before changes output for professor 2
        //Prof1 Rating changes
        prof1.calculation(4,2); // new ratings and level of difficult rating for professor 1
        prof1.calculation(3.4,2.2);
        prof1.calculation(2.9,2.7);
        prof1.calculation(4.6,1.4);
        System.out.println("Updated overall quality: " + prof1.getQuality()); // Overall rating after new ratings given
        System.out.println("Updated overall level of difficulty: " + prof1.getDifficulty() + "\n"); // Overall level of difficulty after new input given
        System.out.println(prof1 + "\n"); // final output for professor 1
        //Prof2 Rating changes
        prof2.calculation(5,3);
        prof2.calculation(4.3,2.2);
        prof2.calculation(3.8,1.2);
        prof2.calculation(4.6,2.7);
        //Change of subject
        prof2.setSubject("MATH-601");
        System.out.println("Change of subject: " + prof2.getSubject());
        System.out.println("Updated overall quality: " + prof2.getQuality());
        System.out.println("Updated overall level of difficulty: " + prof2.getDifficulty() + "\n");

        System.out.println(prof2);
    }
}//End of Class
