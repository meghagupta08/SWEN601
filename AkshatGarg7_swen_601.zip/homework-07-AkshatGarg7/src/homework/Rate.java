package homework;

import java.util.ArrayList;

/**
 * Class Rate takes user input for a professor and allows user to add more ratings and generate an average rating of professor
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class Rate {

    //Declaring private field variable
    private String firstName, lastName, univName, subject;
    private double quality, difficulty;
    private ArrayList<Double> overallRating, overallLevel;

    /**
     * Constructor Rate sets default value and assigns variable for objects
     *
     * @param firstName String type, first name of the professor
     * @param lastName String type, last name of the professor
     * @param univName String type, University name of the professor
     * @param subject String type, Subject name of the professor
     * @param quality double type, Overall rating of the professor
     * @param difficulty double type, overall level of difficulty of professor
     */

    public Rate(String firstName, String lastName, String univName, String subject, double quality, double difficulty){
        this.firstName = firstName;
        this.lastName = lastName;
        this.univName = univName;
        this.subject = subject;
        this.quality = quality;
        this.difficulty = difficulty;
        this.overallRating = new ArrayList<Double>(); // creating new array list to store new rating
        this.overallRating.add(quality);// adding default value to array list
        this.overallLevel = new ArrayList<Double>(); // creating new array list to store new level of difficulty
        this.overallLevel.add(difficulty);// adding default value to array list

    }

    /**
     * Constructor Rate is a chaining constructor of Rate with default values of quality and difficulty of 1.0
     *
     *@param firstName String type, first name of the professor
     *@param lastName String type, last name of the professor
     *@param univName String type, University name of the professor
     *@param subject String type, Subject name of the professor
     */

    public Rate(String firstName, String lastName, String univName, String subject){
        this(firstName,lastName,univName,subject, 1.0,1.0);
    }

    /**
     * Getter getFirstName gets first name of the professor or else returns the default value.
     *
     * @return String type, returns the first name
     */

    public String getFirstName() {
        return firstName;
    }

    /**
     * Getter getLastName gets last name of the professor or else returns the default value.
     *
     * @return String type, returns the last name
     */

    public String getLastName() {
        return lastName;
    }

    /**
     * Getter getUnivName gets university name of the professor or else returns the default value.
     *
     * @return String type, returns the university name
     */

    public String getUnivName() {
        return univName;
    }

    /**
     * Getter getSubject gets subject name of the professor or else returns the default value.
     *
     * @return String type, returns the subject name
     */

    public String getSubject() {
        return subject;
    }

    /**
     * Getter getQuality gets overall rating of the professor.
     *
     * @return double type, returns the overall rating
     */

    public double getQuality() {
        return quality;
    }

    /**
     * Getter getDifficulty gets the overall level of difficulty of the professor.
     *
     * @return String type, returns the overall difficulty
     */

    public double getDifficulty() {
        return difficulty;
    }

    /**
     * Setter setFirstName changes the default value of first name of the object.
     *
     * @param firstName String type, first name of professor
     */

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Setter setLastName changes the default value of last name of the object.
     *
     * @param lastName String type, last name of professor
     */

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Setter setUnivName changes the default value of University name of the object.
     *
     * @param univName String type, university name of professor
     */

    public void setUnivName(String univName) {
        this.univName = univName;
    }

    /**
     * Setter setSubject changes the default value of subject name of the object.
     *
     * @param subject String type, subject name of professor
     */

    public void setSubject(String subject) {
        this.subject = subject;
    }

    /**
     * Function averageCal returns the average of the array list.
     *
     * @param array Double type array list
     * @return double type, average value of array
     */

    public double averageCal(ArrayList<Double> array){
        double sum = 0;
        for(double a : array){
            sum += a;
        }
        return sum/array.size();
    }

    /**
     * Function calculation first saves the new elements in array list and then finds out the average by averageCal.
     *
     * @param quality double type, new rating for professor
     * @param difficulty double type, new level of difficulty for the professor
     */

    public void calculation(double quality, double difficulty){
        if((quality >= 1.0 && quality <= 5.0) && (difficulty >= 1.0 && difficulty <= 5.0)) {
            this.overallRating.add(quality);
            this.overallLevel.add(difficulty);
            //System.out.println(Arrays.toString(overallLevel.toArray()));
            this.quality = Math.round((averageCal(this.overallRating)) * 100.0)/100.0;
            this.difficulty = Math.round((averageCal(this.overallLevel))*100.0)/100.0;
        }
    }

    /**
     * Method toString to modify the output of toString for easier readability
     *
     * @return String type of desired output string format
     */

    @Override
    public String toString(){
        return "Details of the Professor: "
                +"\nFirst Name: " + firstName
                +"\nLast Name: " + lastName
                +"\nUniversity Name: " + univName
                +"\nSubject: " + subject
                +"\nOverall Rating: " + quality
                +"\nLevel of Difficulty: " + difficulty
                ;
    }
}//End of class
