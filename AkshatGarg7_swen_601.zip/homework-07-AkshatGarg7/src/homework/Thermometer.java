package homework;

/**
 * Class Thermometer sets one of the temperature, and we can get other temperature formats
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class Thermometer {
    // Declaring private field variables
    private double celsius;
    private double fahrenheit;
    private double kelvin;

    /**
     * Method toString to modify the output of toString for easier readability
     *
     * @return String type of desired output string format
     */

    @Override
    public String toString(){
        return "Thermometer[Celsius= " + celsius
                +"\u00B0C, Fahrenheit= " + fahrenheit
                +"\u00B0F, Kelvin= " + kelvin
                +"K]";
    }

    /**
     * Constructor Thermometer sets default value to 37 on celsius scale and is a parameter less constructor
     */

    public Thermometer(){
        celsius = 37; // average human body temperature
    }

    /**
     * Setter setCelsius uses celsius scale to set other scales and celsius
     *
     * @param celsius double type, celsius scale setter parameter
     */

    public void setCelsius(double celsius){
        this.celsius = celsius;
        this.fahrenheit = Math.round((((9*celsius)/5) + 32)*100.0)/100.0; // rounding off to 2 decimal places
        this.kelvin = Math.round((celsius + 273.15)*100.0)/100.0;
    }

    /**
     * Setter setFahrenheit uses fahrenheit scale to set other scales
     *
     * @param fahrenheit double type, fahrenheit scale setter parameter
     */

    public void setFahrenheit(double fahrenheit){
        this.fahrenheit = fahrenheit;
        this.celsius = Math.round(((fahrenheit - 32)*5/9)*100.0)/100.0;
        this.kelvin = Math.round((((fahrenheit - 32)*5/9) + 273.15)*100.0)/100.0;
    }

    /**
     * Setter setKelvin uses kelvin scale to set other scales
     *
     * @param kelvin double type, kelvin scale setter parameter
     */

    public void setKelvin(double kelvin) {
        this.kelvin = kelvin;
        this.celsius = Math.round((kelvin -273.15)*100.0)/100.0;
        this.fahrenheit = Math.round((((kelvin - 273.15)*9/5) + 32)*100.0)/100.0;
    }

    /**
     * Getter getCelsius gets the celsius set value or default value
     *
     * @return double type celsius value
     */

    public double getCelsius() {
        return celsius;
    }

    /**
     * Getter getFahrenheit gets the fahrenheit set value or default value
     *
     * @return double type fahrenheit value
     */

    public double getFahrenheit() {
        return fahrenheit;
    }

    /**
     * Getter getKelvin gets the kelvin set value or default value
     *
     * @return double type kelvin value
     */

    public double getKelvin() {
        return kelvin;
    }
}//End of class
