package shapes;

public class Square extends Shape{

    private double sideLength;

    public Square(Position pos, String fillColor, String lineColor, int sideLength) {
        super(pos, fillColor, lineColor);
        this.sideLength = sideLength;
    }

    @Override
    public double area(){
        return sideLength*sideLength;
    }

    @Override
    public double perimeter() {
        return 4*sideLength;
    }

    @Override
    public void scale(double factor) {
        sideLength = sideLength * factor;
    }
}
