package shapes;

public interface Figure {
    public abstract Position getPos();
    public void move(Position pos); // doesn't matter if public abstract is present or not
    String getFillColor();
    String getLineColor();
    double area();
    double perimeter();
    void scale(double factor);
}
