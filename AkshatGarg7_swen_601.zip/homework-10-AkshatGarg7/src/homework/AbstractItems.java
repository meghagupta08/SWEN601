package homework;

/**
 * AbstractItems implements Items interface and addAll and toString method
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public abstract class AbstractItems implements Items{

    /**
     * Collection is an Object type array
     */
    protected Object[] collection;

    /**
     * addAll adds all the element in the items array to the collection
     *
     * @param items Object type, has elements to be added in collection
     */

    public void addAll(Object[] items) {
        for (int i = 0; i < items.length; i++) {
            add(items[i]); //calls add(Object item)
        }
    }

    /**
     * return custom return String
     *
     * @return user desired String
     */

    @Override
    public String toString(){
        String a = "ArrayOfItems [";
        for(int i = 0; i < ArrayOfItems.getCounter() - 1; i++){
            a += collection[i] + ", ";
        }
        return a + collection[ArrayOfItems.getCounter() - 1] + "]"; //custom toString output
    }
}
