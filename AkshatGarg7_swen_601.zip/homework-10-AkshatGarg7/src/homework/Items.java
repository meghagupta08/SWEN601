package homework;

/**
 * Items is an interface class with all the method declared
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public interface Items {
    void add(Object item); // adds a single object to the collection
    Object get(int index); // returns an item at specific index
    int size(); //returns the number of items stored in collection
    void addAll(Object[] items); // adds all the elements in the array to the collection
}
