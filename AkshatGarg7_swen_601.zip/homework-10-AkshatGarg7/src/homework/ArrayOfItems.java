package homework;

/**
 * ArrayOfItems is child class of AbstractItems implementing get, add and size.
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class ArrayOfItems extends AbstractItems{

    /**
     * total size of the collection array
     */

    private int size;

    /**
     * Static counter to check actual count of elemts in collection
     */

    private static int counter = 0;

    /**
     * Constructor ArrayOfItems with input parameter size. And initiates the collection size
     *
     * @param size size of collection
     */

    public ArrayOfItems(int size) {
        this.size = size;
        collection = new Object[size]; //creating collection of the given size
    }

    /**
     * return counter value
     *
     * @return counter value
     */

    protected static int getCounter(){
        return counter; // value of counter
    }

    /**
     * increments the counter by 1
     */

    private static void incrementCounter(){
        counter++; // counter + 1
    }

    /**
     * add the element to the collection if the element to added is at index less than size of collection
     *
     * @param item element to be added
     */

    @Override
    public void add(Object item) {
        if (getCounter() < size) { //checking if space is left in collection or not
            incrementCounter(); // counter + 1
            collection[getCounter() - 1] = item; // adding the element in collection
        }
    }

    /**
     * returns the value at the given index in the collection
     *
     * @param index element to be returned
     * @return element at given index
     */

    @Override
    public Object get(int index){
        if(index < counter) { // if index is less than actual elements count
            return collection[index]; // value of element in collection at given index
        }else{
            return null; // if not present or outside the size of collection
        }
    }

    /**
     * returns the actual number of elements in collection
     *
     * @return actual number of elements in collection
     */

    @Override
    public int size(){
        return getCounter(); // returns the value of actual elements in collection
    }

    /**
     * Test main method for ArrayOfItems
     *
     * @param args None
     */

    public static void main(String[] args) {
        Object[] arraytobeadded = new Object[]{4,5};
        AbstractItems a1 = new ArrayOfItems(10);
        a1.add(1);
        a1.add(2);
        a1.add("avvhktjd");
        System.out.println(a1);
        System.out.println(a1.get(2));
        System.out.println(a1.size());
        a1.addAll(arraytobeadded);
        System.out.println(a1);
    }
}
