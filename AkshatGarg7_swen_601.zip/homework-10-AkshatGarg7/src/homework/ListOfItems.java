package homework;

/**
 * ListOfItems is the child class of AbstractItems to create a list to be stored in collection
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class ListOfItems extends AbstractItems{

    /**
     * Initiate the head node
     */

    private Node head;

    /**
     * Initiate the tail node
     */

    private Node tail;

    /**
     * Initiate the size of the collection
     */

    private int size = 0;

    /**
     * ListOfItems constructor
     */

    public ListOfItems() {
        Node node = new Node();
        this.head = node; // setting the head to node
        this.tail = node; // setting the tail to node
    }

    /**
     * add the item to the collection. If the collection is empty then we initiate the first element
     * and point head to the first element and point that element to tail. Else we find the tail and add
     * element at position and increment the tail.
     *
     * @param item element to be added to the collection
     */

    @Override
    public void add(Object item){
        if(size == 0){
            head = new Node(); // first element in collection
            head.setItem(item); // setting the value of head
            this.tail = this.head; // saving the value of head in tail
        }else{
            Node n = new Node(); // new node
            n.setItem(item); // setting the value of element in node
            tail.setNext(n); // finding the address of next node
            this.tail = n; // setting the address for next node after new node
        }
        this.size++;
    }

    /**
     * Returns the element in the collection at the given index. We start traversing from
     * head to tail to find the element in the collection.
     *
     * @param index element to be returned at given index
     * @return element at given index
     */

    @Override
    public Object get(int index) {
        if (index < 0 || index > size) {
            return null;
        }
        Node nodePart = new Node();
        if (head != null) {
            nodePart = this.head;
            for (int i = 0; i < index ; i++) {
                if(nodePart.getNext() == null){
                    return null;
                }
                nodePart = nodePart.getNext(); // getting the value of element at given index
            }
            return nodePart.getItem();
        }
        return nodePart;
    }

    /**
     * returns the size of the collection
     *
     * @return the size of collection
     */

    @Override
    public int size() {
        return this.size; // size of collection
    }

    /**
     * User defined toString method to return custom String
     *
     * @return String based on user choices
     */

    @Override
    public String toString(){
        String a = "ListOfItems [" + head.getItem() + "->";
        Node np = head.getNext();
        for(int i = 1; i < size - 1; i++){
            a += np.getItem() + "->";
            np = np.getNext();
        }
        return a + np.getItem() + "]";
    }

//    public static void main(String[] args) {
//        AbstractItems a1 = new ListOfItems();
//        a1.add(1);
//        a1.add("abc");
//        //a1.add(3);
//        System.out.println(a1);
//        System.out.println(a1.size());
//        System.out.println(a1.get(3));
//        Object[] addedItems = new Object[] {10,30,40};
//        a1.addAll(addedItems);
//        System.out.println(a1);
//    }
}
