package homework;

import java.util.Arrays;

public class test {
    public static void main(String[] args) {
        Object[] name = new Object[10];
        name[1] = "Akshat";
        name[2] = 7;
        System.out.println(Arrays.toString(name));
    }
}
