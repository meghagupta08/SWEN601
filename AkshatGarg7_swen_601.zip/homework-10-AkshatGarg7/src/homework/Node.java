package homework;

/**
 * Creates a node
 *
 * @author Akshat Garg ag2193@rit.edu
 */
public class Node {

    /**
     * Object item is an item to be added to collection
     */

    private Object item;

    /**
     * next is the address of next node to be accessed
     */

    private Node next;

    /**
     * returns the value of node at given index
     *
     * @return the value of node
     */

    public Object getItem() {
        return item;
    }

    /**
     * set the item at particular index
     *
     * @param item value to be set at given index
     */

    public void setItem(Object item) {
        this.item = item;
    }

    /**
     * return the address of next element
     *
     * @return the address of next element
     */

    public Node getNext() {
        return next;
    }

    /**
     * sets the address to find the next element
     *
     * @param next the address to find next element
     */

    public void setNext(Node next) {
        this.next = next;
    }
}
