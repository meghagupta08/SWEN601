package homework;

/**
 * ItemsTest is class to test the remaining classes in homework package
 *
 * @author Akshat Garg ag2193@rit.edu
 */

public class ItemsTest {

    /**
     * returns an output based on items instance called
     */

    public static void testItems(Items items){
        if( items instanceof ArrayOfItems){
            System.out.println("\n\n");
            items.add(1); // adding element to collection
            System.out.println(items);
            System.out.println("size of the array-> " + items.size());
            items.add(2); // adding more elements in collection
            items.add("abc");
            items.add("dog");
            items.add(5);
            System.out.println(items);
            System.out.println("size of the array-> " +items.size());
            System.out.println(items.get(3)); //output should be "dog"
            Object[] arraytobeadded = new Object[]{6,7,8,9}; // adding a array to the collection
            items.addAll(arraytobeadded);
            System.out.println(items);
            System.out.println("size of the array-> " +items.size());
            Object[] newarraytobeadded = new Object[]{10,11,"qwerty",13,14,15,"Typerwriter","Hello"};
            items.addAll(newarraytobeadded);
            System.out.println(items);
            System.out.println("size of the array-> " +items.size());
            System.out.println(items.get(10));
        }else if(items instanceof ListOfItems){

            System.out.println("\n\n");
            items.add(1);
            items.add(2);
            System.out.println(items);
            System.out.println("size of the array-> " +items.size());
            items.add("abc");
            items.add("dog");
            items.add(5);
            System.out.println(items);
            System.out.println("size of the array-> " +items.size());
            System.out.println(items.get(3)); //output should be "dog"
            items.add(6);
            items.add("qwert");
            items.add("typewriter");
            items.add("hello");
            System.out.println(items);
            System.out.println("size of the array-> " +items.size());
            System.out.println(items.get(5));
            Object[] newarraytobeadded = new Object[]{10,11,13,14,15};
            items.addAll(newarraytobeadded);
            System.out.println(items);
            System.out.println("size of the array-> " +items.size());
        }
    }

    /**
     * Main class to test the testItems
     *
     * @param args None
     */

    public static void main(String[] args) {

        Items array = new ArrayOfItems(13);
        testItems(array);
        Items list = new ListOfItems();
        testItems(list);
    }
}
