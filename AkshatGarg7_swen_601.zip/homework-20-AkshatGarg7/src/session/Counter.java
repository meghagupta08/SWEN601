package session;

public class Counter implements Runnable{
    private Object sharedLock;
    private int start;

    public Counter(Object sharedLock,int start) {
        this.start = start;
        this.sharedLock = sharedLock;
    }

    @Override
    public void run() {
        for(int i = start;  i < 11; i += 2){
            synchronized (sharedLock) {
                System.out.println(start + ":" +i);
                sharedLock.notify();
                try {
                    sharedLock.wait();
                } catch (InterruptedException e) {
                }
            }
        }
    }

    public static void main(String[] args) {
        Object sharedLock = new Object();

//        new Thread(new Counter(sharedLock,2)).start();
        new Thread(new Counter(sharedLock,1)).start();
        new Thread(new Counter(sharedLock,2)).start();

    }
}
