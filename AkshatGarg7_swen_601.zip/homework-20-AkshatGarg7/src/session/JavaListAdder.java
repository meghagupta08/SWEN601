package session;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class JavaListAdder implements Runnable{
    private List<Integer> list;

    public JavaListAdder(List<Integer> list) {
        this.list = list;
    }

    @Override
    public void run() {
        for(int i = 0; i < 10000; i++){
            synchronized (list) {
//                System.out.println(id + " got the lock!");
                list.add(i);
//                System.out.println(id + " got the unlock!");
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        List<Integer> list = new LinkedList<>();

        List<Thread> threads = new ArrayList<>();
        for(int i = 0; i < 10; i++){
            JavaListAdder adder = new JavaListAdder(list);
            Thread thread = new Thread(adder);
            thread.start();
            threads.add(thread);
        }

        for(Thread thread : threads){
            thread.join();
        }

        System.out.println("list after adding:" + list.size());
    }
}
