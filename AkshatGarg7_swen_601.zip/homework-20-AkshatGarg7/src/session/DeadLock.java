package session;

public class DeadLock extends Thread{
    private Object lockA,lockB;

    public DeadLock(Object lockA, Object lockB) {
        this.lockA = lockA;
        this.lockB = lockB;
    }

    @Override
    public void run(){
        while(true){
            synchronized (lockA){
                System.out.println("Got lock a... waiting for lock b...");
                synchronized (lockB){
                    System.out.println("got both locks!");
                }
            }
        }
    }

    public static void main(String[] args) {
        Object lock1 = new Object();
        Object lock2 = new Object();

        
    }
}
