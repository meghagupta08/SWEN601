package session;

import util.MyArrayList;
import util.MyList;
import util.MyNodeList;

import java.util.ArrayList;
import java.util.List;

public class ListAdder implements Runnable{

    private int id;
    private MyList<Integer> list;

    public ListAdder(int id,MyList<Integer> list) {
        this.list = list;
        this.id = id;
    }

    @Override
    public void run() {
//        synchronized (list) { // concurrency dead
//            System.out.println(id + " got the lock!");
            for (int i = 0; i < 10000; i++) {
//                synchronized (list) { //synchronised in util
//                    System.out.println(id + " got the lock!");
                    list.add(i);
//                    System.out.println(id + " got the unlock!");
//                }
            }
//            System.out.println(id + " got the unlock!");
        }
//    }

    public static void main(String[] args) throws InterruptedException {
        MyList<Integer> list = new MyArrayList<>();
//        MyList<Integer> list = new MyNodeList<>();

        List<Thread> threads = new ArrayList<>();
        for(int i = 0; i < 10; i++){
            ListAdder adder = new ListAdder(i,list);
            Thread thread = new Thread(adder);
            thread.start();
            threads.add(thread);
        }

//        synchronized (list) {
//            list.wait();
//        }
        for(Thread thread : threads){
            thread.join();
        }

        System.out.println("list after adding:" + list.size());
    }
}
