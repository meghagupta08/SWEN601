package homework;

/**
 * This class defines the level of Severity
 */
public enum SeverityLevel{
    DEBUG,
    INFO,
    WARNING,
    ERROR,
    CRITICAL;
}
