package homework;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Queue;

/**
 * Logger logs the log message in different threads
 */
public class Logger implements Runnable{
    /**
     * Required fields
     */
    private final String filename;
//    private String destination;
    private Queue<MyLogHandler> logMessage;
    private Object lock;

    /**
     * Constructor
     * @param filename file to which log should be saved
     */
    public Logger(String filename) {
        this.filename = filename;
        this.logMessage = new LinkedList<>();
        this.lock = new Object();
    }

    /**
     * Add logMessage to queue
     * @param message logMessage
     */
    public void add(MyLogHandler message){
        logMessage.add(message);
    }

    /**
     * run the thread
     */
    @Override
    public void run(){
        try{
            MyLogHandler logHandler = this.logMessage.poll(); //read and remove poll element
            String message = logHandler.toString();
            System.out.println(message);
            byte[] bytes = new byte[message.length()];
            bytes = message.getBytes();
            synchronized (lock){ //Synchronizing
                FileOutputStream fos = new FileOutputStream(this.filename,true); //output filename
                fos.write(bytes);
                fos.write("\n".getBytes());
                fos.close();
                lock.notify();
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
