package homework;

import java.io.*;
import java.util.ArrayList;

/**
 * Creates a log file based on input, output filepath and number of threads
 * @author Akshat Garg ag2193@rit.edu
 */
public class Simulation {
    public static void main(String[] args) throws IOException {
        // if args are not equal to 3
        if(args.length != 3){
            System.out.println("Usage:class <Log Filepath> <source filepath> <number of producer>");
            System.exit(2);
        }
        String logFile = args[0];
        String source = args[1];
        int number = Integer.parseInt(args[2]);

        ArrayList<Thread> threads = new ArrayList<>();
        File inputFile = new File(source);
        FileReader fr = new FileReader(inputFile);
        BufferedReader br = new BufferedReader(fr);
        String line;
        int count = 0;
        while((line = br.readLine()) != null){
            for(int i = 0; i < number; i++){
                Logger logger = new Logger(logFile);
                Producer producer = new Producer(logger,line,i);
                Thread thread = new Thread(producer);
                line = br.readLine();
                count ++;
                threads.add(thread);
            }
        }
        for(Thread thread : threads){
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
