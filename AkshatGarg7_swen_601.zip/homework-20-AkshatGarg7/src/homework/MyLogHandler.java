package homework;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * MyLogHandler class produces log messages
 */
public class MyLogHandler{
    /**
     * Required fields
     */
    private static final DateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
    private String time;
    private SeverityLevel severity;
    private String name;
    private String message;

    /**
     * Constructor
     *
     * @param name Fileclass name
     * @param severity severity of log
     * @param message log message to be taken
     */
    public MyLogHandler(String name,SeverityLevel severity, String message) {
        this.name = name;
        this.severity = severity;
        this.message = message;
        Calendar cd = Calendar.getInstance(); //current time
        time = df.format(cd.getTime()); //my format time
    }

    /**
     * @return customized toString method
     */
    @Override
    public String toString(){
        return "[" + severity
                +"][" + time
                +"][" + name
                +"] " + message;
    }
}
