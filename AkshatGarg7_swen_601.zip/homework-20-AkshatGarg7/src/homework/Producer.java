package homework;

import java.util.Random;

/**
 * Producer produces thread for multiple logger
 * @author Akshat Garg ag2193@rit.edu
 */
public class Producer implements Runnable{
    /**
     * Fields required
     */
    private static final Random RNG = new Random(1);
    private Logger logger;
    private String message;
    private int number;

    /**
     * Constructor
     *
     * @param logger my logger
     * @param message to be read
     * @param number number of current thread
     */
    public Producer(Logger logger, String message, int number) {
        this.logger = logger;
        this.message = message;
        this.number = number;
    }

    public Producer(Logger logger) {
        this(logger,null,0);
    }

    /**
     * run the thread
     */
    @Override
    public void run(){
        try {
            Thread.sleep(RNG.nextInt(5000));
            // assigning number to randomly pick from it
            SeverityLevel[] severityLevels = new SeverityLevel[5];
            // now I'll simply load up the array
            severityLevels[0] = SeverityLevel.DEBUG;
            severityLevels[1] = SeverityLevel.INFO;
            severityLevels[2] = SeverityLevel.WARNING;
            severityLevels[3] = SeverityLevel.ERROR;
            severityLevels[4] = SeverityLevel.CRITICAL;
            MyLogHandler myLogHandler = new MyLogHandler(this.toString(),severityLevels[RNG.nextInt(4)],this.message);
            this.logger.add(myLogHandler);
        } catch (InterruptedException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    /**
     * @return Custom toString
     */
    @Override
    public String toString(){
        return "Producer " + this.number;
    }

}
