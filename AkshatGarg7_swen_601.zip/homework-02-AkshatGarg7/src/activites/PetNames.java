package activites;

public class PetNames {
    public static void favorite_pet_names(){
        System.out.println('C');
        System.out.println('h');
        System.out.println('i');
        System.out.println('p');
        System.out.println('s');
    }
    public static void main(String[] args) {
        favorite_pet_names();
        favorite_pet_names();
    }
}
