package activites;
import java.util.Scanner;

public class Calculator {
    public static void value(float a, float b){
        System.out.println(a + b);
        System.out.println(a * b);
        System.out.println(a - b);
        System.out.println(a / b);
    }
    public static void main(String[] args) {
        //float x = 4.0f;
        //float y = 2.0f;

        System.out.println("Please give value of x and y for calculation");
        System.out.print("Enter the value: ");
        Scanner s = new Scanner(System.in);
        float x = s.nextFloat();
        float y = s.nextFloat();
        //System.out.println(s.nextFloat());
        s.close();

        //System.out.println(x , y);

        value(x,y);
    }
}
