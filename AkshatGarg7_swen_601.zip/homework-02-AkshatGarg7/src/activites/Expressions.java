package activites;

public class Expressions {
    public static void main(String[] args){

        int x = 5;
        float y = 5.23f;

        float z = x+y;

        System.out.println(z);
        System.out.println("x= ");
        System.out.println(x);
        System.out.println("y =" + y);

    }
}
