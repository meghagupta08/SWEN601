package activites;

import org.codehaus.groovy.transform.SourceURIASTTransformation;

public class WeightConverter {
    public static float weigh(float p){

        float k = p / 2.2f;
        return k;
    }

    public static void main(String[] args) {
        float TotalWeightpounds_1 = 186.2f;
        float TotalWeightpounds_2 = 207;
        System.out.println("pounds: " + TotalWeightpounds_1);
        System.out.println("kilos:" + weigh(TotalWeightpounds_1));
        System.out.println("pounds: " + TotalWeightpounds_2);
        System.out.println("kilos: " + weigh(TotalWeightpounds_2));
        float TotalWeightpounds = TotalWeightpounds_1 + TotalWeightpounds_2;
        System.out.println("total: " + weigh(TotalWeightpounds));
    }
}