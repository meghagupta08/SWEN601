package activites;

public class Literally {
    public static void main(String[] args){
        System.out.println(1);
        System.out.println(3.14156743);
        System.out.println('a');
        System.out.println("Buttercup");
        System.out.println(true);
    }
}
