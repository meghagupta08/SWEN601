package homework;
import java.util.Scanner;

/**
 * Class Concatenation return a concatenated string
 *
 * @author Akshat Garg ag2193@rit.edu
 * @version v1.1
 * @since v1.0
 */

public class Concatenation {

    /** Creating function concatenated to concatenate given inputs.
     * <p>
     * The function takes 3 inputs from user,i.e.,
     * string, integer and float type. The function
     * converts integer and float type to string type
     * and function returns a concatenated string of
     * these 3 values.
     *
     * @param a is string type
     * @param b is an integer type
     * @param c is a float type
     * @return a concatenated string of a + b + c
     */

    public static String concatenated(String a, int b, float c){

        String d = Integer.toString(b); //converting integer type to string type
        String e = Float.toString(c);//converting float type to string type
        return a + b + c; // returning the concatenated string

    }

    /**
     * Searches for user input using the scanner library and
     * calling the function concatenated(a,b,c) and passing values
     * we print output using System.out.println()
     *
     * @param args none
     */

    public static void main(String[] args) {

        System.out.print("Enter the string, integer and float in same order: ");// asking the user to input in the order of string , integer type and float type
        Scanner s = new Scanner(System.in);// starting scanner to scan input
        String a = s.next();//scanning string type
        int b = s.nextInt();//scanning the next type,i.e., integer type
        float c = s.nextFloat();//scanning the last input float type
        s.close(); //stopping the scan
        System.out.println("Concatenated string: " + concatenated(a,b,c)); //output

    }
}// End of class Concatenation
