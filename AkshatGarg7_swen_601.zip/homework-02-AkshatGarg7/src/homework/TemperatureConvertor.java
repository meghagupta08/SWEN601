package homework;
import java.util.Scanner; //To import scanner

public class TemperatureConvertor {

    /* Creating a function to convert
    * given degree fahrenheit in kelvin using the formula
    * and returning a float value of kelvin
    */
    public static float convertor(float TemperatureF){
        float TemperatureK = ((TemperatureF - 32) * 5/9) + 273; //Converting Fahrenheit to Kelvin using formula
        return TemperatureK; //Returning temperature in Kelvin

    }

    public static void main(String[] args) {

        System.out.print("Enter the temperature in degree Fahrenheit: "); //prompting user to input the temperature in f
        Scanner s = new Scanner(System.in); // using scanner to scan for input
        float TemperatureF = s.nextFloat(); // storing the user input temperature in new variable
        s.close(); // stopping the scanner
        System.out.println(TemperatureF + " degrees Fahrenheit is " + convertor(TemperatureF) + " degrees in Kelvin");//output
        //System.out.println(convertor(212));

    }
}
