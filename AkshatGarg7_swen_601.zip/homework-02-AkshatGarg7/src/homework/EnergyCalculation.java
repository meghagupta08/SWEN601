package homework;
import java.util.Scanner;

/**
 * Class EnergyCalculation return energy of mass using formula e = m*(c^2)
 *
 * @author Akshat Garg ag2193@rit.edu
 * @version v1.1
 * @since v1.0
 */

public class EnergyCalculation {

    /** Function energy returns energy of given mass using formula e = m*(c^2)
     * <p>
     * The function return energy in joules and is double type.
     * We take input from user of mass in grams of type double
     * and divide it by 1000 so that it is in SI unit, kg
     * and multiply it by square of speed of light,i.e., c
     * which equals to 299792458 m/s. This gives us the value of
     * energy,i.e., e in joules.
     * The function returns e.
     *
     * @param mass double type and is in grams
     * @return e of double type and in joules
     */

    public static double energy(double mass){

        int c = 299792458; //speed of light in m/s
        double e = (mass/1000) * c * c; //formula to calculate the energy in Joules, we divided the mass by 1000 because it is in grams
        return e; //returning the value of energy in joules

    }

    /**
     * Searches for user input using the scanner library
     * and calls the function energy to return the value for the given input of mass in grams
     *
     * @param args none
     */

    public static void main(String[] args) {

        System.out.print("Enter the mass in grams: ");//prompting user to give input for mass in grams
        Scanner s = new Scanner(System.in);//initializing scanner to scan user input
        double mass = s.nextDouble(); //storing user input in variable mass
        s.close();
        System.out.println("Energy in Joules: " + energy(mass) +" J");//output

    }
}//End of class EnergyCalculation
